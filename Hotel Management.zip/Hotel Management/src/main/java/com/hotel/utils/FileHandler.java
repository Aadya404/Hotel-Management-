package com.hotel.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.hotel.models.Booking;
import com.hotel.models.Customer;
import com.hotel.models.Invoice;
import com.hotel.models.Rating;
import com.hotel.models.Room;
import com.hotel.models.User;

/**
 * FileHandler Class
 * Handles file-based serialization and deserialization of objects
 */
public class FileHandler {
    private static final String DATA_DIR = "data/";
    
    // File paths
    private static final String ROOMS_FILE = DATA_DIR + "rooms.dat";
    private static final String CUSTOMERS_FILE = DATA_DIR + "customers.dat";
    private static final String BOOKINGS_FILE = DATA_DIR + "bookings.dat";
    private static final String INVOICES_FILE = DATA_DIR + "invoices.dat";
    private static final String USERS_FILE = DATA_DIR + "users.dat";
    private static final String RATINGS_FILE = DATA_DIR + "ratings.dat";

    // ==================== Initialization ====================

    /**
     * Create data directory if not exists
     */
    public static void initializeDataDirectory() {
        File dir = new File(DATA_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    // ==================== Generic Save/Load Methods ====================

    /**
     * Save list of objects to file (Serialization)
     */
    @SuppressWarnings("unchecked")
    public static <T> boolean saveList(String filename, List<T> list) {
        try {
            initializeDataDirectory();
            FileOutputStream fos = new FileOutputStream(filename);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(list);
            oos.close();
            fos.close();
            return true;
        } catch (IOException e) {
            System.err.println("Error saving to file: " + filename);
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Load list of objects from file (Deserialization)
     */
    @SuppressWarnings("unchecked")
    public static <T> List<T> loadList(String filename) {
        try {
            FileInputStream fis = new FileInputStream(filename);
            ObjectInputStream ois = new ObjectInputStream(fis);
            List<T> list = (List<T>) ois.readObject();
            ois.close();
            fis.close();
            return list;
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading from file: " + filename);
            return new ArrayList<>();
        }
    }

    /**
     * Check if file exists
     */
    public static boolean fileExists(String filename) {
        return new File(filename).exists();
    }

    /**
     * Delete file
     */
    public static boolean deleteFile(String filename) {
        return new File(filename).delete();
    }

    // ==================== Room Operations ====================

    /**
     * Save rooms list
     */
    public static boolean saveRooms(List<Room> rooms) {
        return saveList(ROOMS_FILE, rooms);
    }

    /**
     * Load rooms list
     */
    public static List<Room> loadRooms() {
        if (!fileExists(ROOMS_FILE)) {
            return new ArrayList<>();
        }
        return loadList(ROOMS_FILE);
    }

    // ==================== Customer Operations ====================

    /**
     * Save customers list
     */
    public static boolean saveCustomers(List<Customer> customers) {
        return saveList(CUSTOMERS_FILE, customers);
    }

    /**
     * Load customers list
     */
    public static List<Customer> loadCustomers() {
        if (!fileExists(CUSTOMERS_FILE)) {
            return new ArrayList<>();
        }
        return loadList(CUSTOMERS_FILE);
    }

    // ==================== Booking Operations ====================

    /**
     * Save bookings list
     */
    public static boolean saveBookings(List<Booking> bookings) {
        return saveList(BOOKINGS_FILE, bookings);
    }

    /**
     * Load bookings list
     */
    public static List<Booking> loadBookings() {
        if (!fileExists(BOOKINGS_FILE)) {
            return new ArrayList<>();
        }
        return loadList(BOOKINGS_FILE);
    }

    // ==================== Invoice Operations ====================

    /**
     * Save invoices list
     */
    public static boolean saveInvoices(List<Invoice> invoices) {
        return saveList(INVOICES_FILE, invoices);
    }

    /**
     * Load invoices list
     */
    public static List<Invoice> loadInvoices() {
        if (!fileExists(INVOICES_FILE)) {
            return new ArrayList<>();
        }
        return loadList(INVOICES_FILE);
    }

    // ==================== User Operations ====================

    /**
     * Save users list
     */
    public static boolean saveUsers(List<User> users) {
        return saveList(USERS_FILE, users);
    }

    /**
     * Load users list
     */
    public static List<User> loadUsers() {
        if (!fileExists(USERS_FILE)) {
            return new ArrayList<>();
        }
        return loadList(USERS_FILE);
    }

    // ==================== Rating Operations ====================

    /**
     * Save ratings list
     */
    public static boolean saveRatings(List<Rating> ratings) {
        return saveList(RATINGS_FILE, ratings);
    }

    /**
     * Load ratings list
     */
    public static List<Rating> loadRatings() {
        if (!fileExists(RATINGS_FILE)) {
            return new ArrayList<>();
        }
        return loadList(RATINGS_FILE);
    }

    // ==================== Backup Operations ====================

    /**
     * Create backup of all data files
     */
    public static boolean backupAllData() {
        try {
            String backupDir = "backup/" + System.currentTimeMillis() + "/";
            new File(backupDir).mkdirs();
            
            backupFile(ROOMS_FILE, backupDir + "rooms.dat");
            backupFile(CUSTOMERS_FILE, backupDir + "customers.dat");
            backupFile(BOOKINGS_FILE, backupDir + "bookings.dat");
            backupFile(INVOICES_FILE, backupDir + "invoices.dat");
            backupFile(USERS_FILE, backupDir + "users.dat");
            backupFile(RATINGS_FILE, backupDir + "ratings.dat");
            
            return true;
        } catch (Exception e) {
            System.err.println("Error creating backup");
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Backup single file
     */
    private static void backupFile(String sourceFile, String destFile) throws IOException {
        if (!fileExists(sourceFile)) {
            return;
        }
        
        FileInputStream fis = new FileInputStream(sourceFile);
        FileOutputStream fos = new FileOutputStream(destFile);
        byte[] buffer = new byte[1024];
        int length;
        while ((length = fis.read(buffer)) > 0) {
            fos.write(buffer, 0, length);
        }
        fis.close();
        fos.close();
    }

    // ==================== Data Integrity ====================

    /**
     * Check if data files are corrupted
     */
    public static boolean validateDataFiles() {
        try {
            if (fileExists(ROOMS_FILE)) {
                loadRooms();
            }
            if (fileExists(CUSTOMERS_FILE)) {
                loadCustomers();
            }
            if (fileExists(BOOKINGS_FILE)) {
                loadBookings();
            }
            if (fileExists(INVOICES_FILE)) {
                loadInvoices();
            }
            if (fileExists(USERS_FILE)) {
                loadUsers();
            }
            if (fileExists(RATINGS_FILE)) {
                loadRatings();
            }
            return true;
        } catch (Exception e) {
            System.err.println("Data integrity check failed");
            return false;
        }
    }

    /**
     * Get data directory size
     */
    public static long getDataDirectorySize() {
        File dir = new File(DATA_DIR);
        long size = 0;
        
        if (dir.exists() && dir.isDirectory()) {
            for (File file : dir.listFiles()) {
                if (file.isFile()) {
                    size += file.length();
                }
            }
        }
        
        return size;
    }

    /**
     * Clear all data files
     */
    public static boolean clearAllData() {
        try {
            deleteFile(ROOMS_FILE);
            deleteFile(CUSTOMERS_FILE);
            deleteFile(BOOKINGS_FILE);
            deleteFile(INVOICES_FILE);
            deleteFile(USERS_FILE);
            deleteFile(RATINGS_FILE);
            return true;
        } catch (Exception e) {
            System.err.println("Error clearing data");
            return false;
        }
    }

    /**
     * Get file info summary
     */
    public static String getFileInfoSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("========== FILE INFO ==========\n");
        sb.append("Rooms: ").append(fileExists(ROOMS_FILE) ? "✓" : "✗").append("\n");
        sb.append("Customers: ").append(fileExists(CUSTOMERS_FILE) ? "✓" : "✗").append("\n");
        sb.append("Bookings: ").append(fileExists(BOOKINGS_FILE) ? "✓" : "✗").append("\n");
        sb.append("Invoices: ").append(fileExists(INVOICES_FILE) ? "✓" : "✗").append("\n");
        sb.append("Users: ").append(fileExists(USERS_FILE) ? "✓" : "✗").append("\n");
        sb.append("Ratings: ").append(fileExists(RATINGS_FILE) ? "✓" : "✗").append("\n");
        sb.append("Total Size: ").append(getDataDirectorySize()).append(" bytes\n");
        sb.append("===============================\n");
        return sb.toString();
    }
}