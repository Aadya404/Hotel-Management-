package com.hotel.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.hotel.models.Booking;
import com.hotel.models.Room;

/**
 * DatabaseLogger - JDBC/SQLite integration
 * Logs key hotel operations to a SQLite database for audit and reporting.
 * Works alongside file-based storage (FileHandler) as a secondary persistent store.
 */
public class DatabaseLogger {

    private static final String DB_URL = "jdbc:sqlite:hotel_audit.db";
    private static Connection connection;

    // ── Connect ──
    public static void connect() {
        try {
            connection = DriverManager.getConnection(DB_URL);
            System.out.println("JDBC connected to SQLite: hotel_audit.db");
            createTables();
        } catch (SQLException e) {
            System.err.println("JDBC connection failed: " + e.getMessage());
        }
    }

    public static void disconnect() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("JDBC connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("Error closing JDBC: " + e.getMessage());
        }
    }

    // ── Create Tables ──
    private static void createTables() throws SQLException {
        Statement st = connection.createStatement();

        st.execute(
            "CREATE TABLE IF NOT EXISTS booking_log (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "booking_id INTEGER," +
            "customer_id INTEGER," +
            "room_number INTEGER," +
            "check_in_date TEXT," +
            "check_out_date TEXT," +
            "guests INTEGER," +
            "final_price REAL," +
            "status TEXT," +
            "logged_at TEXT DEFAULT (datetime('now')))"
        );

        st.execute(
            "CREATE TABLE IF NOT EXISTS room_log (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "room_number INTEGER," +
            "room_type TEXT," +
            "category TEXT," +
            "price REAL," +
            "status TEXT," +
            "logged_at TEXT DEFAULT (datetime('now')))"
        );

        st.execute(
            "CREATE TABLE IF NOT EXISTS login_log (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "username TEXT," +
            "role TEXT," +
            "success INTEGER," +
            "logged_at TEXT DEFAULT (datetime('now')))"
        );

        st.execute(
            "CREATE TABLE IF NOT EXISTS revenue_log (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "booking_id INTEGER," +
            "room_number INTEGER," +
            "amount REAL," +
            "payment_method TEXT," +
            "logged_at TEXT DEFAULT (datetime('now')))"
        );

        st.close();
        System.out.println("JDBC tables ready.");
    }

    // ── Log a Booking ──
    public static void logBooking(Booking booking) {
        if (connection == null) return;
        String sql =
            "INSERT INTO booking_log " +
            "(booking_id, customer_id, room_number, check_in_date, " +
            "check_out_date, guests, final_price, status) " +
            "VALUES (?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1,    booking.getBookingId());
            ps.setInt(2,    booking.getCustomerId());
            ps.setInt(3,    booking.getRoomNumber());
            ps.setString(4, booking.getCheckInDate().toString());
            ps.setString(5, booking.getCheckOutDate().toString());
            ps.setInt(6,    booking.getNumberOfGuests());
            ps.setDouble(7, booking.getFinalPrice());
            ps.setString(8, booking.getStatus().getDisplayName());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("logBooking error: " + e.getMessage());
        }
    }

    // ── Log Booking Status Change ──
    public static void logBookingStatusChange(Booking booking) {
        if (connection == null) return;
        String sql =
            "INSERT INTO booking_log " +
            "(booking_id, customer_id, room_number, check_in_date, " +
            "check_out_date, guests, final_price, status) " +
            "VALUES (?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1,    booking.getBookingId());
            ps.setInt(2,    booking.getCustomerId());
            ps.setInt(3,    booking.getRoomNumber());
            ps.setString(4, booking.getCheckInDate().toString());
            ps.setString(5, booking.getCheckOutDate().toString());
            ps.setInt(6,    booking.getNumberOfGuests());
            ps.setDouble(7, booking.getFinalPrice());
            ps.setString(8, booking.getStatus().getDisplayName());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("logBookingStatusChange error: " + e.getMessage());
        }
    }

    // ── Log Room ──
    public static void logRoom(Room room) {
        if (connection == null) return;
        String sql =
            "INSERT INTO room_log (room_number, room_type, category, price, status) " +
            "VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1,    room.getRoomNumber());
            ps.setString(2, room.getRoomType().getDisplayName());
            ps.setString(3, room.getRoomCategory().getDisplayName());
            ps.setDouble(4, room.getPricePerDay());
            ps.setString(5, room.getStatus().getDisplayName());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("logRoom error: " + e.getMessage());
        }
    }

    // ── Log Login ──
    public static void logLogin(String username, String role, boolean success) {
        if (connection == null) return;
        String sql = "INSERT INTO login_log (username, role, success) VALUES (?,?,?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, role);
            ps.setInt(3,    success ? 1 : 0);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("logLogin error: " + e.getMessage());
        }
    }

    // ── Log Revenue ──
    public static void logRevenue(int bookingId, int roomNumber,
                                   double amount, String paymentMethod) {
        if (connection == null) return;
        String sql =
            "INSERT INTO revenue_log (booking_id, room_number, amount, payment_method) " +
            "VALUES (?,?,?,?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1,    bookingId);
            ps.setInt(2,    roomNumber);
            ps.setDouble(3, amount);
            ps.setString(4, paymentMethod);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("logRevenue error: " + e.getMessage());
        }
    }

    // ── Query: Booking audit log ──
    public static String getBookingSummaryFromDB() {
        if (connection == null) return "Database not connected.";
        StringBuilder sb = new StringBuilder();
        sb.append("======= BOOKING AUDIT LOG (SQLite/JDBC) =======\n");
        String sql = "SELECT * FROM booking_log ORDER BY logged_at DESC LIMIT 50";
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            sb.append(String.format("%-8s %-6s %-6s %-12s %-12s %-8s %-12s %s\n",
                "Booking", "Cust", "Room", "Check-In", "Check-Out",
                "Guests", "Price", "Status"));
            sb.append("------------------------------------------------\n");
            int count = 0;
            while (rs.next()) {
                sb.append(String.format("%-8d %-6d %-6d %-12s %-12s %-8d %-12s %s\n",
                    rs.getInt("booking_id"),
                    rs.getInt("customer_id"),
                    rs.getInt("room_number"),
                    rs.getString("check_in_date"),
                    rs.getString("check_out_date"),
                    rs.getInt("guests"),
                    "Rs." + String.format("%.0f", rs.getDouble("final_price")),
                    rs.getString("status")
                ));
                count++;
            }
            if (count == 0) sb.append("  No bookings logged yet.\n");
        } catch (SQLException e) {
            sb.append("Error reading from DB: ").append(e.getMessage());
        }
        sb.append("===============================================\n");
        return sb.toString();
    }

    // ── Query: Login audit log ──
    public static String getLoginLogFromDB() {
        if (connection == null) return "Database not connected.";
        StringBuilder sb = new StringBuilder();
        sb.append("LOGIN AUDIT LOG (SQLite/JDBC) \n");
        String sql = "SELECT * FROM login_log ORDER BY logged_at DESC LIMIT 20";
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                sb.append(String.format("%-15s %-12s %-8s %s\n",
                    rs.getString("username"),
                    rs.getString("role"),
                    rs.getInt("success") == 1 ? "Login OK" : "FAILED",
                    rs.getString("logged_at")
                ));
            }
        } catch (SQLException e) {
            sb.append("Error: ").append(e.getMessage());
        }
        sb.append("--------------------------------------\n");
        return sb.toString();
    }

    // ── Query: Revenue log ──
    public static String getRevenueLogFromDB() {
        if (connection == null) return "Database not connected.";
        StringBuilder sb = new StringBuilder();
        sb.append(" REVENUE LOG (SQLite/JDBC) \n");
        String sql = "SELECT * FROM revenue_log ORDER BY logged_at DESC";
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            double total = 0;
            while (rs.next()) {
                double amt = rs.getDouble("amount");
                total += amt;
                sb.append(String.format("Booking #%-6d Room %-4d Rs.%-10.2f %s  [%s]\n",
                    rs.getInt("booking_id"),
                    rs.getInt("room_number"),
                    amt,
                    rs.getString("payment_method"),
                    rs.getString("logged_at")
                ));
            }
            sb.append("--------------------------------------------\n");
            sb.append(String.format("Total Revenue logged: Rs.%.2f\n", total));
        } catch (SQLException e) {
            sb.append("Error: ").append(e.getMessage());
        }
        sb.append("==========================================\n");
        return sb.toString();
    }

    public static boolean isConnected() {
        try { return connection != null && !connection.isClosed(); }
        catch (SQLException e) { return false; }
    }
}