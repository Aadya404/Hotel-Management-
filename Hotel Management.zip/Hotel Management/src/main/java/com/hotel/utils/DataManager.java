package com.hotel.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.hotel.models.AmenityType;
import com.hotel.models.Booking;
import com.hotel.models.Customer;
import com.hotel.models.Invoice;
import com.hotel.models.Rating;
import com.hotel.models.Room;
import com.hotel.models.RoomCategory;
import com.hotel.models.RoomType;
import com.hotel.models.User;
import com.hotel.services.BillingService;
import com.hotel.services.BookingService;
import com.hotel.services.PricingService;
import com.hotel.services.ReportService;
import com.hotel.services.RoomService;
import com.hotel.services.UserService;

/**
 * DataManager Class
 * Centralized data management with thread-safe operations and automatic persistence
 * Uses synchronization for thread-safe access
 */
public class DataManager {
    // Services
    private RoomService roomService;
    private BookingService bookingService;
    private BillingService billingService;
    private UserService userService;
    private ReportService reportService;
    private PricingService pricingService;

    // Data lists with synchronization
    private List<Room> rooms;
    private List<Customer> customers;
    private List<Booking> bookings;
    private List<Invoice> invoices;
    private List<User> users;
    private List<Rating> ratings;

    // Thread management
    private ScheduledExecutorService autoSaveExecutor;
    private final Object lock = new Object();  // Synchronization lock
    private volatile boolean isInitialized = false;  // Wrapper class: Boolean

    public DataManager() {
        initializeCollections();
        initializeServices();
        startAutoSave();
    }

    // ==================== Initialization ====================

    /**
     * Initialize all collections with thread-safe lists
     */
    private void initializeCollections() {
        synchronized (lock) {
            // Use Collections.synchronizedList for thread safety
            this.rooms = Collections.synchronizedList(new ArrayList<>());
            this.customers = Collections.synchronizedList(new ArrayList<>());
            this.bookings = Collections.synchronizedList(new ArrayList<>());
            this.invoices = Collections.synchronizedList(new ArrayList<>());
            this.users = Collections.synchronizedList(new ArrayList<>());
            this.ratings = Collections.synchronizedList(new ArrayList<>());
        }
    }

    /**
     * Initialize all services
     */
    private void initializeServices() {
        synchronized (lock) {
            this.roomService = new RoomService();
            this.bookingService = new BookingService(roomService);
            this.billingService = new BillingService(bookingService, roomService);
            this.userService = new UserService();
            this.reportService = new ReportService(roomService, bookingService, billingService);
            this.pricingService = new PricingService(roomService, bookingService);
            this.isInitialized = true;  // Autoboxing: Boolean
        }
    }

    // ==================== Data Loading ====================

    /**
     * Load all data from files
     */
    public boolean loadAllData() {
        synchronized (lock) {
            try {
                FileHandler.initializeDataDirectory();

                // Load rooms
                List<Room> loadedRooms = FileHandler.loadRooms();
                rooms.addAll(loadedRooms);
                for (Room room : loadedRooms) {
                    roomService.addRoom(room);
                }

                // Load users
                List<User> loadedUsers = FileHandler.loadUsers();
                users.addAll(loadedUsers);

                // Load customers
                List<Customer> loadedCustomers = FileHandler.loadCustomers();
                customers.addAll(loadedCustomers);

                // Load bookings
               List<Booking> loadedBookings = FileHandler.loadBookings();
               bookings.addAll(loadedBookings);
               for (Booking booking : loadedBookings) {

                    bookingService.loadBookingDirectly(booking);
                 }

                // Load invoices
                List<Invoice> loadedInvoices = FileHandler.loadInvoices();
                invoices.addAll(loadedInvoices);

                // Load ratings
                List<Rating> loadedRatings = FileHandler.loadRatings();
                ratings.addAll(loadedRatings);

                System.out.println("✓ All data loaded successfully");
                return true;
            } catch (Exception e) {
                System.err.println("✗ Error loading data: " + e.getMessage());
                return false;
            }
        }
    }

    // ==================== Data Saving ====================

    /**
     * Save all data to files (synchronized)
     */
    public boolean saveAllData() {
        synchronized (lock) {
            try {
                FileHandler.backupAllData();
                
                FileHandler.saveRooms(new ArrayList<>(rooms));
                FileHandler.saveCustomers(new ArrayList<>(customers));
                FileHandler.saveBookings(new ArrayList<>(bookings));
                FileHandler.saveInvoices(new ArrayList<>(invoices));
                FileHandler.saveUsers(new ArrayList<>(users));
                FileHandler.saveRatings(new ArrayList<>(ratings));

                System.out.println("✓ All data saved successfully");
                return true;
            } catch (Exception e) {
                System.err.println("✗ Error saving data: " + e.getMessage());
                return false;
            }
        }
    }

    // ==================== Auto-Save (Multithreading) ====================

    /**
     * Start auto-save thread (saves every 5 minutes)
     */
    private void startAutoSave() {
        autoSaveExecutor = Executors.newScheduledThreadPool(1);
        autoSaveExecutor.scheduleAtFixedRate(
                this::saveAllData,
                5,  // Initial delay: 5 minutes
                5,  // Repeat every: 5 minutes
                TimeUnit.MINUTES
        );
    }

    /**
     * Stop auto-save thread
     */
    public void stopAutoSave() {
        if (autoSaveExecutor != null && !autoSaveExecutor.isShutdown()) {
            autoSaveExecutor.shutdown();
        }
    }

    // ==================== Service Getters ====================

    public RoomService getRoomService() {
        return roomService;
    }

    public BookingService getBookingService() {
        return bookingService;
    }

    public BillingService getBillingService() {
        return billingService;
    }

    public UserService getUserService() {
        return userService;
    }

    public ReportService getReportService() {
        return reportService;
    }

    public PricingService getPricingService() {
        return pricingService;
    }

    // ==================== Data Access (Thread-Safe) ====================

    /**
     * Get all rooms (thread-safe copy)
     */
    public List<Room> getAllRooms() {
        synchronized (lock) {
            return new ArrayList<>(rooms);
        }
    }

    /**
     * Get all customers (thread-safe copy)
     */
    public List<Customer> getAllCustomers() {
        synchronized (lock) {
            return new ArrayList<>(customers);
        }
    }

    /**
     * Get all bookings (thread-safe copy)
     */
    public List<Booking> getAllBookings() {
        synchronized (lock) {
            return new ArrayList<>(bookings);
        }
    }

    /**
     * Get all invoices (thread-safe copy)
     */
    public List<Invoice> getAllInvoices() {
        synchronized (lock) {
            return new ArrayList<>(invoices);
        }
    }

    /**
     * Get all users (thread-safe copy)
     */
    public List<User> getAllUsers() {
        synchronized (lock) {
            return new ArrayList<>(users);
        }
    }

    /**
     * Get all ratings (thread-safe copy)
     */
    public List<Rating> getAllRatings() {
        synchronized (lock) {
            return new ArrayList<>(ratings);
        }
    }

    // ==================== Statistics ====================

    /**
     * Get total data count
     */
    public String getDataStatistics() {
        synchronized (lock) {
            StringBuilder sb = new StringBuilder();
            sb.append("========== DATA STATISTICS ==========\n");
            sb.append("Rooms: ").append(rooms.size()).append("\n");
            sb.append("Customers: ").append(customers.size()).append("\n");
            sb.append("Bookings: ").append(bookings.size()).append("\n");
            sb.append("Invoices: ").append(invoices.size()).append("\n");
            sb.append("Users: ").append(users.size()).append("\n");
            sb.append("Ratings: ").append(ratings.size()).append("\n");
            sb.append("=====================================\n");
            return sb.toString();
        }
    }

    /**
     * Check if data manager is initialized
     */
    public Boolean isInitialized() {
        return isInitialized;  // Autoboxing: Boolean wrapper
    }

    /**
     * Get system health status
     */
    public String getSystemHealthStatus() {
        synchronized (lock) {
            StringBuilder sb = new StringBuilder();
            sb.append("========== SYSTEM HEALTH ==========\n");
            sb.append("Initialized: ").append(isInitialized ? "✓" : "✗").append("\n");
            sb.append("Data Files Valid: ").append(FileHandler.validateDataFiles() ? "✓" : "✗").append("\n");
            sb.append("Data Directory Size: ").append(FileHandler.getDataDirectorySize()).append(" bytes\n");
            sb.append("Auto-Save Active: ").append(!autoSaveExecutor.isShutdown() ? "✓" : "✗").append("\n");
            sb.append(FileHandler.getFileInfoSummary());
            sb.append("===================================\n");
            return sb.toString();
        }
    }

    // ==================== Sample Data ====================

    /**
     * Initialize with sample data for testing
     */
    public void initializeSampleData() {
    synchronized (lock) {
        if (roomService.getTotalRoomCount() > 0) return;

        // SINGLE ROOMS (1 adult + 1 child)
        Room r101 = new Room(101, RoomType.SINGLE, RoomCategory.STANDARD, 1500.0);
        r101.addAmenity(AmenityType.WIFI); r101.addAmenity(AmenityType.AIR_CONDITIONING);
        r101.setDescription("Cozy single, garden view");

        Room r102 = new Room(102, RoomType.SINGLE, RoomCategory.STANDARD, 1500.0);
        r102.addAmenity(AmenityType.WIFI); r102.addAmenity(AmenityType.TV);
        r102.setDescription("Standard single, quiet floor");

        Room r103 = new Room(103, RoomType.SINGLE, RoomCategory.PREMIUM, 1800.0);
        r103.addAmenity(AmenityType.WIFI); r103.addAmenity(AmenityType.AIR_CONDITIONING);
        r103.addAmenity(AmenityType.SAFE); r103.addAmenity(AmenityType.TV);
        r103.setDescription("Premium single, city view");

        Room r104 = new Room(104, RoomType.SINGLE, RoomCategory.PREMIUM, 1800.0);
        r104.addAmenity(AmenityType.WIFI); r104.addAmenity(AmenityType.AIR_CONDITIONING);
        r104.addAmenity(AmenityType.SHOWER);
        r104.setDescription("Premium single, upper floor");

        // DOUBLE ROOMS (2 adults + 1 child)
        Room r201 = new Room(201, RoomType.DOUBLE, RoomCategory.STANDARD, 2500.0);
        r201.addAmenity(AmenityType.WIFI); r201.addAmenity(AmenityType.AIR_CONDITIONING);
        r201.addAmenity(AmenityType.TV);
        r201.setDescription("Standard double, pool facing");

        Room r202 = new Room(202, RoomType.DOUBLE, RoomCategory.STANDARD, 2500.0);
        r202.addAmenity(AmenityType.WIFI); r202.addAmenity(AmenityType.AIR_CONDITIONING);
        r202.addAmenity(AmenityType.BALCONY);
        r202.setDescription("Standard double with balcony");

        Room r203 = new Room(203, RoomType.DOUBLE, RoomCategory.PREMIUM, 3000.0);
        r203.addAmenity(AmenityType.WIFI); r203.addAmenity(AmenityType.AIR_CONDITIONING);
        r203.addAmenity(AmenityType.BALCONY); r203.addAmenity(AmenityType.SAFE);
        r203.addAmenity(AmenityType.TV);
        r203.setDescription("Premium double, sea view");

        Room r204 = new Room(204, RoomType.DOUBLE, RoomCategory.PREMIUM, 3000.0);
        r204.addAmenity(AmenityType.WIFI); r204.addAmenity(AmenityType.AIR_CONDITIONING);
        r204.addAmenity(AmenityType.BATHTUB); r204.addAmenity(AmenityType.MINI_BAR);
        r204.setDescription("Premium double with bathtub");

        Room r205 = new Room(205, RoomType.DOUBLE, RoomCategory.LUXURY, 3500.0);
        r205.addAmenity(AmenityType.WIFI); r205.addAmenity(AmenityType.AIR_CONDITIONING);
        r205.addAmenity(AmenityType.BALCONY); r205.addAmenity(AmenityType.MINI_BAR);
        r205.addAmenity(AmenityType.BATHTUB); r205.addAmenity(AmenityType.ROOM_SERVICE);
        r205.setDescription("Luxury double, panoramic view");

        // DELUXE SUITES (3 adults + 2 children)
        Room r301 = new Room(301, RoomType.DELUXE, RoomCategory.LUXURY, 5000.0);
        r301.addAmenity(AmenityType.WIFI); r301.addAmenity(AmenityType.AIR_CONDITIONING);
        r301.addAmenity(AmenityType.BALCONY); r301.addAmenity(AmenityType.MINI_BAR);
        r301.addAmenity(AmenityType.ROOM_SERVICE);
        r301.setDescription("Luxury suite, top floor");

        Room r302 = new Room(302, RoomType.DELUXE, RoomCategory.LUXURY, 5000.0);
        r302.addAmenity(AmenityType.WIFI); r302.addAmenity(AmenityType.AIR_CONDITIONING);
        r302.addAmenity(AmenityType.BALCONY); r302.addAmenity(AmenityType.BATHTUB);
        r302.addAmenity(AmenityType.MINI_BAR); r302.addAmenity(AmenityType.SAFE);
        r302.addAmenity(AmenityType.ROOM_SERVICE);
        r302.setDescription("Presidential suite with jacuzzi");

        Room r303 = new Room(303, RoomType.DELUXE, RoomCategory.LUXURY, 5500.0);
        r303.addAmenity(AmenityType.WIFI); r303.addAmenity(AmenityType.AIR_CONDITIONING);
        r303.addAmenity(AmenityType.BALCONY); r303.addAmenity(AmenityType.BATHTUB);
        r303.addAmenity(AmenityType.MINI_BAR); r303.addAmenity(AmenityType.TV);
        r303.addAmenity(AmenityType.ROOM_SERVICE);
        r303.setDescription("Grand suite, private terrace");

        Room r304 = new Room(304, RoomType.DELUXE, RoomCategory.LUXURY, 6000.0);
        r304.addAmenity(AmenityType.WIFI); r304.addAmenity(AmenityType.AIR_CONDITIONING);
        r304.addAmenity(AmenityType.BALCONY); r304.addAmenity(AmenityType.BATHTUB);
        r304.addAmenity(AmenityType.MINI_BAR); r304.addAmenity(AmenityType.SAFE);
        r304.addAmenity(AmenityType.TV); r304.addAmenity(AmenityType.SHOWER);
        r304.addAmenity(AmenityType.ROOM_SERVICE);
        r304.setDescription("Royal suite, butler service");

        for (Room r : new Room[]{r101,r102,r103,r104,
                                  r201,r202,r203,r204,r205,
                                  r301,r302,r303,r304}) {
            roomService.addRoom(r);
            rooms.add(r);
        }
        System.out.println("✓ Sample data initialized: 13 rooms loaded");
    }
}

    // ==================== Cleanup ====================

    /**
     * Cleanup and shutdown
     */
    public void shutdown() {
        synchronized (lock) {
            saveAllData();
            stopAutoSave();
            System.out.println("✓ DataManager shutdown complete");
        }
    }

    /**
     * Reset all data
     */
    public void resetAllData() {
        synchronized (lock) {
            FileHandler.clearAllData();
            rooms.clear();
            customers.clear();
            bookings.clear();
            invoices.clear();
            users.clear();
            ratings.clear();
            initializeCollections();
            System.out.println("✓ All data reset");
        }
    }
}