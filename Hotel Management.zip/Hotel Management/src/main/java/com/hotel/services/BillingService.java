package com.hotel.services;

import com.hotel.models.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * BillingService Class
 * Handles all billing-related operations including invoice generation, payment tracking, and refunds
 */
public class BillingService {
    private List<Invoice> invoices;  // Collection: List for invoice storage
    private BookingService bookingService;
    private RoomService roomService;
    private static final Double TAX_PERCENTAGE = 18.0;  // Wrapper class: 18% GST (India)

    public BillingService(BookingService bookingService, RoomService roomService) {
        this.invoices = new ArrayList<>();  // Generics: ArrayList<Invoice>
        this.bookingService = bookingService;
        this.roomService = roomService;
    }

    // ==================== Invoice Creation ====================

    /**
     * Generate invoice for a booking
     */
    public Invoice generateInvoice(int bookingId, int customerId, String customerName, 
                                   String customerEmail, String customerPhone) {
        Booking booking = bookingService.getBookingById(bookingId);
        if (booking == null) {
            return null;
        }

        Room room = roomService.getRoomByNumber(booking.getRoomNumber());
        if (room == null) {
            return null;
        }

        // Create invoice
        Invoice invoice = new Invoice(bookingId, customerId, booking.getRoomNumber(), 
                                     customerName, customerEmail, customerPhone);

        // Set booking details
        invoice.setCheckInDate(booking.getCheckInDate());
        invoice.setCheckOutDate(booking.getCheckOutDate());
        invoice.setNumberOfGuests(booking.getNumberOfGuests());
        invoice.setNumberOfNights((int) java.time.temporal.ChronoUnit.DAYS.between(
                                booking.getCheckInDate(), booking.getCheckOutDate()));
        invoice.setRoomType(room.getRoomType().getDisplayName());
        invoice.setPricePerNight(room.getPricePerDay());

        // Set room charges (base price × number of nights)
        Double roomCharges = room.getPricePerDay() * invoice.getNumberOfNights();
        invoice.setRoomCharges(roomCharges);

        // Set tax percentage
        invoice.setTaxPercentage(TAX_PERCENTAGE);

        // Calculate totals
        invoice.calculateTotals();

        // Issue the invoice
        invoice.issueInvoice();

        invoices.add(invoice);
        return invoice;
    }

    /**
     * Get invoice by ID
     */
    public Invoice getInvoiceById(int invoiceId) {
        return invoices.stream()
                .filter(invoice -> invoice.getInvoiceId() == invoiceId)
                .findFirst()
                .orElse(null);
    }

    /**
     * Get invoice by booking ID
     */
    public Invoice getInvoiceByBookingId(int bookingId) {
        return invoices.stream()
                .filter(invoice -> invoice.getBookingId() == bookingId)
                .findFirst()
                .orElse(null);
    }

    /**
     * Get all invoices
     */
    public List<Invoice> getAllInvoices() {
        return new ArrayList<>(invoices);
    }

    /**
     * Get invoices for a customer
     */
    public List<Invoice> getInvoicesByCustomerId(int customerId) {
        return invoices.stream()  // Generics & Stream API
                .filter(invoice -> invoice.getCustomerId() == customerId)
                .collect(Collectors.toList());
    }

    /**
     * Update invoice
     */
    public boolean updateInvoice(Invoice invoice) {
        Invoice existing = getInvoiceById(invoice.getInvoiceId());
        if (existing == null) {
            return false;
        }

        existing.setDiscountAmount(invoice.getDiscountAmount());
        existing.setLoyaltyDiscount(invoice.getLoyaltyDiscount());
        existing.setRemarks(invoice.getRemarks());
        existing.calculateTotals();

        return true;
    }

    /**
     * Delete invoice
     */
    public boolean deleteInvoice(int invoiceId) {
        return invoices.removeIf(invoice -> invoice.getInvoiceId() == invoiceId);
    }

    // ==================== Payment Operations ====================

    /**
     * Record payment for invoice
     */
    public boolean recordPayment(int invoiceId, Double amountPaid, String paymentMethod) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice == null) {
            return false;
        }

        invoice.setAmountPaid(amountPaid);
        invoice.setPaymentMethod(paymentMethod);

        if (amountPaid >= invoice.getTotalAmount()) {
            invoice.markAsPaid(paymentMethod);
        }

        return true;
    }

    /**
     * Make full payment
     */
    public boolean makeFullPayment(int invoiceId, String paymentMethod) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice == null) {
            return false;
        }

        invoice.markAsPaid(paymentMethod);
        return true;
    }

    /**
     * Get payment status
     */
    public String getPaymentStatus(int invoiceId) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice == null) {
            return "Invoice not found";
        }

        if (invoice.isPaid()) {
            return "PAID";
        } else if (invoice.getBalanceDue() == 0) {
            return "PAID";
        } else {
            return "PENDING - Balance due: ₹" + String.format("%.2f", invoice.getBalanceDue());
        }
    }

    /**
     * Get balance due
     */
    public Double getBalanceDue(int invoiceId) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice == null) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        return invoice.getBalanceDue();
    }

    // ==================== Discount & Deduction Operations ====================

    /**
     * Apply discount to invoice
     */
    public void applyDiscount(int invoiceId, Double discountAmount) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice != null) {
            invoice.setDiscountAmount(discountAmount);
            invoice.calculateTotals();
        }
    }

    /**
     * Apply loyalty points as discount
     */
    public void applyLoyaltyDiscount(int invoiceId, Double pointsValue) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice != null) {
            invoice.setLoyaltyDiscount(pointsValue);
            invoice.calculateTotals();
        }
    }

    /**
     * Apply promo code discount
     */
    public void applyPromoCode(int invoiceId, String promoCode, Double discountPercent) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice == null) {
            return;
        }

        // Calculate discount amount
        Double discountAmount = (invoice.getSubtotal() * discountPercent) / 100.0;
        invoice.setDiscountAmount(discountAmount);
        invoice.calculateTotals();
    }

    // ==================== Refund Operations ====================

    /**
     * Process refund for cancelled booking
     */
    public boolean processRefund(int invoiceId, Double refundAmount, String reason) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice == null || invoice.getTotalAmount() < 1) {
            return false;
        }

        invoice.processRefund(refundAmount, reason);
        return true;
    }

    /**
     * Get refund amount
     */
    public Double getRefundAmount(int invoiceId) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice == null) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        return invoice.getRefundAmount();
    }

    /**
     * Get refunded invoices
     */
    public List<Invoice> getRefundedInvoices() {
        return invoices.stream()
                .filter(Invoice::isRefunded)
                .collect(Collectors.toList());
    }

    /**
     * Get total refunded amount
     */
    public Double getTotalRefundedAmount() {
        return invoices.stream()
                .mapToDouble(Invoice::getRefundAmount)
                .sum();
    }

    // ==================== Invoice Status Operations ====================

    /**
     * Get invoices by status
     */
    public List<Invoice> getInvoicesByStatus(String status) {
        return invoices.stream()
                .filter(invoice -> invoice.getInvoiceStatus().equals(status))
                .collect(Collectors.toList());
    }

    /**
     * Get paid invoices
     */
    public List<Invoice> getPaidInvoices() {
        return getInvoicesByStatus("PAID");
    }

    /**
     * Get pending invoices
     */
    public List<Invoice> getPendingInvoices() {
        return invoices.stream()
                .filter(invoice -> !invoice.isPaid() && !invoice.isRefunded())
                .collect(Collectors.toList());
    }

    /**
     * Get overdue invoices (due date passed but not paid)
     */
    public List<Invoice> getOverdueInvoices() {
        return invoices.stream()
                .filter(invoice -> !invoice.isPaid())
                .filter(invoice -> invoice.getDueDate().isBefore(LocalDateTime.now()))
                .collect(Collectors.toList());
    }

    /**
     * Mark invoice as cancelled
     */
    public void cancelInvoice(int invoiceId) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice != null) {
            invoice.setInvoiceStatus("CANCELLED");
        }
    }

    // ==================== Statistics Operations ====================

    /**
     * Get total revenue (all paid invoices)
     */
    public Double getTotalRevenue() {
        return invoices.stream()
                .filter(Invoice::isPaid)
                .mapToDouble(Invoice::getTotalAmount)
                .sum();
    }

    /**
     * Get total pending amount (not yet paid)
     */
    public Double getTotalPendingAmount() {
        return invoices.stream()
                .filter(invoice -> !invoice.isPaid())
                .mapToDouble(Invoice::getBalanceDue)
                .sum();
    }

    /**
     * Get total invoiced amount
     */
    public Double getTotalInvoicedAmount() {
        return invoices.stream()
                .mapToDouble(Invoice::getTotalAmount)
                .sum();
    }

    /**
     * Get average invoice amount
     */
    public Double getAverageInvoiceAmount() {
        if (invoices.isEmpty()) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        return getTotalInvoicedAmount() / invoices.size();
    }

    /**
     * Get total tax collected
     */
    public Double getTotalTaxCollected() {
        return invoices.stream()
                .mapToDouble(Invoice::getTaxAmount)
                .sum();
    }

    /**
     * Get total discounts given
     */
    public Double getTotalDiscountsGiven() {
        return invoices.stream()
                .mapToDouble(Invoice::getDiscountAmount)
                .sum();
    }

    /**
     * Get payment method statistics
     */
    public Map<String, Integer> getPaymentMethodStats() {
        return invoices.stream()
                .filter(Invoice::isPaid)
                .collect(Collectors.groupingBy(
                        Invoice::getPaymentMethod,
                        Collectors.collectingAndThen(Collectors.toList(), List::size)
                ));
    }

    /**
     * Get invoice count
     */
    public int getTotalInvoiceCount() {
        return invoices.size();
    }

    /**
     * Get paid invoice count
     */
    public int getPaidInvoiceCount() {
        return (int) invoices.stream()
                .filter(Invoice::isPaid)
                .count();
    }

    /**
     * Get pending invoice count
     */
    public int getPendingInvoiceCount() {
        return (int) invoices.stream()
                .filter(invoice -> !invoice.isPaid())
                .count();
    }

    /**
     * Get refunded invoice count
     */
    public int getRefundedInvoiceCount() {
        return (int) invoices.stream()
                .filter(Invoice::isRefunded)
                .count();
    }

    /**
     * Get collection rate percentage
     */
    public Double getCollectionRatePercentage() {
        if (invoices.isEmpty()) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        long paidCount = invoices.stream().filter(Invoice::isPaid).count();
        return (paidCount * 100.0) / invoices.size();
    }

    /**
     * Get revenue for date range
     */
    public Double getRevenueForDateRange(java.time.LocalDate startDate, java.time.LocalDate endDate) {
        return invoices.stream()
                .filter(Invoice::isPaid)
                .filter(invoice -> !invoice.getInvoiceDate().toLocalDate().isBefore(startDate) &&
                                 !invoice.getInvoiceDate().toLocalDate().isAfter(endDate))
                .mapToDouble(Invoice::getTotalAmount)
                .sum();
    }

    /**
     * Get invoice as formatted string
     */
    public String getInvoiceAsString(int invoiceId) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice == null) {
            return "Invoice not found";
        }
        return invoice.getInvoiceAsString();
    }

    /**
     * Print invoice
     */
    public void printInvoice(int invoiceId) {
        Invoice invoice = getInvoiceById(invoiceId);
        if (invoice != null) {
            System.out.println(invoice.getInvoiceAsString());
        }
    }

    /**
     * Get invoices by customer for report
     */
    public String getCustomerBillingReport(int customerId) {
        List<Invoice> customerInvoices = getInvoicesByCustomerId(customerId);
        
        StringBuilder sb = new StringBuilder();
        sb.append("========== CUSTOMER BILLING REPORT ==========\n");
        sb.append("Customer ID: ").append(customerId).append("\n");
        sb.append("Total Invoices: ").append(customerInvoices.size()).append("\n");
        
        Double totalAmount = customerInvoices.stream()
                .mapToDouble(Invoice::getTotalAmount)
                .sum();
        Double paidAmount = customerInvoices.stream()
                .filter(Invoice::isPaid)
                .mapToDouble(Invoice::getTotalAmount)
                .sum();
        
        sb.append("Total Amount: ₹").append(String.format("%.2f", totalAmount)).append("\n");
        sb.append("Paid Amount: ₹").append(String.format("%.2f", paidAmount)).append("\n");
        sb.append("Pending Amount: ₹").append(String.format("%.2f", totalAmount - paidAmount)).append("\n");
        
        sb.append("\n--- INVOICES ---\n");
        for (Invoice invoice : customerInvoices) {
            sb.append("Invoice #").append(invoice.getInvoiceId())
                    .append(" - ₹").append(String.format("%.2f", invoice.getTotalAmount()))
                    .append(" - ").append(invoice.getInvoiceStatus())
                    .append("\n");
        }
        
        sb.append("==========================================\n");
        return sb.toString();
    }
}