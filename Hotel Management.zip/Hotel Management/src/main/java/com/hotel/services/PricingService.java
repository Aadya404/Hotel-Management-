package com.hotel.services;

import com.hotel.models.*;
import java.time.LocalDate;
import java.time.Month;
import java.time.DayOfWeek;

/**
 * PricingService Class
 * Handles dynamic pricing calculations based on multiple factors
 */
public class PricingService {
    private RoomService roomService;
    private BookingService bookingService;

    public PricingService(RoomService roomService, BookingService bookingService) {
        this.roomService = roomService;
        this.bookingService = bookingService;
    }

    // ==================== Base Price Management ====================

    /**
     * Get base price for a room
     */
    public Double getBasePrice(int roomNumber) {
        Room room = roomService.getRoomByNumber(roomNumber);
        if (room == null) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        return room.getPricePerDay();
    }

    /**
     * Set base price for a room
     */
    public boolean setBasePrice(int roomNumber, Double price) {
        Room room = roomService.getRoomByNumber(roomNumber);
        if (room != null && price > 0) {
            room.setPricePerDay(price);
            return true;
        }
        return false;
    }

    // ==================== Dynamic Pricing Modifiers ====================

    /**
     * Calculate occupancy-based price modifier
     * < 30% booked → -15%
     * 30-60% booked → 0%
     * 60-80% booked → +15%
     * > 80% booked → +25%
     */
    public Double getOccupancyModifier() {
        Double occupancyRate = roomService.getOccupancyPercentage();

        if (occupancyRate < 30) {
            return -0.15;  // Wrapper class: Double autoboxing
        } else if (occupancyRate < 60) {
            return 0.0;
        } else if (occupancyRate < 80) {
            return 0.15;
        } else {
            return 0.25;
        }
    }

    /**
     * Calculate day-type based price modifier
     * Weekday (Mon-Thu) → -5%
     * Weekend (Fri-Sun) → +10%
     * Holiday → +20%
     */
    public Double getDayTypeModifier(LocalDate date) {
        DayOfWeek dayOfWeek = date.getDayOfWeek();

        if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
            return 0.10;  // Weekend: +10%
        } else if (isPublicHoliday(date)) {
            return 0.20;  // Holiday: +20%
        } else {
            return -0.05;  // Weekday: -5%
        }
    }

    /**
     * Calculate advance booking based price modifier
     * 60+ days ahead → -20%
     * 30-60 days ahead → -10%
     * 7-30 days ahead → 0%
     * <7 days ahead → +15%
     */
    public Double getAdvanceBookingModifier(LocalDate checkInDate) {
        long daysAhead = java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), checkInDate);

        if (daysAhead >= 60) {
            return -0.20;  // Wrapper class: Double autoboxing
        } else if (daysAhead >= 30) {
            return -0.10;
        } else if (daysAhead >= 7) {
            return 0.0;
        } else {
            return 0.15;
        }
    }

    /**
     * Calculate season based price modifier
     * Off-season (Jan, Feb, Sept) → -10%
     * Peak season (Dec, May, June) → +25%
     * Normal season → 0%
     */
    public Double getSeasonModifier(LocalDate date) {
        Month month = date.getMonth();

        switch (month) {
            case JANUARY:
            case FEBRUARY:
            case SEPTEMBER:
                return -0.10;  // Off-season
            case DECEMBER:
            case MAY:
            case JUNE:
                return 0.25;  // Peak season
            default:
                return 0.0;   // Normal season
        }
    }

    /**
     * Calculate occupancy-based modifier for specific room type
     */
    public Double getOccupancyModifierForRoomType(RoomType roomType) {
        java.util.List<Room> roomsByType = roomService.filterByRoomType(roomType);
        if (roomsByType.isEmpty()) {
            return 0.0;
        }

        long occupiedCount = roomsByType.stream()
                .filter(Room::isOccupied)
                .count();

        double occupancyRate = (occupiedCount * 100.0) / roomsByType.size();

        if (occupancyRate < 30) {
            return -0.15;
        } else if (occupancyRate < 60) {
            return 0.0;
        } else if (occupancyRate < 80) {
            return 0.15;
        } else {
            return 0.25;
        }
    }

    // ==================== Final Price Calculation ====================

    /**
     * Calculate final price with all modifiers
     * Final Price = Base Price × (1 + Occupancy%) × (1 + Day%) × (1 + Advance%) × (1 + Season%)
     */
    public Double calculateFinalPrice(int roomNumber, LocalDate checkInDate, long numberOfNights) {
        Double basePrice = getBasePrice(roomNumber);
        if (basePrice == null || basePrice <= 0) {
            return 0.0;  // Wrapper class: Double autoboxing
        }

        // Get all modifiers
        Double occupancyMod = getOccupancyModifier();
        Double dayTypeMod = getDayTypeModifier(checkInDate);
        Double advanceMod = getAdvanceBookingModifier(checkInDate);
        Double seasonMod = getSeasonModifier(checkInDate);

        // Calculate price per night with modifiers
        Double pricePerNight = basePrice * 
                (1 + occupancyMod) * 
                (1 + dayTypeMod) * 
                (1 + advanceMod) * 
                (1 + seasonMod);

        // Calculate total for all nights
        return pricePerNight * numberOfNights;
    }

    /**
     * Calculate final price with custom modifiers
     */
    public Double calculateFinalPriceWithCustomModifiers(int roomNumber, LocalDate checkInDate, 
                                                        long numberOfNights, Double customModifier) {
        Double basePrice = getBasePrice(roomNumber);
        if (basePrice == null || basePrice <= 0) {
            return 0.0;  // Wrapper class: Double autoboxing
        }

        // Get standard modifiers
        Double occupancyMod = getOccupancyModifier();
        Double dayTypeMod = getDayTypeModifier(checkInDate);
        Double advanceMod = getAdvanceBookingModifier(checkInDate);
        Double seasonMod = getSeasonModifier(checkInDate);

        // Calculate price per night with all modifiers
        Double pricePerNight = basePrice * 
                (1 + occupancyMod) * 
                (1 + dayTypeMod) * 
                (1 + advanceMod) * 
                (1 + seasonMod) *
                (1 + customModifier);

        return pricePerNight * numberOfNights;
    }

    /**
     * Get price breakdown for a booking
     */
    public String getPriceBreakdown(int roomNumber, LocalDate checkInDate, long numberOfNights) {
        Double basePrice = getBasePrice(roomNumber);
        Room room = roomService.getRoomByNumber(roomNumber);

        if (basePrice == null || room == null) {
            return "Room not found";
        }

        Double occupancyMod = getOccupancyModifier();
        Double dayTypeMod = getDayTypeModifier(checkInDate);
        Double advanceMod = getAdvanceBookingModifier(checkInDate);
        Double seasonMod = getSeasonModifier(checkInDate);

        Double finalPrice = calculateFinalPrice(roomNumber, checkInDate, numberOfNights);
        Double pricePerNight = finalPrice / numberOfNights;

        StringBuilder sb = new StringBuilder();
        sb.append("========== PRICE BREAKDOWN ==========\n");
        sb.append("Room: ").append(room.getRoomType().getDisplayName()).append(" (₹").append(basePrice).append("/night)\n");
        sb.append("Check-in: ").append(checkInDate).append("\n");
        sb.append("Number of nights: ").append(numberOfNights).append("\n");
        sb.append("\n--- PRICE MODIFIERS ---\n");
        sb.append(String.format("Base Price: ₹%.2f\n", basePrice));
        sb.append(String.format("Occupancy: %+.0f%% (%.2f%%)\n", occupancyMod * 100, getOccupancyPercentage()));
        sb.append(String.format("Day Type: %+.0f%% (%s)\n", dayTypeMod * 100, getDayTypeName(checkInDate)));
        sb.append(String.format("Advance Booking: %+.0f%%\n", advanceMod * 100));
        sb.append(String.format("Season: %+.0f%% (%s)\n", seasonMod * 100, getSeasonName(checkInDate)));
        sb.append(String.format("\nFinal Price per Night: ₹%.2f\n", pricePerNight));
        sb.append(String.format("Total for %d nights: ₹%.2f\n", numberOfNights, finalPrice));
        sb.append("====================================\n");

        return sb.toString();
    }

    // ==================== Helper Methods ====================

    /**
     * Check if a date is a public holiday (India)
     */
    private boolean isPublicHoliday(LocalDate date) {
        // Simple implementation - can be extended with actual holiday list
        Month month = date.getMonth();
        int dayOfMonth = date.getDayOfMonth();

        // Major Indian holidays (simplified)
        return (month == Month.JANUARY && dayOfMonth == 26) ||      // Republic Day
               (month == Month.MARCH && dayOfMonth == 8) ||         // Maha Shivaratri (approximate)
               (month == Month.MARCH && dayOfMonth == 25) ||        // Holi (approximate)
               (month == Month.APRIL && dayOfMonth == 14) ||        // Ambedkar Jayanti
               (month == Month.AUGUST && dayOfMonth == 15) ||       // Independence Day
               (month == Month.OCTOBER && dayOfMonth == 2) ||       // Gandhi Jayanti
               (month == Month.OCTOBER && dayOfMonth == 24) ||      // Diwali (approximate)
               (month == Month.DECEMBER && dayOfMonth == 25);       // Christmas
    }

    /**
     * Get day type name
     */
    private String getDayTypeName(LocalDate date) {
        DayOfWeek dayOfWeek = date.getDayOfWeek();
        if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
            return "Weekend";
        } else if (isPublicHoliday(date)) {
            return "Holiday";
        } else {
            return "Weekday";
        }
    }

    /**
     * Get season name
     */
    private String getSeasonName(LocalDate date) {
        Month month = date.getMonth();
        switch (month) {
            case JANUARY:
            case FEBRUARY:
            case SEPTEMBER:
                return "Off-Season";
            case DECEMBER:
            case MAY:
            case JUNE:
                return "Peak Season";
            default:
                return "Normal Season";
        }
    }

    /**
     * Get occupancy percentage
     */
    public Double getOccupancyPercentage() {
        return roomService.getOccupancyPercentage();
    }

    /**
     * Calculate discount amount from percentage
     */
    public Double calculateDiscountAmount(Double totalPrice, Double discountPercent) {
        return (totalPrice * discountPercent) / 100.0;
    }

    /**
     * Apply early bird discount (15% for 60+ days advance)
     */
    public Double getEarlyBirdDiscount(Double totalPrice, LocalDate checkInDate) {
        long daysAhead = java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), checkInDate);
        if (daysAhead >= 60) {
            return calculateDiscountAmount(totalPrice, 15.0);
        }
        return 0.0;  // Wrapper class: Double autoboxing
    }

    /**
     * Apply weekend surcharge
     */
    public Double getWeekendSurcharge(Double basePrice, LocalDate checkInDate) {
        DayOfWeek dayOfWeek = checkInDate.getDayOfWeek();
        if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
            return (basePrice * 10.0) / 100.0;  // 10% surcharge
        }
        return 0.0;  // Wrapper class: Double autoboxing
    }

    /**
     * Apply loyalty discount (percentage based on customer tier)
     */
    public Double getLoyaltyDiscount(Double totalPrice, LoyaltyTier tier) {
        Double discountPercent = 0.0;
        switch (tier) {
            case SILVER:
                discountPercent = 0.0;
                break;
            case GOLD:
                discountPercent = 5.0;
                break;
            case PLATINUM:
                discountPercent = 10.0;
                break;
        }
        return calculateDiscountAmount(totalPrice, discountPercent);
    }

    /**
     * Get price suggestions for similar room types
     */
    public java.util.Map<RoomType, Double> getSuggestedPricesForAllRoomTypes(LocalDate checkInDate, long numberOfNights) {
        java.util.Map<RoomType, Double> prices = new java.util.HashMap<>();  // Generics: Map<RoomType, Double>

        for (RoomType type : RoomType.values()) {
            java.util.List<Room> roomsOfType = roomService.filterByRoomType(type);
            if (!roomsOfType.isEmpty()) {
                Room room = roomsOfType.get(0);
                Double price = calculateFinalPrice(room.getRoomNumber(), checkInDate, numberOfNights);
                prices.put(type, price);
            }
        }

        return prices;
    }

    /**
     * Get cheapest room option
     */
    public Double getCheapestRoomPrice(LocalDate checkInDate, long numberOfNights) {
        Room cheapestRoom = roomService.getCheapestRoom();
        if (cheapestRoom == null) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        return calculateFinalPrice(cheapestRoom.getRoomNumber(), checkInDate, numberOfNights);
    }

    /**
     * Get most expensive room option
     */
    public Double getMostExpensiveRoomPrice(LocalDate checkInDate, long numberOfNights) {
        Room mostExpensiveRoom = roomService.getMostExpensiveRoom();
        if (mostExpensiveRoom == null) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        return calculateFinalPrice(mostExpensiveRoom.getRoomNumber(), checkInDate, numberOfNights);
    }
}