package com.hotel.services;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.hotel.models.*;

/**
 * ReportService Class
 * Handles analytics and report generation for admin dashboard
 */
public class ReportService {
    private RoomService roomService;
    private BookingService bookingService;
    private BillingService billingService;
    private BookingService bookingServiceRef;

    public ReportService(RoomService roomService, BookingService bookingService, BillingService billingService) {
        this.roomService = roomService;
        this.bookingService = bookingService;
        this.billingService = billingService;
        this.bookingServiceRef = bookingService;
    }

    // ==================== Dashboard Statistics ====================

    /**
     * Get total revenue
     */
    public Double getTotalRevenue() {
        return billingService.getTotalRevenue();
    }

    /**
     * Get occupancy percentage
     */
    public Double getOccupancyPercentage() {
        return roomService.getOccupancyPercentage();
    }

    /**
     * Get total guests (all bookings)
     */
    public Integer getTotalGuests() {
        return (int) bookingService.getAllBookings()
                .stream()
                .mapToInt(Booking::getNumberOfGuests)
                .sum();
    }

    /**
     * Get total bookings count
     */
    public Integer getTotalBookings() {
        return bookingService.getTotalBookingsCount();
    }

    /**
     * Get available rooms count
     */
    public Integer getAvailableRoomsCount() {
        return roomService.getAvailableRoomCount();
    }

    /**
     * Get occupied rooms count
     */
    public Integer getOccupiedRoomsCount() {
        return roomService.getOccupiedRoomCount();
    }

    /**
     * Get maintenance rooms count
     */
    public Integer getMaintenanceRoomsCount() {
        return roomService.getMaintenanceRoomCount();
    }

    /**
     * Get average room rating
     */
    public Double getAverageRoomRating() {
        return roomService.getAverageRoomRating();
    }

    /**
     * Get average booking value
     */
    public Double getAverageBookingValue() {
        return bookingService.getAverageBookingValue();
    }

    /**
     * Get average length of stay
     */
    public Double getAverageLengthOfStay() {
        return bookingService.getAverageLengthOfStay();
    }

    // ==================== Dashboard Summary ====================

    /**
     * Get comprehensive dashboard summary
     */
    public String getDashboardSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("========== DASHBOARD SUMMARY ==========\n");
        sb.append("\n--- KEY METRICS ---\n");
        sb.append(String.format("Total Revenue: ₹%.2f\n", getTotalRevenue()));
        sb.append(String.format("Total Bookings: %d\n", getTotalBookings()));
        sb.append(String.format("Total Guests: %d\n", getTotalGuests()));
        sb.append(String.format("Occupancy Rate: %.1f%%\n", getOccupancyPercentage()));
        sb.append(String.format("Average Booking Value: ₹%.2f\n", getAverageBookingValue()));
        sb.append(String.format("Average Length of Stay: %.1f nights\n", getAverageLengthOfStay()));
        
        sb.append("\n--- ROOM STATUS ---\n");
        sb.append(String.format("Available Rooms: %d\n", getAvailableRoomsCount()));
        sb.append(String.format("Occupied Rooms: %d\n", getOccupiedRoomsCount()));
        sb.append(String.format("Maintenance Rooms: %d\n", getMaintenanceRoomsCount()));
        sb.append(String.format("Total Rooms: %d\n", roomService.getTotalRoomCount()));
        
        sb.append("\n--- RATINGS ---\n");
        sb.append(String.format("Average Room Rating: %.1f/5.0\n", getAverageRoomRating()));
        
        sb.append("\n========================================\n");
        return sb.toString();
    }

    // ==================== Peak Hours & Analysis ====================

    /**
     * Get busiest days (which days have most bookings)
     */
    public Map<java.time.DayOfWeek, Integer> getBusiestDaysOfWeek() {
        return bookingService.getAllBookings()
                .stream()
                .collect(Collectors.groupingBy(
                        booking -> booking.getCheckInDate().getDayOfWeek(),
                        Collectors.collectingAndThen(Collectors.toList(), List::size)
                ));
    }

    /**
     * Get peak booking month
     */
    public Month getPeakBookingMonth() {
        return bookingService.getAllBookings()
                .stream()
                .collect(Collectors.groupingBy(
                        booking -> booking.getCheckInDate().getMonth(),
                        Collectors.counting()
                ))
                .entrySet()
                .stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    /**
     * Get booking count by month
     */
    public Map<Month, Long> getBookingsByMonth() {
        return bookingService.getAllBookings()
                .stream()
                .collect(Collectors.groupingBy(
                        booking -> booking.getCheckInDate().getMonth(),
                        Collectors.counting()
                ));
    }

    /**
     * Get room type popularity
     */
    public Map<RoomType, Integer> getRoomTypePopularity() {
        return bookingService.getBookingCountByRoomType();
    }

    /**
     * Get most booked room type
     */
    public RoomType getMostBookedRoomType() {
        return getRoomTypePopularity()
                .entrySet()
                .stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    /**
     * Get peak analysis report
     */
    public String getPeakAnalysisReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("========== PEAK ANALYSIS REPORT ==========\n");
        
        sb.append("\n--- BUSIEST DAYS OF WEEK ---\n");
        Map<java.time.DayOfWeek, Integer> busyDays = getBusiestDaysOfWeek();
        for (Map.Entry<java.time.DayOfWeek, Integer> entry : busyDays.entrySet()) {
            sb.append(entry.getKey()).append(": ").append(entry.getValue()).append(" bookings\n");
        }
        
        sb.append("\n--- PEAK MONTH ---\n");
        Month peakMonth = getPeakBookingMonth();
        if (peakMonth != null) {
            sb.append("Peak Month: ").append(peakMonth).append("\n");
        }
        
        sb.append("\n--- ROOM TYPE POPULARITY ---\n");
        Map<RoomType, Integer> typePopularity = getRoomTypePopularity();
        for (Map.Entry<RoomType, Integer> entry : typePopularity.entrySet()) {
            sb.append(entry.getKey().getDisplayName()).append(": ").append(entry.getValue()).append(" bookings\n");
        }
        
        sb.append("\n=========================================\n");
        return sb.toString();
    }

    // ==================== Revenue Analysis ====================

    /**
     * Get revenue by room type
     */
    public Map<RoomType, Double> getRevenueByRoomType() {
        Map<RoomType, Double> revenueMap = new HashMap<>();  // Generics: Map<RoomType, Double>
        
        for (RoomType type : RoomType.values()) {
            List<Room> rooms = roomService.filterByRoomType(type);
            Double revenue = 0.0;  // Wrapper class: Double autoboxing
            
            for (Room room : rooms) {
                List<Booking> bookings = bookingService.getBookingsByRoomNumber(room.getRoomNumber());
                revenue += bookings.stream()
                        .filter(b -> !b.isCancelled())
                        .mapToDouble(Booking::getFinalPrice)
                        .sum();
            }
            
            revenueMap.put(type, revenue);
        }
        
        return revenueMap;
    }

    /**
     * Get revenue by month
     */
    public Map<Month, Double> getRevenueByMonth() {
        return billingService.getAllInvoices()
                .stream()
                .filter(Invoice::isPaid)
                .collect(Collectors.groupingBy(
                        invoice -> invoice.getInvoiceDate().getMonth(),
                        Collectors.summingDouble(Invoice::getTotalAmount)
                ));
    }

    /**
     * Get top revenue generating rooms
     */
    public List<Room> getTopRevenueRooms(int limit) {
        Map<Integer, Double> roomRevenue = new HashMap<>();  // Generics: Map<Integer, Double>
        
        for (Room room : roomService.getAllRooms()) {
            List<Booking> bookings = bookingService.getBookingsByRoomNumber(room.getRoomNumber());
            Double revenue = bookings.stream()
                    .filter(b -> !b.isCancelled())
                    .mapToDouble(Booking::getFinalPrice)
                    .sum();
            roomRevenue.put(room.getRoomNumber(), revenue);
        }
        
        return roomRevenue.entrySet()
                .stream()
                .sorted(Map.Entry.<Integer, Double>comparingByValue().reversed())
                .limit(limit)
                .map(entry -> roomService.getRoomByNumber(entry.getKey()))
                .collect(Collectors.toList());
    }

    // ==================== Occupancy Analysis ====================

    /**
     * Get occupancy percentage by room type
     */
    public Map<RoomType, Double> getOccupancyByRoomType() {
        Map<RoomType, Double> occupancyMap = new HashMap<>();  // Generics: Map<RoomType, Double>
        
        for (RoomType type : RoomType.values()) {
            List<Room> rooms = roomService.filterByRoomType(type);
            if (rooms.isEmpty()) continue;
            
            long occupiedCount = rooms.stream()
                    .filter(Room::isOccupied)
                    .count();
            
            Double occupancyPercent = (occupiedCount * 100.0) / rooms.size();
            occupancyMap.put(type, occupancyPercent);
        }
        
        return occupancyMap;
    }

    /**
     * Get occupancy trend for date range
     */
    public Map<LocalDate, Double> getOccupancyTrend(LocalDate startDate, LocalDate endDate) {
        Map<LocalDate, Double> trend = new HashMap<>();  // Generics: Map<LocalDate, Double>
        
        for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
            LocalDate finalDate = date;
            
            long occupiedRooms = bookingService.getAllBookings()
                    .stream()
                    .filter(b -> !b.isCancelled())
                    .filter(b -> !finalDate.isBefore(b.getCheckInDate()) && !finalDate.isAfter(b.getCheckOutDate()))
                    .count();
            
            Double occupancyPercent = (occupiedRooms * 100.0) / roomService.getTotalRoomCount();
            trend.put(date, occupancyPercent);
        }
        
        return trend;
    }

    // ==================== Customer Analysis ====================

    /**
     * Get repeat customers
     */
    public List<Integer> getRepeatCustomers() {
        return bookingService.getAllBookings()
                .stream()
                .map(Booking::getCustomerId)
                .distinct()
                .filter(customerId -> {
                    List<Booking> customerBookings = bookingService.getBookingsByCustomerId(customerId);
                    return customerBookings.size() > 1;
                })
                .collect(Collectors.toList());
    }

    /**
     * Get total repeat customer bookings
     */
    public Integer getTotalRepeatCustomerBookings() {
        return (int) bookingService.getAllBookings()
                .stream()
                .filter(booking -> {
                    List<Booking> customerBookings = bookingService.getBookingsByCustomerId(booking.getCustomerId());
                    return customerBookings.size() > 1;
                })
                .count();
    }

    /**
     * Get repeat customer percentage
     */
    public Double getRepeatCustomerPercentage() {
        List<Integer> allCustomers = bookingService.getAllBookings()
                .stream()
                .map(Booking::getCustomerId)
                .distinct()
                .collect(Collectors.toList());
        
        if (allCustomers.isEmpty()) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        
        long repeatCount = allCustomers.stream()
                .filter(customerId -> {
                    List<Booking> customerBookings = bookingService.getBookingsByCustomerId(customerId);
                    return customerBookings.size() > 1;
                })
                .count();
        
        return (repeatCount * 100.0) / allCustomers.size();
    }

    /**
     * Get top customers by spending
     */
    public List<Integer> getTopCustomersBySpending(int limit) {
        Map<Integer, Double> customerSpending = new HashMap<>();  // Generics: Map<Integer, Double>
        
        for (Booking booking : bookingService.getAllBookings()) {
            if (!booking.isCancelled()) {
                customerSpending.merge(booking.getCustomerId(), booking.getFinalPrice(), Double::sum);
            }
        }
        
        return customerSpending.entrySet()
                .stream()
                .sorted(Map.Entry.<Integer, Double>comparingByValue().reversed())
                .limit(limit)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    // ==================== Cancellation Analysis ====================

    /**
     * Get cancellation rate percentage
     */
    public Double getCancellationRatePercentage() {
        long totalBookings = bookingService.getAllBookings().size();
        if (totalBookings == 0) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        
        long cancelledBookings = bookingService.getCancelledBookings().size();
        return (cancelledBookings * 100.0) / totalBookings;
    }

    /**
     * Get total refunded amount
     */
    public Double getTotalRefundedAmount() {
        return billingService.getTotalRefundedAmount();
    }

    /**
     * Get refund rate
     */
    public Double getRefundRate() {
        return (getTotalRefundedAmount() / getTotalRevenue()) * 100.0;
    }

    // ==================== Comprehensive Reports ====================

    /**
     * Get full admin report
     */
    public String getFullAdminReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("========== COMPREHENSIVE ADMIN REPORT ==========\n");
        sb.append(getDashboardSummary());
        sb.append(getPeakAnalysisReport());
        
        sb.append("\n--- REVENUE ANALYSIS ---\n");
        Map<RoomType, Double> revenueByType = getRevenueByRoomType();
        for (Map.Entry<RoomType, Double> entry : revenueByType.entrySet()) {
            sb.append(entry.getKey().getDisplayName()).append(": ₹")
                    .append(String.format("%.2f", entry.getValue())).append("\n");
        }
        
        sb.append("\n--- OCCUPANCY BY ROOM TYPE ---\n");
        Map<RoomType, Double> occupancyByType = getOccupancyByRoomType();
        for (Map.Entry<RoomType, Double> entry : occupancyByType.entrySet()) {
            sb.append(entry.getKey().getDisplayName()).append(": ")
                    .append(String.format("%.1f%%", entry.getValue())).append("\n");
        }
        
        sb.append("\n--- CUSTOMER INSIGHTS ---\n");
        sb.append("Repeat Customers: ").append(getRepeatCustomers().size()).append("\n");
        sb.append("Repeat Customer %: ").append(String.format("%.1f%%", getRepeatCustomerPercentage())).append("\n");
        
        sb.append("\n--- CANCELLATION ANALYSIS ---\n");
        sb.append("Cancellation Rate: ").append(String.format("%.1f%%", getCancellationRatePercentage())).append("\n");
        sb.append("Total Refunded: ₹").append(String.format("%.2f", getTotalRefundedAmount())).append("\n");
        
        sb.append("\n===============================================\n");
        return sb.toString();
    }
}