package com.hotel.services;

import com.hotel.models.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * UserService Class
 * Handles user authentication, registration, and account management
 */
public class UserService {
    private List<User> users;  // Collection: List for user storage
    private User currentLoggedInUser;

    public UserService() {
        this.users = new ArrayList<>();  // Generics: ArrayList<User>
        this.currentLoggedInUser = null;
        
        // Add default admin user
        initializeDefaultUsers();
    }

    // ==================== Initialization ====================

    /**
     * Initialize default users
     */
    private void initializeDefaultUsers() {
        // Add default admin user
        User admin = new User("admin", "admin123", "admin@hotel.com", "Administrator", UserRole.ADMIN);
        admin.setDepartment("Management");
        admin.setPhone("9999999999");
        users.add(admin);
        
        // Add sample customer
        User customer = new User("john_doe", "password123", "john@example.com", "John Doe", UserRole.CUSTOMER);
        customer.setPhone("9876543210");
        users.add(customer);
    }

    // ==================== Authentication ====================

    /**
     * Authenticate user (login)
     */
    public boolean authenticateUser(String username, String password) {
        User user = getUserByUsername(username);
        
        if (user == null) {
            return false;
        }

        // Check if account is locked
        if (user.isAccountLocked()) {
            return false;
        }

        // Check if account is active
        if (!user.getIsActive()) {
            return false;
        }

        // Validate password
        if (!user.validatePassword(password)) {
            user.recordFailedLoginAttempt();
            return false;
        }

        // Record successful login
        user.recordSuccessfulLogin();
        this.currentLoggedInUser = user;

        return true;
    }

    /**
     * Logout current user
     */
    public void logout() {
        this.currentLoggedInUser = null;
    }

    /**
     * Get currently logged-in user
     */
    public User getCurrentLoggedInUser() {
        return currentLoggedInUser;
    }

    /**
     * Check if user is logged in
     */
    public boolean isUserLoggedIn() {
        return currentLoggedInUser != null;
    }

    /**
     * Check if logged-in user is admin
     */
    public boolean isAdminLoggedIn() {
        return currentLoggedInUser != null && currentLoggedInUser.isAdmin();
    }

    /**
     * Check if logged-in user is customer
     */
    public boolean isCustomerLoggedIn() {
        return currentLoggedInUser != null && currentLoggedInUser.isCustomer();
    }

    // ==================== User CRUD Operations ====================

    /**
     * Register new user
     */
    public boolean registerUser(String username, String password, String email, String fullName, UserRole role) {
        // Check if username already exists
        if (getUserByUsername(username) != null) {
            return false;
        }

        // Validate inputs
        if (username == null || username.length() < 3 || password == null || password.length() < 8) {
            return false;
        }

        User newUser = new User(username, password, email, fullName, role);
        
        // Validate
        if (!newUser.validateEmail() || !newUser.validateUsername() || !newUser.validatePassword()) {
            return false;
        }

        return users.add(newUser);
    }

    /**
     * Get user by username
     */
    public User getUserByUsername(String username) {
        return users.stream()  // Generics & Stream API
                .filter(user -> user.getUsername().equalsIgnoreCase(username))
                .findFirst()
                .orElse(null);
    }

    /**
     * Get user by ID
     */
    public User getUserById(int userId) {
        return users.stream()
                .filter(user -> user.getUserId() == userId)
                .findFirst()
                .orElse(null);
    }

    /**
     * Get user by email
     */
    public User getUserByEmail(String email) {
        return users.stream()
                .filter(user -> user.getEmail().equalsIgnoreCase(email))
                .findFirst()
                .orElse(null);
    }

    /**
     * Get all users
     */
    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }

    /**
     * Get all admin users
     */
    public List<User> getAllAdmins() {
        return users.stream()
                .filter(User::isAdmin)
                .collect(Collectors.toList());
    }

    /**
     * Get all customer users
     */
    public List<User> getAllCustomers() {
        return users.stream()
                .filter(User::isCustomer)
                .collect(Collectors.toList());
    }

    /**
     * Update user profile
     */
    public boolean updateUserProfile(int userId, String fullName, String email, String phone, String department) {
        User user = getUserById(userId);
        if (user == null) {
            return false;
        }

        user.setFullName(fullName);
        user.setEmail(email);
        user.setPhone(phone);
        user.setDepartment(department);

        return true;
    }

    /**
     * Change user password
     */
    public boolean changePassword(int userId, String oldPassword, String newPassword) {
        User user = getUserById(userId);
        if (user == null || newPassword.length() < 8) {
            return false;
        }

        return user.changePassword(oldPassword, newPassword);
    }

    /**
     * Deactivate user account
     */
    public boolean deactivateUser(int userId) {
        User user = getUserById(userId);
        if (user == null) {
            return false;
        }

        user.setIsActive(false);
        return true;
    }

    /**
     * Activate user account
     */
    public boolean activateUser(int userId) {
        User user = getUserById(userId);
        if (user == null) {
            return false;
        }

        user.setIsActive(true);
        return true;
    }

    /**
     * Delete user
     */
    public boolean deleteUser(int userId) {
        return users.removeIf(user -> user.getUserId() == userId);
    }

    // ==================== Account Locking ====================

    /**
     * Unlock user account
     */
    public boolean unlockUserAccount(int userId) {
        User user = getUserById(userId);
        if (user == null) {
            return false;
        }

        user.unlockAccount();
        return true;
    }

    /**
     * Get locked users
     */
    public List<User> getLockedUsers() {
        return users.stream()
                .filter(User::isAccountLocked)
                .collect(Collectors.toList());
    }

    /**
     * Check if user account is locked
     */
    public boolean isUserAccountLocked(String username) {
        User user = getUserByUsername(username);
        return user != null && user.isAccountLocked();
    }

    // ==================== Session Management ====================

    /**
     * Get current user role
     */
    public UserRole getCurrentUserRole() {
        if (currentLoggedInUser == null) {
            return null;
        }
        return currentLoggedInUser.getRole();
    }

    /**
     * Check permission (admin only)
     */
    public boolean hasAdminPermission() {
        return currentLoggedInUser != null && currentLoggedInUser.isAdmin();
    }

    /**
     * Check permission (customer or admin)
     */
    public boolean hasCustomerPermission() {
        return currentLoggedInUser != null;
    }

    /**
     * Get current user info
     */
    public String getCurrentUserInfo() {
        if (currentLoggedInUser == null) {
            return "No user logged in";
        }
        return currentLoggedInUser.getUserSummary();
    }

    // ==================== Validation ====================

    /**
     * Validate username format
     */
    public boolean isValidUsername(String username) {
        return username != null && username.length() >= 3 && username.length() <= 20;
    }

    /**
     * Validate password strength
     */
    public boolean isValidPassword(String password) {
        return password != null && password.length() >= 8;
    }

    /**
     * Validate email format
     */
    public boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

    /**
     * Check if username is available
     */
    public boolean isUsernameAvailable(String username) {
        return getUserByUsername(username) == null;
    }

    /**
     * Check if email is available
     */
    public boolean isEmailAvailable(String email) {
        return getUserByEmail(email) == null;
    }

    // ==================== Statistics ====================

    /**
     * Get total user count
     */
    public int getTotalUserCount() {
        return users.size();
    }

    /**
     * Get admin count
     */
    public int getAdminCount() {
        return (int) users.stream()
                .filter(User::isAdmin)
                .count();
    }

    /**
     * Get customer count
     */
    public int getCustomerCount() {
        return (int) users.stream()
                .filter(User::isCustomer)
                .count();
    }

    /**
     * Get active user count
     */
    public int getActiveUserCount() {
        return (int) users.stream()
                .filter(User::getIsActive)
                .count();
    }

    /**
     * Get inactive user count
     */
    public int getInactiveUserCount() {
        return (int) users.stream()
                .filter(user -> !user.getIsActive())
                .count();
    }

    /**
     * Get locked user count
     */
    public int getLockedUserCount() {
        return (int) users.stream()
                .filter(User::isAccountLocked)
                .count();
    }

    /**
     * Get users by activity (active users)
     */
    public List<User> getActiveUsers() {
        return users.stream()
                .filter(User::getIsActive)
                .collect(Collectors.toList());
    }

    /**
     * Get users by activity (inactive users)
     */
    public List<User> getInactiveUsers() {
        return users.stream()
                .filter(user -> !user.getIsActive())
                .collect(Collectors.toList());
    }

    /**
     * Get users who have never logged in
     */
    public List<User> getNeverLoggedInUsers() {
        return users.stream()
                .filter(user -> user.getLastLoginDate() == null)
                .collect(Collectors.toList());
    }

    /**
     * Get user summary report
     */
    public String getUserSummaryReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("========== USER SUMMARY REPORT ==========\n");
        sb.append("Total Users: ").append(getTotalUserCount()).append("\n");
        sb.append("Admins: ").append(getAdminCount()).append("\n");
        sb.append("Customers: ").append(getCustomerCount()).append("\n");
        sb.append("Active Users: ").append(getActiveUserCount()).append("\n");
        sb.append("Inactive Users: ").append(getInactiveUserCount()).append("\n");
        sb.append("Locked Accounts: ").append(getLockedUserCount()).append("\n");
        sb.append("Never Logged In: ").append(getNeverLoggedInUsers().size()).append("\n");
        sb.append("=========================================\n");
        return sb.toString();
    }

    /**
     * Get all users list with details
     */
    public String getAllUsersDetails() {
        StringBuilder sb = new StringBuilder();
        sb.append("========== ALL USERS ==========\n");
        
        for (User user : users) {
            sb.append("ID: ").append(user.getUserId())
                    .append(" | Username: ").append(user.getUsername())
                    .append(" | Role: ").append(user.getRole().getDisplayName())
                    .append(" | Status: ").append(user.getIsActive() ? "Active" : "Inactive")
                    .append(" | Email: ").append(user.getEmail())
                    .append("\n");
        }
        
        sb.append("===============================\n");
        return sb.toString();
    }

    /**
     * Reset failed login attempts
     */
    public boolean resetFailedLoginAttempts(int userId) {
        User user = getUserById(userId);
        if (user == null) {
            return false;
        }

        user.setLoginAttempts(0);  // Wrapper class: Integer autoboxing
        return true;
    }
}