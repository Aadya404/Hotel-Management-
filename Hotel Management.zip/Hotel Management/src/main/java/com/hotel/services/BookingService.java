package com.hotel.services;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.hotel.models.Booking;
import com.hotel.models.BookingStatus;
import com.hotel.models.RefundPolicy;
import com.hotel.models.Room;
import com.hotel.models.RoomType;

/**
 * BookingService Class
 
 */
public class BookingService {
    private List<Booking> bookings;  // Collection: List for booking storage
    private RoomService roomService;

    public BookingService(RoomService roomService) {
        this.bookings = new ArrayList<>();  // Generics: ArrayList<Booking>
        this.roomService = roomService;
    }

    
    /**
     * Create a new booking
     */
    public Booking createBooking(int customerId, int roomNumber, LocalDate checkInDate, 
                                 LocalDate checkOutDate, Integer numberOfGuests) {
        // Validate inputs
        if (checkInDate.isAfter(checkOutDate) || checkInDate.isBefore(LocalDate.now())) {
            return null;
        }

        // Check if room is available
        Room room = roomService.getRoomByNumber(roomNumber);
        if (room == null || !room.isAvailable()) {
            return null;
        }

        // Create booking
        Booking booking = new Booking(customerId, roomNumber, checkInDate, checkOutDate, numberOfGuests);
        booking.setBasePrice(room.getPricePerDay());
        bookings.add(booking);

        return booking;
    }

    /**
     * Get booking by ID
     */
    public Booking getBookingById(int bookingId) {
        return bookings.stream()
                .filter(booking -> booking.getBookingId() == bookingId)
                .findFirst()
                .orElse(null);
    }

    /**
     * Get all bookings
     */
    public List<Booking> getAllBookings() {
        return new ArrayList<>(bookings);
    }

    /**
     * Get bookings by customer ID
     */
    public List<Booking> getBookingsByCustomerId(int customerId) {
        return bookings.stream()  // Generics & Stream API
                .filter(booking -> booking.getCustomerId() == customerId)
                .collect(Collectors.toList());
    }

    /**
     * Get bookings by room number
     */
    public List<Booking> getBookingsByRoomNumber(int roomNumber) {
        return bookings.stream()
                .filter(booking -> booking.getRoomNumber() == roomNumber)
                .collect(Collectors.toList());
    }

    /**
     * Update booking
     */
    public boolean updateBooking(Booking booking) {
        Booking existing = getBookingById(booking.getBookingId());
        if (existing == null) {
            return false;
        }
        
        existing.setCheckInDate(booking.getCheckInDate());
        existing.setCheckOutDate(booking.getCheckOutDate());
        existing.setNumberOfGuests(booking.getNumberOfGuests());
        existing.setBookingNotes(booking.getBookingNotes());
        
        return true;
    }

    /**
     * Delete booking
     */
    public boolean deleteBooking(int bookingId) {
        return bookings.removeIf(booking -> booking.getBookingId() == bookingId);
    }

    /**
     * Booking exists
     */
    public boolean bookingExists(int bookingId) {
        return bookings.stream()
                .anyMatch(booking -> booking.getBookingId() == bookingId);
    }

    // ==================== Check-in/Check-out Operations ====================

    /**
     * Check-in a guest
     */
    public boolean checkIn(int bookingId) {
        Booking booking = getBookingById(bookingId);
        if (booking == null || !booking.getStatus().equals(BookingStatus.CONFIRMED)) {
            return false;
        }

        booking.checkIn();
        roomService.markRoomOccupied(booking.getRoomNumber());

        return true;
    }

    /**
     * Check-out a guest
     */
    public boolean checkOut(int bookingId) {
        Booking booking = getBookingById(bookingId);
        if (booking == null || !booking.isCheckedIn()) {
            return false;
        }

        booking.checkOut();
        roomService.markRoomAvailable(booking.getRoomNumber());

        return true;
    }

    /**
     * Get duration of stay
     */
    public String getStayDuration(int bookingId) {
        Booking booking = getBookingById(bookingId);
        if (booking == null) {
            return "N/A";
        }
        return booking.getDurationString();
    }

    /**
     * Get number of nights
     */
    public long getNumberOfNights(int bookingId) {
        Booking booking = getBookingById(bookingId);
        if (booking == null) {
            return 0;
        }
        return ChronoUnit.DAYS.between(booking.getCheckInDate(), booking.getCheckOutDate());
    }

    // ==================== Booking Status Operations ====================

    /**
     * Confirm booking
     */
    public boolean confirmBooking(int bookingId) {
        Booking booking = getBookingById(bookingId);
        if (booking == null || !booking.getStatus().equals(BookingStatus.PENDING)) {
            return false;
        }

        booking.confirmBooking();
        return true;
    }

    /**
     * Get bookings by status
     */
    public List<Booking> getBookingsByStatus(BookingStatus status) {
        return bookings.stream()
                .filter(booking -> booking.getStatus() == status)
                .collect(Collectors.toList());
    }

    /**
     * Get pending bookings
     */
    public List<Booking> getPendingBookings() {
        return getBookingsByStatus(BookingStatus.PENDING);
    }

    /**
     * Get confirmed bookings
     */
    public List<Booking> getConfirmedBookings() {
        return getBookingsByStatus(BookingStatus.CONFIRMED);
    }

    /**
     * Get checked-in bookings
     */
    public List<Booking> getCheckedInBookings() {
        return getBookingsByStatus(BookingStatus.CHECKED_IN);
    }

    /**
     * Get checked-out bookings
     */
    public List<Booking> getCheckedOutBookings() {
        return getBookingsByStatus(BookingStatus.CHECKED_OUT);
    }

    /**
     * Get cancelled bookings
     */
    public List<Booking> getCancelledBookings() {
        return getBookingsByStatus(BookingStatus.CANCELLED);
    }

    // ==================== Cancellation Operations ====================

    /**
     * Cancel booking with smart refund policy
     */
    public boolean cancelBooking(int bookingId, String reason) {
        Booking booking = getBookingById(bookingId);
        if (booking == null || !booking.canBeCancelled()) {
            return false;
        }

        // Get applicable refund policy based on cancellation timing
        RefundPolicy refundPolicy = booking.getApplicableRefundPolicy();

        // Cancel the booking
        booking.cancelBooking(reason, refundPolicy);

        // Release the room
        roomService.markRoomAvailable(booking.getRoomNumber());

        return true;
    }

    /**
     * Get refund amount for a booking
     */
    public Double getRefundAmount(int bookingId) {
        Booking booking = getBookingById(bookingId);
        if (booking == null || !booking.isCancelled()) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        return booking.getRefundAmount();
    }

    /**
     * Get refund policy for a booking
     */
    public RefundPolicy getRefundPolicy(int bookingId) {
        Booking booking = getBookingById(bookingId);
        if (booking == null) {
            return RefundPolicy.NO_REFUND;
        }
        return booking.getRefundPolicy();
    }

    /**
     * Days until check-in
     */
    public long getDaysUntilCheckIn(int bookingId) {
        Booking booking = getBookingById(bookingId);
        if (booking == null) {
            return 0;
        }
        return ChronoUnit.DAYS.between(LocalDate.now(), booking.getCheckInDate());
    }

    /**
     * Can booking be cancelled (based on refund policy)
     */
    public boolean canCancelWithFullRefund(int bookingId) {
        long daysUntilCheckIn = getDaysUntilCheckIn(bookingId);
        return daysUntilCheckIn >= 30;
    }

    // ==================== Availability Check ====================

    /**
     * Check if room is available for dates
     */
    public boolean isRoomAvailableForDates(int roomNumber, LocalDate checkInDate, LocalDate checkOutDate) {
        // Get room
        Room room = roomService.getRoomByNumber(roomNumber);
        if (room == null || !room.isAvailable()) {
            return false;
        }

        // Check for overlapping bookings
        List<Booking> roomBookings = getBookingsByRoomNumber(roomNumber);
        
        for (Booking booking : roomBookings) {
            // Skip cancelled bookings
            if (booking.isCancelled()) {
                continue;
            }

            // Check for date overlap
            if (!(checkOutDate.isBefore(booking.getCheckInDate()) || 
                  checkInDate.isAfter(booking.getCheckOutDate()))) {
                return false;  // Dates overlap
            }
        }

        return true;
    }

    /**
     * Get next available date for a room
     */
    public LocalDate getNextAvailableDate(int roomNumber) {
        List<Booking> roomBookings = getBookingsByRoomNumber(roomNumber)
                .stream()
                .filter(b -> !b.isCancelled())
                .sorted(Comparator.comparing(Booking::getCheckOutDate))
                .collect(Collectors.toList());

        if (roomBookings.isEmpty()) {
            return LocalDate.now();
        }

        return roomBookings.get(roomBookings.size() - 1).getCheckOutDate();
    }

    /**
     * Find alternative rooms for given dates
     */
    public List<Room> findAlternativeRooms(int roomNumber, LocalDate checkInDate, LocalDate checkOutDate) {
        Room originalRoom = roomService.getRoomByNumber(roomNumber);
        if (originalRoom == null) {
            return new ArrayList<>();
        }

        return roomService.getAllRooms()
                .stream()
                .filter(room -> room.getRoomType() == originalRoom.getRoomType())
                .filter(room -> isRoomAvailableForDates(room.getRoomNumber(), checkInDate, checkOutDate))
                .collect(Collectors.toList());
    }

    // ==================== Statistics Operations ====================

    /**
     * Get total bookings count
     */
    public int getTotalBookingsCount() {
        return bookings.size();
    }

    /**
     * Get pending bookings count
     */
    public int getPendingBookingsCount() {
        return (int) bookings.stream()
                .filter(b -> b.getStatus() == BookingStatus.PENDING)
                .count();
    }

    /**
     * Get confirmed bookings count
     */
    public int getConfirmedBookingsCount() {
        return (int) bookings.stream()
                .filter(b -> b.getStatus() == BookingStatus.CONFIRMED)
                .count();
    }

    /**
     * Get checked-in bookings count
     */
    public int getCheckedInBookingsCount() {
        return (int) bookings.stream()
                .filter(b -> b.getStatus() == BookingStatus.CHECKED_IN)
                .count();
    }

    /**
     * Get total revenue from all bookings
     */
    public Double getTotalRevenue() {
        return bookings.stream()
                .mapToDouble(Booking::getFinalPrice)
                .sum();
    }

    /**
     * Get average booking value
     */
    public Double getAverageBookingValue() {
        if (bookings.isEmpty()) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        return getTotalRevenue() / bookings.size();
    }

    /**
     * Get total refunded amount
     */
    public Double getTotalRefundedAmount() {
        return bookings.stream()
                .filter(Booking::isCancelled)
                .mapToDouble(Booking::getRefundAmount)
                .sum();
    }

    /**
     * Get booking count by room type
     */
    public Map<RoomType, Integer> getBookingCountByRoomType() {
        return bookings.stream()
                .filter(b -> !b.isCancelled())
                .collect(Collectors.groupingBy(
                        booking -> roomService.getRoomByNumber(booking.getRoomNumber()).getRoomType(),
                        Collectors.collectingAndThen(Collectors.toList(), List::size)
                ));
    }

    /**
     * Get average length of stay
     */
    public Double getAverageLengthOfStay() {
        if (bookings.isEmpty()) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        return bookings.stream()
                .mapToLong(b -> ChronoUnit.DAYS.between(b.getCheckInDate(), b.getCheckOutDate()))
                .average()
                .orElse(0.0);
    }

    /**
     * Get repeat customer bookings
     */
    public List<Booking> getRepeatCustomerBookings(int customerId) {
        return getBookingsByCustomerId(customerId)
                .stream()
                .filter(b -> !b.isCancelled())
                .sorted(Comparator.comparing(Booking::getBookingDate).reversed())
                .collect(Collectors.toList());
    }

    /**
     * Get upcoming bookings
     */
    public List<Booking> getUpcomingBookings() {
        return bookings.stream()
                .filter(Booking::isUpcoming)
                .sorted(Comparator.comparing(Booking::getCheckInDate))
                .collect(Collectors.toList());
    }

    /**
     * Get ongoing bookings
     */
    public List<Booking> getOngoingBookings() {
        return bookings.stream()
                .filter(Booking::isOngoing)
                .collect(Collectors.toList());
    }

    /**
     * Get bookings for date range
     */
    public List<Booking> getBookingsForDateRange(LocalDate startDate, LocalDate endDate) {
        return bookings.stream()
                .filter(b -> !b.getCheckInDate().isAfter(endDate) && !b.getCheckOutDate().isBefore(startDate))
                .collect(Collectors.toList());
    }

    // ==================== Pricing Operations ====================

    /**
     * Set final price for booking
     */
    public void setBookingFinalPrice(int bookingId, Double finalPrice) {
        Booking booking = getBookingById(bookingId);
        if (booking != null) {
            booking.setFinalPrice(finalPrice);
        }
    }

    /**
     * Apply discount to booking
     */
    public void applyDiscount(int bookingId, Double discountAmount) {
        Booking booking = getBookingById(bookingId);
        if (booking != null) {
            booking.setDiscountApplied(discountAmount);
            Double newPrice = booking.getFinalPrice() - discountAmount;
            booking.setFinalPrice(Math.max(0, newPrice));
        }
    }
    public void loadBookingDirectly(Booking booking) {
    if (booking != null && !bookingExists(booking.getBookingId())) {
        bookings.add(booking);
    }
}

    /**
     * Apply loyalty points redemption
     */
    public void applyLoyaltyDiscount(int bookingId, Double pointsValue) {
        Booking booking = getBookingById(bookingId);
        if (booking != null) {
            booking.setLoyaltyPointsRedeemed(pointsValue);
            Double newPrice = booking.getFinalPrice() - pointsValue;
            booking.setFinalPrice(Math.max(0, newPrice));
        }
    }
}