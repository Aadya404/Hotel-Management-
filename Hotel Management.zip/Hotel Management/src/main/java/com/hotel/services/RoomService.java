package com.hotel.services;

import com.hotel.models.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * RoomService Class
 * Handles all room-related operations including CRUD, search, filter, and availability management
 */
public class RoomService {
    private List<Room> rooms;  // Collection: List for room storage

    public RoomService() {
        this.rooms = new ArrayList<>();  // Generics: ArrayList<Room>
    }

    // ==================== CRUD Operations ====================

    /**
     * Add a new room to the system
     */
    public boolean addRoom(Room room) {
        if (room == null || roomExists(room.getRoomNumber())) {
            return false;
        }
        return rooms.add(room);
    }

    /**
     * Get room by room number
     */
    public Room getRoomByNumber(int roomNumber) {
        return rooms.stream()
                .filter(room -> room.getRoomNumber() == roomNumber)
                .findFirst()
                .orElse(null);
    }

    /**
     * Get all rooms
     */
    public List<Room> getAllRooms() {
        return new ArrayList<>(rooms);  // Return copy to prevent external modification
    }

    /**
     * Update room details
     */
    public boolean updateRoom(Room room) {
        Room existingRoom = getRoomByNumber(room.getRoomNumber());
        if (existingRoom == null) {
            return false;
        }
        
        // Update all properties
        existingRoom.setRoomType(room.getRoomType());
        existingRoom.setRoomCategory(room.getRoomCategory());
        existingRoom.setPricePerDay(room.getPricePerDay());
        existingRoom.setDescription(room.getDescription());
        existingRoom.setAmenities(room.getAmenities());
        
        return true;
    }

    /**
     * Delete a room
     */
    public boolean deleteRoom(int roomNumber) {
        return rooms.removeIf(room -> room.getRoomNumber() == roomNumber);
    }

    /**
     * Check if room exists
     */
    public boolean roomExists(int roomNumber) {
        return rooms.stream()
                .anyMatch(room -> room.getRoomNumber() == roomNumber);
    }

    // ==================== Availability Operations ====================

    /**
     * Get all available rooms
     */
    public List<Room> getAvailableRooms() {
        return rooms.stream()  // Generics & Stream API
                .filter(Room::isAvailable)
                .collect(Collectors.toList());
    }

    /**
     * Get occupied rooms
     */
    public List<Room> getOccupiedRooms() {
        return rooms.stream()
                .filter(Room::isOccupied)
                .collect(Collectors.toList());
    }

    /**
     * Get rooms under maintenance
     */
    public List<Room> getMaintenanceRooms() {
        return rooms.stream()
                .filter(Room::isUnderMaintenance)
                .collect(Collectors.toList());
    }

    /**
     * Mark room as occupied
     */
    public boolean markRoomOccupied(int roomNumber) {
        Room room = getRoomByNumber(roomNumber);
        if (room != null) {
            room.markAsOccupied();
            return true;
        }
        return false;
    }

    /**
     * Mark room as available
     */
    public boolean markRoomAvailable(int roomNumber) {
        Room room = getRoomByNumber(roomNumber);
        if (room != null) {
            room.markAsAvailable();
            return true;
        }
        return false;
    }

    /**
     * Mark room as maintenance
     */
    public boolean markRoomMaintenance(int roomNumber, String reason, java.time.LocalDate until) {
        Room room = getRoomByNumber(roomNumber);
        if (room != null) {
            room.markAsMaintenance(reason, until);
            return true;
        }
        return false;
    }

    // ==================== Filter & Search Operations ====================

    /**
     * Filter rooms by type
     */
    public List<Room> filterByRoomType(RoomType type) {
        return rooms.stream()
                .filter(room -> room.getRoomType() == type)
                .collect(Collectors.toList());
    }

    /**
     * Filter rooms by category
     */
    public List<Room> filterByRoomCategory(RoomCategory category) {
        return rooms.stream()
                .filter(room -> room.getRoomCategory() == category)
                .collect(Collectors.toList());
    }

    /**
     * Filter rooms by price range
     */
    public List<Room> filterByPriceRange(Double minPrice, Double maxPrice) {
        return rooms.stream()
                .filter(room -> room.getPricePerDay() >= minPrice && room.getPricePerDay() <= maxPrice)
                .collect(Collectors.toList());
    }

    /**
     * Filter rooms by status
     */
    public List<Room> filterByStatus(AvailabilityStatus status) {
        return rooms.stream()
                .filter(room -> room.getStatus() == status)
                .collect(Collectors.toList());
    }

    /**
     * Filter rooms by capacity (adults + children)
     */
    public List<Room> filterByCapacity(int adults, int children) {
        return rooms.stream()
                .filter(room -> room.getRoomType().getMaxAdults() >= adults && 
                              room.getRoomType().getMaxChildren() >= children)
                .collect(Collectors.toList());
    }

    /**
     * Filter rooms by amenity
     */
    public List<Room> filterByAmenity(AmenityType amenity) {
        return rooms.stream()
                .filter(room -> room.hasAmenity(amenity))
                .collect(Collectors.toList());
    }

    /**
     * Filter by multiple amenities
     */
    public List<Room> filterByMultipleAmenities(Set<AmenityType> amenities) {
        return rooms.stream()
                .filter(room -> amenities.stream().allMatch(room::hasAmenity))
                .collect(Collectors.toList());
    }

    /**
     * Filter by rating
     */
    public List<Room> filterByMinimumRating(double minRating) {
        return rooms.stream()
                .filter(room -> room.getAverageRating() >= minRating)
                .collect(Collectors.toList());
    }

    /**
     * Search rooms by multiple criteria
     */
    public List<Room> searchRooms(RoomType type, Double maxPrice, int minCapacity) {
        return rooms.stream()
                .filter(room -> room.getRoomType() == type)
                .filter(room -> room.getPricePerDay() <= maxPrice)
                .filter(room -> room.getRoomType().getMaxAdults() >= minCapacity)
                .filter(Room::isAvailable)
                .collect(Collectors.toList());
    }

    // ==================== Sorting Operations ====================

    /**
     * Get rooms sorted by price (ascending)
     */
    public List<Room> getRoomsSortedByPrice() {
        return rooms.stream()
                .sorted(Comparator.comparingDouble(Room::getPricePerDay))
                .collect(Collectors.toList());
    }

    /**
     * Get rooms sorted by price (descending)
     */
    public List<Room> getRoomsSortedByPriceDescending() {
        return rooms.stream()
                .sorted(Comparator.comparingDouble(Room::getPricePerDay).reversed())
                .collect(Collectors.toList());
    }

    /**
     * Get rooms sorted by rating
     */
    public List<Room> getRoomsSortedByRating() {
        return rooms.stream()
                .sorted(Comparator.comparingDouble(Room::getAverageRating).reversed())
                .collect(Collectors.toList());
    }

    /**
     * Get rooms sorted by room number
     */
    public List<Room> getRoomsSortedByNumber() {
        return rooms.stream()
                .sorted(Comparator.comparingInt(Room::getRoomNumber))
                .collect(Collectors.toList());
    }

    // ==================== Statistics Operations ====================

    /**
     * Get total number of rooms
     */
    public int getTotalRoomCount() {
        return rooms.size();
    }

    /**
     * Get available room count
     */
    public int getAvailableRoomCount() {
        return (int) rooms.stream()
                .filter(Room::isAvailable)
                .count();
    }

    /**
     * Get occupied room count
     */
    public int getOccupiedRoomCount() {
        return (int) rooms.stream()
                .filter(Room::isOccupied)
                .count();
    }

    /**
     * Get maintenance room count
     */
    public int getMaintenanceRoomCount() {
        return (int) rooms.stream()
                .filter(Room::isUnderMaintenance)
                .count();
    }

    /**
     * Get occupancy percentage
     */
    public Double getOccupancyPercentage() {
        if (rooms.isEmpty()) {
            return 0.0;  // Wrapper class: Double autoboxing
        }
        long occupiedCount = rooms.stream()
                .filter(Room::isOccupied)
                .count();
        return (occupiedCount * 100.0) / rooms.size();
    }

    /**
     * Get average room price
     */
    public Double getAverageRoomPrice() {
        return rooms.stream()  // Generics & Stream
                .mapToDouble(Room::getPricePerDay)
                .average()
                .orElse(0.0);
    }

    /**
     * Get average room rating
     */
    public Double getAverageRoomRating() {
        return rooms.stream()
                .mapToDouble(Room::getAverageRating)
                .average()
                .orElse(0.0);
    }

    /**
     * Get most expensive room
     */
    public Room getMostExpensiveRoom() {
        return rooms.stream()
                .max(Comparator.comparingDouble(Room::getPricePerDay))
                .orElse(null);
    }

    /**
     * Get cheapest room
     */
    public Room getCheapestRoom() {
        return rooms.stream()
                .min(Comparator.comparingDouble(Room::getPricePerDay))
                .orElse(null);
    }

    /**
     * Get highest rated room
     */
    public Room getHighestRatedRoom() {
        return rooms.stream()
                .max(Comparator.comparingDouble(Room::getAverageRating))
                .orElse(null);
    }

    /**
     * Get room count by type
     */
    public Map<RoomType, Integer> getRoomCountByType() {
        return rooms.stream()
                .collect(Collectors.groupingBy(
                        Room::getRoomType,
                        Collectors.collectingAndThen(
                                Collectors.toList(),
                                List::size
                        )
                ));
    }

    /**
     * Get total rooms by price range
     */
    public int getRoomCountByPriceRange(Double minPrice, Double maxPrice) {
        return (int) rooms.stream()
                .filter(room -> room.getPricePerDay() >= minPrice && room.getPricePerDay() <= maxPrice)
                .count();
    }

    // ==================== Amenity Operations ====================

    /**
     * Add amenity to room
     */
    public boolean addAmenityToRoom(int roomNumber, AmenityType amenity) {
        Room room = getRoomByNumber(roomNumber);
        if (room != null) {
            room.addAmenity(amenity);
            return true;
        }
        return false;
    }

    /**
     * Remove amenity from room
     */
    public boolean removeAmenityFromRoom(int roomNumber, AmenityType amenity) {
        Room room = getRoomByNumber(roomNumber);
        if (room != null) {
            room.removeAmenity(amenity);
            return true;
        }
        return false;
    }

    // ==================== Rating Operations ====================

    /**
     * Add rating to room
     */
    public boolean addRatingToRoom(int roomNumber, double rating) {
        Room room = getRoomByNumber(roomNumber);
        if (room != null && rating >= 1.0 && rating <= 5.0) {
            room.addRating(rating);
            return true;
        }
        return false;
    }

    /**
     * Get rooms with good ratings (>=4.0)
     */
    public List<Room> getHighlyRatedRooms() {
        return rooms.stream()
                .filter(room -> room.getAverageRating() >= 4.0)
                .collect(Collectors.toList());
    }

    /**
     * Get rooms with poor ratings (<3.0)
     */
    public List<Room> getPoorlyRatedRooms() {
        return rooms.stream()
                .filter(room -> room.getAverageRating() < 3.0 && room.getRatingCount() > 0)
                .collect(Collectors.toList());
    }

    // ==================== Batch Operations ====================

    /**
     * Clear all rooms (dangerous - use carefully)
     */
    public void clearAllRooms() {
        rooms.clear();
    }

    /**
     * Get total count of all rooms
     */
    public int getTotalCount() {
        return rooms.size();
    }

    /**
     * Validate all rooms
     */
    public boolean validateAllRooms() {
        return rooms.stream()
                .allMatch(room -> room.getPricePerDay() > 0 && room.getRoomType() != null);
    }
}