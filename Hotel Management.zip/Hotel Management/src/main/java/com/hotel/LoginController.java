package com.hotel;

import com.hotel.models.User;
import com.hotel.utils.DataManager;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * LoginController - FXML controller for login.fxml
 * Demonstrates Scene Builder / FXML MVC pattern
 */
public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label statusLabel;
    @FXML private Button loginButton;

    private DataManager dataManager;
    private LoginCallback callback;

    // Callback interface so Main.java knows when login succeeds
    public interface LoginCallback {
        void onLoginSuccess(User user);
    }

    public void setDataManager(DataManager dataManager) {
        this.dataManager = dataManager;
    }

    public void setCallback(LoginCallback callback) {
        this.callback = callback;
    }

    @FXML
    public void initialize() {
        // Allow Enter key on password field to trigger login
        passwordField.setOnAction(e -> handleLogin());
        usernameField.setOnAction(e -> passwordField.requestFocus());
    }

    @FXML
    public void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            showStatus("⚠  Please enter both username and password.", false);
            return;
        }

        if (dataManager.getUserService().authenticateUser(username, password)) {
            User user = dataManager.getUserService().getCurrentLoggedInUser();
            showStatus("✓  Login successful!", true);
            if (callback != null) callback.onLoginSuccess(user);
        } else {
            showStatus("✗  Invalid username or password.", false);
            passwordField.clear();
        }
    }

    private void showStatus(String message, boolean success) {
        statusLabel.setText(message);
        statusLabel.setStyle(
            "-fx-font-size:12px;-fx-text-fill:" +
            (success ? "#27ae60" : "#e74c3c") + ";"
        );
    }
}