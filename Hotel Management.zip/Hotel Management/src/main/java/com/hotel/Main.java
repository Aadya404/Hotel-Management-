package com.hotel;

import java.time.LocalDate;
import java.util.List;

import com.hotel.models.Booking;
import com.hotel.models.BookingStatus;
import com.hotel.models.Invoice;
import com.hotel.models.Rating;
import com.hotel.models.Room;
import com.hotel.models.RoomCategory;
import com.hotel.models.RoomType;
import com.hotel.models.User;
import com.hotel.utils.DataManager;
import com.hotel.utils.DatabaseLogger;   
import com.hotel.utils.FileHandler;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {
    private DataManager dataManager;
    private Stage primaryStage;
    private User currentUser;

    private static final String NAVY      = "#1a2747";
    private static final String GOLD      = "#c9a84c";
    private static final String WHITE     = "#ffffff";
    private static final String OFF_WHITE = "#f4f6fb";
    private static final String TEXT_DARK = "#1a2747";
    private static final String TEXT_GREY = "#6b7a99";
    private static final String SUCCESS   = "#27ae60";
    private static final String DANGER    = "#e74c3c";
    private static final String BORDER    = "#dce3f0";
    private static final String ACCENT    = "#3498db";

    @Override
    public void start(Stage stage) throws Exception {
        this.primaryStage = stage;
        dataManager = new DataManager();
        dataManager.initializeSampleData();
        dataManager.loadAllData();
        DatabaseLogger.connect();
        primaryStage.setWidth(1200);
        primaryStage.setHeight(760);
        primaryStage.setMinWidth(1000);
        primaryStage.setMinHeight(650);
        primaryStage.setOnCloseRequest(e -> {
            dataManager.saveAllData();
            dataManager.shutdown();
            DatabaseLogger.disconnect();
        });
        showLoginScreen();
        primaryStage.show();
    }

    // ══════════════════════════════════════════════
    //  STYLE HELPERS
    // ══════════════════════════════════════════════

    private Button styledBtn(String text, String bg, String fg) {
        Button b = new Button(text);
        b.setStyle(
            "-fx-background-color:" + bg + ";" +
            "-fx-text-fill:" + fg + ";" +
            "-fx-font-size:13px;" +
            "-fx-font-weight:bold;" +
            "-fx-padding:9 20;" +
            "-fx-background-radius:7;" +
            "-fx-cursor:hand;"
        );
        b.setOnMouseEntered(e -> b.setOpacity(0.82));
        b.setOnMouseExited(e  -> b.setOpacity(1.0));
        return b;
    }

    private Label titleLbl(String t) {
        Label l = new Label(t);
        l.setStyle(
            "-fx-font-size:22px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:" + TEXT_DARK + ";"
        );
        return l;
    }

    private Label fieldLbl(String t) {
        Label l = new Label(t);
        l.setStyle(
            "-fx-font-size:11px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:" + TEXT_GREY + ";"
        );
        return l;
    }

    private TextField field(String prompt) {
        TextField tf = new TextField();
        tf.setPromptText(prompt);
        tf.setStyle(
            "-fx-background-color:" + WHITE + ";" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:6;" +
            "-fx-background-radius:6;" +
            "-fx-padding:8 12;" +
            "-fx-font-size:13px;"
        );
        tf.setPrefHeight(38);
        return tf;
    }

    private PasswordField passField(String prompt) {
        PasswordField pf = new PasswordField();
        pf.setPromptText(prompt);
        pf.setStyle(
            "-fx-background-color:" + WHITE + ";" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:6;" +
            "-fx-background-radius:6;" +
            "-fx-padding:8 12;" +
            "-fx-font-size:13px;"
        );
        pf.setPrefHeight(38);
        return pf;
    }

    private void styleDate(DatePicker dp) {
        dp.setStyle(
            "-fx-background-color:" + WHITE + ";" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:6;" +
            "-fx-background-radius:6;" +
            "-fx-font-size:13px;"
        );
        dp.setPrefHeight(38);
    }

    private <T> ComboBox<T> combo(T... items) {
        ComboBox<T> cb = new ComboBox<>(FXCollections.observableArrayList(items));
        cb.setStyle(
            "-fx-background-color:" + WHITE + ";" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:6;" +
            "-fx-background-radius:6;" +
            "-fx-font-size:13px;"
        );
        cb.setPrefHeight(38);
        cb.setPrefWidth(180);
        if (items.length > 0) cb.setValue(items[0]);
        return cb;
    }

    private VBox statBox(String value, String label, String color) {
        VBox b = new VBox(6);
        b.setAlignment(Pos.CENTER);
        b.setPadding(new Insets(20, 26, 20, 26));
        b.setStyle(
            "-fx-background-color:" + WHITE + ";" +
            "-fx-background-radius:12;" +
            "-fx-border-color:" + color + ";" +
            "-fx-border-width:0 0 0 4;" +
            "-fx-effect:dropshadow(gaussian,rgba(0,0,0,0.05),8,0,0,2);"
        );
        Label v = new Label(value);
        v.setStyle(
            "-fx-font-size:26px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:" + color + ";"
        );
        Label l = new Label(label);
        l.setStyle(
            "-fx-font-size:11px;" +
            "-fx-text-fill:" + TEXT_GREY + ";" +
            "-fx-font-weight:bold;"
        );
        b.getChildren().addAll(v, l);
        return b;
    }

    private VBox card(String title, javafx.scene.Node... nodes) {
        VBox c = new VBox(14);
        c.setPadding(new Insets(22));
        c.setStyle(
            "-fx-background-color:" + WHITE + ";" +
            "-fx-background-radius:12;" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:12;" +
            "-fx-effect:dropshadow(gaussian,rgba(0,0,0,0.06),12,0,0,3);"
        );
        if (title != null) {
            Label t = new Label(title);
            t.setStyle(
                "-fx-font-size:15px;" +
                "-fx-font-weight:bold;" +
                "-fx-text-fill:" + TEXT_DARK + ";"
            );
            Separator sep = new Separator();
            c.getChildren().addAll(t, sep);
        }
        c.getChildren().addAll(nodes);
        return c;
    }

    private ScrollPane scroll(VBox content) {
        ScrollPane sp = new ScrollPane(content);
        sp.setFitToWidth(true);
        sp.setStyle(
            "-fx-background-color:transparent;" +
            "-fx-background:" + OFF_WHITE + ";" +
            "-fx-border-color:transparent;"
        );
        return sp;
    }

    private void alert(String title, String msg, boolean ok) {
        Alert a = new Alert(ok ? Alert.AlertType.INFORMATION : Alert.AlertType.ERROR);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }

   
    //  TABLE BUILDER
  

private VBox table(String[] headers, String[][] rows) {
    VBox tbl = new VBox(0);
    tbl.setStyle(
        "-fx-background-color:" + WHITE + ";" +
        "-fx-border-color:" + BORDER + ";" +
        "-fx-border-radius:8;" +
        "-fx-background-radius:8;"
    );

    // Header row
    HBox hdr = new HBox(0);
    hdr.setStyle(
        "-fx-background-color:#eef2fb;" +
        "-fx-background-radius:8 8 0 0;" +
        "-fx-border-color:transparent transparent " + BORDER + " transparent;"
    );
    for (String h : headers) {
        Label lbl = new Label(h);
        lbl.setStyle(
            "-fx-font-size:11px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:" + TEXT_GREY + ";" +
            "-fx-padding:10 16;"
        );
        lbl.setMinWidth(160);
        lbl.setPrefWidth(180);
        HBox.setHgrow(lbl, Priority.ALWAYS);
        lbl.setMaxWidth(Double.MAX_VALUE);
        hdr.getChildren().add(lbl);
    }
    tbl.getChildren().add(hdr);

    if (rows == null || rows.length == 0) {
        Label e = new Label("No records found.");
        e.setStyle(
            "-fx-font-size:12px;" +
            "-fx-text-fill:" + TEXT_GREY + ";" +
            "-fx-padding:14;"
        );
        tbl.getChildren().add(e);
        return tbl;
    }

    for (int i = 0; i < rows.length; i++) {
        final String bg = (i % 2 == 0) ? WHITE : "#fafbfd";
        HBox row = new HBox(0);
        row.setStyle(
            "-fx-background-color:" + bg + ";" +
            "-fx-border-color:transparent transparent " + BORDER + " transparent;"
        );
        for (String cell : rows[i]) {
            Label lbl = new Label(cell != null ? cell : "—");
            lbl.setStyle(
                "-fx-font-size:12px;" +
                "-fx-text-fill:" + TEXT_DARK + ";" +
                "-fx-padding:10 16;"
            );
            lbl.setMinWidth(160);
            lbl.setPrefWidth(180);
            HBox.setHgrow(lbl, Priority.ALWAYS);
            lbl.setMaxWidth(Double.MAX_VALUE);
            lbl.setWrapText(false);
            row.getChildren().add(lbl);
        }
        final String bgFinal = bg;
        row.setOnMouseEntered(e -> row.setStyle(
            "-fx-background-color:#eef4ff;" +
            "-fx-border-color:transparent transparent " + BORDER + " transparent;"
        ));
        row.setOnMouseExited(e -> row.setStyle(
            "-fx-background-color:" + bgFinal + ";" +
            "-fx-border-color:transparent transparent " + BORDER + " transparent;"
        ));
        tbl.getChildren().add(row);
    }
    return tbl;
}

   
    //  LOGIN SCREEN
   

    private void showLoginScreen() {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(
                getClass().getResource("/com/hotel/login.fxml")
            );
            javafx.scene.Parent root = loader.load();

            LoginController controller = loader.getController();
            controller.setDataManager(dataManager);
            controller.setCallback(user -> {
                currentUser = user;
                if (currentUser.isAdmin()) showAdminDashboard();
                else showCustomerPortal();
            });

            primaryStage.setScene(new javafx.scene.Scene(root));
            primaryStage.setTitle("MANIPAL Hotel — Login");

        } catch (Exception e) {
            System.err.println("FXML load failed: " + e.getMessage());
            showLoginScreenFallback();
        }
    }

    
    private void showLoginScreenFallback() {
        VBox left = new VBox(16);
        left.setAlignment(Pos.CENTER);
        left.setStyle("-fx-background-color:" + NAVY + ";");
        left.setPrefWidth(420);
        left.setPadding(new Insets(60));

        Label name = new Label("MANIPAL HOTEL");
        name.setStyle(
            "-fx-font-size:32px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:" + GOLD + ";"
        );
        Label sub = new Label("Management System");
        sub.setStyle("-fx-font-size:14px;-fx-text-fill:rgba(255,255,255,0.45);");
        Label tag = new Label("Elegance  ·  Comfort  ·  Excellence");
        tag.setStyle(
            "-fx-font-size:11px;" +
            "-fx-text-fill:rgba(255,255,255,0.25);" +
            "-fx-font-style:italic;"
        );
        left.getChildren().addAll(name, sub, tag);

        VBox right = new VBox();
        right.setAlignment(Pos.CENTER);
        right.setStyle("-fx-background-color:" + OFF_WHITE + ";");

        VBox form = new VBox(14);
        form.setMaxWidth(370);
        form.setPadding(new Insets(44));
        form.setStyle(
            "-fx-background-color:" + WHITE + ";" +
            "-fx-background-radius:16;" +
            "-fx-effect:dropshadow(gaussian,rgba(0,0,0,0.10),24,0,0,4);"
        );

        Label welcome = new Label("Welcome Back");
        welcome.setStyle(
            "-fx-font-size:24px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:" + TEXT_DARK + ";"
        );
        Label wsub = new Label("Please sign in to continue");
        wsub.setStyle("-fx-font-size:13px;-fx-text-fill:" + TEXT_GREY + ";");

        TextField uField = field("Username");
        uField.setPrefWidth(310);
        PasswordField pField = passField("Password");
        pField.setPrefWidth(310);

        Label status = new Label();
        status.setWrapText(true);
        status.setMaxWidth(310);

        Button loginBtn = styledBtn("Sign In", NAVY, WHITE);
        loginBtn.setPrefWidth(310);
        loginBtn.setPrefHeight(46);

        Label hint = new Label("Admin: admin / admin123     |     Customer: john_doe / password123");
        hint.setStyle("-fx-font-size:10px;-fx-text-fill:" + TEXT_GREY + ";");
        hint.setWrapText(true);
        hint.setMaxWidth(310);

        Runnable doLogin = () -> {
            String username = uField.getText().trim();
            String password = pField.getText();
            if (username.isEmpty() || password.isEmpty()) {
                status.setText("Please enter both username and password.");
                status.setStyle("-fx-text-fill:" + DANGER + ";-fx-font-size:12px;");
                return;
            }
            if (dataManager.getUserService().authenticateUser(username, password)) {
                currentUser = dataManager.getUserService().getCurrentLoggedInUser();
                DatabaseLogger.logLogin(username, currentUser.getRole().getDisplayName(), true);
                if (currentUser.isAdmin()) showAdminDashboard();
                else showCustomerPortal();
            } else {
                DatabaseLogger.logLogin(username, "unknown", false);
                status.setText("Invalid username or password. Please try again.");
                status.setStyle("-fx-text-fill:" + DANGER + ";-fx-font-size:12px;");
                pField.clear();
            }
        };

        loginBtn.setOnAction(e -> doLogin.run());
        pField.setOnAction(e -> doLogin.run());
        uField.setOnAction(e -> pField.requestFocus());

        form.getChildren().addAll(
            welcome, wsub, new Separator(),
            fieldLbl("USERNAME"), uField,
            fieldLbl("PASSWORD"), pField,
            status, loginBtn, hint
        );
        right.getChildren().add(form);

        HBox root = new HBox(left, right);
        HBox.setHgrow(right, Priority.ALWAYS);
        primaryStage.setScene(new Scene(root));
        primaryStage.setTitle("MANIPAL Hotel Management System");
    }

    // ══════════════════════════════════════════════
    //  ADMIN DASHBOARD
    // ══════════════════════════════════════════════

    private void showAdminDashboard() {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color:" + OFF_WHITE + ";");
        root.setLeft(buildSidebar(root));
        root.setTop(buildTopBar());
        root.setCenter(buildOverview());
        primaryStage.setScene(new Scene(root));
        primaryStage.setTitle("MANIPAL Hotel -Administration");
    }

    private VBox buildSidebar(BorderPane root) {
        VBox sb = new VBox(0);
        sb.setPrefWidth(225);
        sb.setStyle("-fx-background-color:" + NAVY + ";");

        VBox logo = new VBox(4);
        logo.setPadding(new Insets(24, 20, 24, 20));
        Label icon = new Label("MANIPAL HOTEL");
        icon.setStyle(
            "-fx-font-size:14px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:" + GOLD + ";"
        );
        Label sub = new Label("Administration Panel");
        sub.setStyle("-fx-font-size:10px;-fx-text-fill:rgba(255,255,255,0.3);");
        logo.getChildren().addAll(icon, sub);

        Separator sep = new Separator();
        sep.setStyle("-fx-background-color:rgba(255,255,255,0.08);");

        VBox nav = new VBox(3);
        nav.setPadding(new Insets(12, 10, 12, 10));

        String[] labels = {"Overview", "Rooms", "Bookings", "Billing", "Reports","Database"};
        Button[] btns = new Button[labels.length];

        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            Button btn = navBtn(labels[i], i == 0);
            btn.setOnAction(e -> {
                javafx.scene.Node page;
                switch (idx) {
                     case 0: page = buildOverview();          break;
    case 1: page = buildRoomsPane();         break;
    case 2: page = buildBookingsPane();      break;
    case 3: page = buildBillingPane();       break;
    case 4: page = buildReportsPane();       break;
    default: page = buildDatabaseViewPane(); break;
                }
                root.setCenter(page);
                for (Button b : btns) b.setStyle(navStyle(false));
                btn.setStyle(navStyle(true));
            });
            btns[i] = btn;
            nav.getChildren().add(btn);
        }

        Region sp = new Region();
        VBox.setVgrow(sp, Priority.ALWAYS);

        Button logout = new Button("Sign Out");
        logout.setMaxWidth(Double.MAX_VALUE);
        logout.setAlignment(Pos.CENTER_LEFT);
        logout.setPadding(new Insets(12, 16, 12, 16));
        logout.setStyle(
            "-fx-background-color:rgba(231,76,60,0.12);" +
            "-fx-text-fill:#e74c3c;" +
            "-fx-font-size:13px;" +
            "-fx-background-radius:8;" +
            "-fx-cursor:hand;"
        );
        logout.setOnAction(e -> {
            dataManager.getUserService().logout();
            showLoginScreen();
        });

        VBox bottom = new VBox(logout);
        bottom.setPadding(new Insets(12));
        sb.getChildren().addAll(logo, sep, nav, sp, bottom);
        return sb;
    }

    private Button navBtn(String text, boolean active) {
        Button b = new Button(text);
        b.setMaxWidth(Double.MAX_VALUE);
        b.setAlignment(Pos.CENTER_LEFT);
        b.setPadding(new Insets(12, 16, 12, 16));
        b.setStyle(navStyle(active));
        return b;
    }

    private String navStyle(boolean active) {
        return active
            ? "-fx-background-color:rgba(255,255,255,0.14);" +
              "-fx-text-fill:" + WHITE + ";" +
              "-fx-font-size:13px;" +
              "-fx-font-weight:bold;" +
              "-fx-background-radius:8;" +
              "-fx-cursor:hand;"
            : "-fx-background-color:transparent;" +
              "-fx-text-fill:rgba(255,255,255,0.6);" +
              "-fx-font-size:13px;" +
              "-fx-background-radius:8;" +
              "-fx-cursor:hand;";
    }

    private HBox buildTopBar() {
        HBox bar = new HBox();
        bar.setPadding(new Insets(14, 28, 14, 28));
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setStyle(
            "-fx-background-color:" + WHITE + ";" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-width:0 0 1 0;"
        );
        Label t = new Label("Administration Dashboard");
        t.setStyle(
            "-fx-font-size:18px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:" + TEXT_DARK + ";"
        );
        Region filler = new Region();
        HBox.setHgrow(filler, Priority.ALWAYS);
        Label u = new Label(currentUser.getFullName() + "  —  Administrator");
        u.setStyle("-fx-font-size:12px;-fx-text-fill:" + TEXT_GREY + ";");
        bar.getChildren().addAll(t, filler, u);
        return bar;
    }

    // ── Overview ──
    private ScrollPane buildOverview() {
        VBox c = new VBox(22);
        c.setPadding(new Insets(28));

        int total    = dataManager.getRoomService().getTotalRoomCount();
        int avail    = dataManager.getRoomService().getAvailableRoomCount();
        int occupied = dataManager.getRoomService().getOccupiedRoomCount();
        int bookings = dataManager.getBookingService().getTotalBookingsCount();
        double rev   = dataManager.getBillingService().getTotalRevenue();

        HBox stats = new HBox(14);
        VBox[] boxes = {
            statBox(String.valueOf(total),          "Total Rooms",   NAVY),
            statBox(String.valueOf(avail),          "Available",     SUCCESS),
            statBox(String.valueOf(occupied),       "Occupied",      GOLD),
            statBox(String.valueOf(bookings),       "Total Bookings","#8e44ad"),
            statBox("Rs." + String.format("%.0f", rev), "Revenue",  "#16a085")
        };
        for (VBox b : boxes) {
            HBox.setHgrow(b, Priority.ALWAYS);
            b.setMaxWidth(Double.MAX_VALUE);
        }
        stats.getChildren().addAll(boxes);

        VBox roomTbl = table(
            new String[]{"Room", "Type", "Category", "Price / Night", "Status"},
            dataManager.getRoomService().getRoomsSortedByNumber().stream().map(r ->
                new String[]{
                    String.valueOf(r.getRoomNumber()),
                    r.getRoomType().getDisplayName(),
                    r.getRoomCategory().getDisplayName(),
                    "Rs." + String.format("%.0f", r.getPricePerDay()),
                    r.getStatus().getDisplayName()
                }
            ).toArray(String[][]::new)
        );

        VBox bkTbl = table(
            new String[]{"Booking ID", "Room", "Check-In", "Check-Out", "Status", "Amount"},
            dataManager.getBookingService().getAllBookings().stream().map(b ->
                new String[]{
                    "#" + b.getBookingId(),
                    String.valueOf(b.getRoomNumber()),
                    b.getCheckInDate().toString(),
                    b.getCheckOutDate().toString(),
                    b.getStatus().getDisplayName(),
                    "Rs." + String.format("%.0f", b.getFinalPrice())
                }
            ).toArray(String[][]::new)
        );

        c.getChildren().addAll(
            titleLbl("Welcome back, " + currentUser.getFullName()),
            stats,
            card("Room Status", roomTbl),
            card("Recent Bookings", bkTbl)
        );
        return scroll(c);
    }

    // ── Rooms ──
    private ScrollPane buildRoomsPane() {
        VBox c = new VBox(22);
        c.setPadding(new Insets(28));

        TextField rnField = field("e.g. 105");
        rnField.setPrefWidth(110);
        ComboBox<String> tc = combo("SINGLE", "DOUBLE", "DELUXE");
        ComboBox<String> cc = combo("STANDARD", "PREMIUM", "LUXURY");
        TextField prField  = field("e.g. 2000");
        prField.setPrefWidth(110);
        Label fb = new Label();

        VBox[] holder = {new VBox()};
        Runnable refresh = () -> holder[0].getChildren().setAll(table(
            new String[]{"Room", "Type", "Category", "Price / Night",
                         "Max Guests", "Status", "Amenities"},
            dataManager.getRoomService().getRoomsSortedByNumber().stream().map(r ->
                new String[]{
                    String.valueOf(r.getRoomNumber()),
                    r.getRoomType().getDisplayName(),
                    r.getRoomCategory().getDisplayName(),
                    "Rs." + String.format("%.0f", r.getPricePerDay()),
                    (r.getRoomType().getMaxAdults() + r.getRoomType().getMaxChildren()) +
                        " (Adults: " + r.getRoomType().getMaxAdults() +
                        ", Children: " + r.getRoomType().getMaxChildren() + ")",
                    r.getStatus().getDisplayName(),
                    r.getAmenitiesString().isEmpty() ? "None" : r.getAmenitiesString()
                }
            ).toArray(String[][]::new)
        ));
        refresh.run();

        Button addBtn = styledBtn("Add Room", NAVY, WHITE);
        addBtn.setOnAction(e -> {
            try {
                int num        = Integer.parseInt(rnField.getText().trim());
                RoomType rt    = RoomType.valueOf(tc.getValue());
                RoomCategory rc= RoomCategory.valueOf(cc.getValue());
                double pr      = Double.parseDouble(prField.getText().trim());
                boolean ok     = dataManager.getRoomService().addRoom(new Room(num, rt, rc, pr));
                if (ok) {
                    fb.setText("Room " + num + " added successfully.");
                    fb.setStyle("-fx-text-fill:" + SUCCESS + ";-fx-font-size:12px;");
                    rnField.clear();
                    prField.clear();
                    refresh.run();
                } else {
                    fb.setText("A room with that number already exists.");
                    fb.setStyle("-fx-text-fill:" + DANGER + ";-fx-font-size:12px;");
                }
            } catch (Exception ex) {
                fb.setText("Please check your input and try again.");
                fb.setStyle("-fx-text-fill:" + DANGER + ";-fx-font-size:12px;");
            }
        });

        GridPane fg = new GridPane();
        fg.setHgap(12);
        fg.setVgap(8);
        fg.add(fieldLbl("ROOM NUMBER"), 0, 0);
        fg.add(fieldLbl("TYPE"),        1, 0);
        fg.add(fieldLbl("CATEGORY"),    2, 0);
        fg.add(fieldLbl("PRICE / NIGHT"),3,0);
        fg.add(rnField, 0, 1);
        fg.add(tc,      1, 1);
        fg.add(cc,      2, 1);
        fg.add(prField, 3, 1);

        HBox btnRow = new HBox(12, addBtn, fb);
        btnRow.setAlignment(Pos.CENTER_LEFT);

        c.getChildren().addAll(
            titleLbl("Room Management"),
            card("Add New Room", fg, btnRow),
            card("All Rooms", holder[0])
        );
        return scroll(c);
    }

    // ── Bookings ──
    private ScrollPane buildBookingsPane() {
        VBox c = new VBox(22);
        c.setPadding(new Insets(28));

        TextField cidf  = field("Customer ID");
        TextField rnf   = field("Room Number");
        TextField gf    = field("Guests");
        gf.setPrefWidth(80);
        DatePicker ciPick = new DatePicker(LocalDate.now().plusDays(1));
        DatePicker coPick = new DatePicker(LocalDate.now().plusDays(3));
        styleDate(ciPick);
        styleDate(coPick);
        Label fb = new Label();

        VBox[] holder = {new VBox()};
        Runnable refresh = () -> holder[0].getChildren().setAll(table(
            new String[]{"Booking ID", "Customer", "Room",
                         "Check-In", "Check-Out", "Guests", "Status", "Amount"},
            dataManager.getBookingService().getAllBookings().stream().map(b ->
                new String[]{
                    "#" + b.getBookingId(),
                    String.valueOf(b.getCustomerId()),
                    String.valueOf(b.getRoomNumber()),
                    b.getCheckInDate().toString(),
                    b.getCheckOutDate().toString(),
                    String.valueOf(b.getNumberOfGuests()),
                    b.getStatus().getDisplayName(),
                    "Rs." + String.format("%.0f", b.getFinalPrice())
                }
            ).toArray(String[][]::new)
        ));
        refresh.run();

        Button createBtn = styledBtn("Create Booking", NAVY, WHITE);
        createBtn.setOnAction(e -> {
            try {
                int cust   = Integer.parseInt(cidf.getText().trim());
                int room   = Integer.parseInt(rnf.getText().trim());
                int guests = Integer.parseInt(gf.getText().trim());
                LocalDate ci = ciPick.getValue();
                LocalDate co = coPick.getValue();

                if (!co.isAfter(ci)) {
                    fb.setText("Check-out date must be after check-in.");
                    fb.setStyle("-fx-text-fill:" + DANGER + ";");
                    return;
                }
                Room r = dataManager.getRoomService().getRoomByNumber(room);
                if (r == null) {
                    fb.setText("Room not found. Please check the room number.");
                    fb.setStyle("-fx-text-fill:" + DANGER + ";");
                    return;
                }
                int maxG = r.getRoomType().getMaxAdults() + r.getRoomType().getMaxChildren();
                if (guests > maxG) {
                    fb.setText("This room accommodates a maximum of " + maxG + " guests.");
                    fb.setStyle("-fx-text-fill:" + DANGER + ";");
                    return;
                }

                Booking b = dataManager.getBookingService()
                        .createBooking(cust, room, ci, co, guests);
                if (b != null) {
                    long nights = java.time.temporal.ChronoUnit.DAYS.between(ci, co);
                    double price = dataManager.getPricingService()
                            .calculateFinalPrice(room, ci, nights);
                    dataManager.getBookingService()
                            .setBookingFinalPrice(b.getBookingId(), price);
                    dataManager.getBookingService().confirmBooking(b.getBookingId());
                    fb.setText("Booking #" + b.getBookingId() + " created. Total: Rs." +
                            String.format("%.0f", price));
                    fb.setStyle("-fx-text-fill:" + SUCCESS + ";");
                    DatabaseLogger.logBooking(b);
                    cidf.clear();
                    rnf.clear();
                    gf.clear();
                    refresh.run();
                } else {
                    fb.setText("Could not create booking. The room may not be available.");
                    fb.setStyle("-fx-text-fill:" + DANGER + ";");
                }
            } catch (Exception ex) {
                fb.setText("Please check your input and try again.");
                fb.setStyle("-fx-text-fill:" + DANGER + ";");
            }
        });

        GridPane fg = new GridPane();
        fg.setHgap(12);
        fg.setVgap(8);
        fg.add(fieldLbl("CUSTOMER ID"), 0, 0);
        fg.add(fieldLbl("ROOM"),        1, 0);
        fg.add(fieldLbl("CHECK-IN"),    2, 0);
        fg.add(fieldLbl("CHECK-OUT"),   3, 0);
        fg.add(fieldLbl("GUESTS"),      4, 0);
        fg.add(cidf,    0, 1);
        fg.add(rnf,     1, 1);
        fg.add(ciPick,  2, 1);
        fg.add(coPick,  3, 1);
        fg.add(gf,      4, 1);

        // Actions
        TextField aid = field("Booking ID");
        aid.setPrefWidth(130);
        Button ciBtn  = styledBtn("Check In",  SUCCESS, WHITE);
        Button coBtn  = styledBtn("Check Out", GOLD, TEXT_DARK);
        Button canBtn = styledBtn("Cancel",    DANGER, WHITE);
        Label  afb    = new Label();
        afb.setWrapText(true);

        ciBtn.setOnAction(e -> {
            try {
                int id = Integer.parseInt(aid.getText().trim());
                boolean ok = dataManager.getBookingService().checkIn(id);
                afb.setText(ok
                    ? "Guest checked in successfully for booking #" + id
                    : "Check-in failed. The booking must be in Confirmed status.");
                afb.setStyle("-fx-text-fill:" + (ok ? SUCCESS : DANGER) + ";");
                refresh.run();
            } catch (Exception ex) {
                afb.setText("Please enter a valid booking ID.");
                afb.setStyle("-fx-text-fill:" + DANGER + ";");
            }
        });

        coBtn.setOnAction(e -> {
            try {
                int id = Integer.parseInt(aid.getText().trim());
                Booking b = dataManager.getBookingService().getBookingById(id);
                boolean ok = dataManager.getBookingService().checkOut(id);
                if (ok && b != null) {
                    Invoice existing = dataManager.getBillingService()
                            .getInvoiceByBookingId(id);
                    DatabaseLogger.logRevenue(id, b.getRoomNumber(), b.getFinalPrice(), "Cash");
                    DatabaseLogger.logBookingStatusChange(b);
                    if (existing == null) {
                        Invoice inv = dataManager.getBillingService()
                                .generateInvoice(id, b.getCustomerId(), "Guest", "", "");
                        if (inv != null) {
                            dataManager.getBillingService()
                                    .makeFullPayment(inv.getInvoiceId(), "Cash");
                        }
                    }
                }
                afb.setText(ok
                    ? "Guest checked out. Invoice generated and revenue updated."
                    : "Check-out failed. The booking must be in Checked-In status.");
                afb.setStyle("-fx-text-fill:" + (ok ? SUCCESS : DANGER) + ";");
                refresh.run();
            } catch (Exception ex) {
                afb.setText("Please enter a valid booking ID.");
                afb.setStyle("-fx-text-fill:" + DANGER + ";");
            }
        });

        canBtn.setOnAction(e -> {
            try {
                int id = Integer.parseInt(aid.getText().trim());
                boolean ok = dataManager.getBookingService()
                        .cancelBooking(id, "Cancelled by administrator");
                afb.setText(ok
                    ? "Booking #" + id + " has been cancelled."
                    : "Could not cancel this booking.");
                afb.setStyle("-fx-text-fill:" + (ok ? SUCCESS : DANGER) + ";");
                refresh.run();
            } catch (Exception ex) {
                afb.setText("Please enter a valid booking ID.");
                afb.setStyle("-fx-text-fill:" + DANGER + ";");
            }
        });

        HBox actionRow = new HBox(10,
            fieldLbl("BOOKING ID:"), aid, ciBtn, coBtn, canBtn, afb);
        actionRow.setAlignment(Pos.CENTER_LEFT);

        c.getChildren().addAll(
            titleLbl("Booking Management"),
            card("New Booking", fg, new HBox(12, createBtn, fb)),
            card("Check In / Out / Cancel", actionRow),
            card("All Bookings", holder[0])
        );
        return scroll(c);
    }

    // ── Billing ──
    private ScrollPane buildBillingPane() {
        VBox c = new VBox(22);
        c.setPadding(new Insets(28));

        double rev     = dataManager.getBillingService().getTotalRevenue();
        double pend    = dataManager.getBillingService().getTotalPendingAmount();
        double refund  = dataManager.getBillingService().getTotalRefundedAmount();
        int    invCount= dataManager.getBillingService().getTotalInvoiceCount();

        HBox revRow = new HBox(14);
        VBox[] boxes = {
            statBox("Rs." + String.format("%.0f", rev),    "Total Revenue",  SUCCESS),
            statBox("Rs." + String.format("%.0f", pend),   "Pending",        GOLD),
            statBox("Rs." + String.format("%.0f", refund), "Refunded",       DANGER),
            statBox(String.valueOf(invCount),               "Invoices Issued",NAVY)
        };
        for (VBox b : boxes) {
            HBox.setHgrow(b, Priority.ALWAYS);
            b.setMaxWidth(Double.MAX_VALUE);
        }
        revRow.getChildren().addAll(boxes);

        VBox invTbl = table(
            new String[]{"Invoice", "Booking", "Room",
                         "Charges", "Tax", "Total", "Status"},
            dataManager.getBillingService().getAllInvoices().stream().map(inv ->
                new String[]{
                    "#" + inv.getInvoiceId(),
                    "#" + inv.getBookingId(),
                    String.valueOf(inv.getRoomNumber()),
                    "Rs." + String.format("%.2f", inv.getRoomCharges()),
                    "Rs." + String.format("%.2f", inv.getTaxAmount()),
                    "Rs." + String.format("%.2f", inv.getTotalAmount()),
                    inv.getInvoiceStatus()
                }
            ).toArray(String[][]::new)
        );

        TextField bif = field("Booking ID");
        TextField cif = field("Customer ID");
        TextField nmf = field("Customer Name");
        Label gfb     = new Label();
        Button genBtn = styledBtn("Generate Invoice", NAVY, WHITE);

        TextArea prev = new TextArea("Invoice preview will appear here after generation.");
        prev.setEditable(false);
        prev.setPrefRowCount(12);
        prev.setStyle(
            "-fx-font-family:'Courier New';" +
            "-fx-font-size:12px;" +
            "-fx-control-inner-background:" + OFF_WHITE + ";" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:8;"
        );

        genBtn.setOnAction(e -> {
            try {
                int bid = Integer.parseInt(bif.getText().trim());
                int cid = Integer.parseInt(cif.getText().trim());
                Invoice inv = dataManager.getBillingService()
                        .generateInvoice(bid, cid, nmf.getText().trim(), "", "");
                if (inv != null) {
                    dataManager.getBillingService()
                            .makeFullPayment(inv.getInvoiceId(), "Cash");
                    prev.setText(inv.getInvoiceAsString());
                    gfb.setText("Invoice #" + inv.getInvoiceId() +
                            " generated and marked as paid.");
                    gfb.setStyle("-fx-text-fill:" + SUCCESS + ";");
                } else {
                    gfb.setText("Could not generate invoice. Please check the booking ID.");
                    gfb.setStyle("-fx-text-fill:" + DANGER + ";");
                }
            } catch (Exception ex) {
                gfb.setText("Please check your input and try again.");
                gfb.setStyle("-fx-text-fill:" + DANGER + ";");
            }
        });

        GridPane fg = new GridPane();
        fg.setHgap(12);
        fg.setVgap(8);
        fg.add(fieldLbl("BOOKING ID"),   0, 0);
        fg.add(fieldLbl("CUSTOMER ID"),  1, 0);
        fg.add(fieldLbl("CUSTOMER NAME"),2, 0);
        fg.add(bif, 0, 1);
        fg.add(cif, 1, 1);
        fg.add(nmf, 2, 1);

        c.getChildren().addAll(
            titleLbl("Billing and Invoices"),
            card("Revenue Overview", revRow),
            card("All Invoices", invTbl),
            card("Generate Invoice", fg, new HBox(12, genBtn, gfb), prev)
        );
        return scroll(c);
    }

    // ── Reports ──
    // FIX 3: moved return scroll(c) to the very end so DB Audit Log card is included
    private ScrollPane buildReportsPane() {
        VBox c = new VBox(22);
        c.setPadding(new Insets(28));

        double avgStay  = dataManager.getReportService().getAverageLengthOfStay();
        double avgVal   = dataManager.getReportService().getAverageBookingValue();
        double cancRate = dataManager.getReportService().getCancellationRatePercentage();
        double totalRev = dataManager.getBillingService().getTotalRevenue();

        HBox metrics = new HBox(14);
        VBox[] boxes = {
            statBox("Rs." + String.format("%.0f", totalRev), "Total Revenue",      SUCCESS),
            statBox(String.format("%.1f nights", avgStay),   "Avg Length of Stay", ACCENT),
            statBox("Rs." + String.format("%.0f", avgVal),   "Avg Booking Value",  NAVY),
            statBox(String.format("%.1f%%", cancRate),        "Cancellation Rate",  DANGER)
        };
        for (VBox b : boxes) {
            HBox.setHgrow(b, Priority.ALWAYS);
            b.setMaxWidth(Double.MAX_VALUE);
        }
        metrics.getChildren().addAll(boxes);

        VBox typeTbl = table(
            new String[]{"Room Type", "Total Rooms", "Available", "Occupied", "Revenue"},
            java.util.Arrays.stream(RoomType.values()).map(rt -> {
                List<Room> rooms = dataManager.getRoomService().filterByRoomType(rt);
                long av  = rooms.stream().filter(Room::isAvailable).count();
                long occ = rooms.stream().filter(Room::isOccupied).count();
                double rv= dataManager.getReportService()
                        .getRevenueByRoomType().getOrDefault(rt, 0.0);
                return new String[]{
                    rt.getDisplayName(),
                    String.valueOf(rooms.size()),
                    String.valueOf(av),
                    String.valueOf(occ),
                    "Rs." + String.format("%.0f", rv)
                };
            }).toArray(String[][]::new)
        );

        VBox statusTbl = table(
            new String[]{"Status", "Count"},
            new String[][]{
                {"Pending",
                    String.valueOf(dataManager.getBookingService().getPendingBookingsCount())},
                {"Confirmed",
                    String.valueOf(dataManager.getBookingService().getConfirmedBookingsCount())},
                {"Checked In",
                    String.valueOf(dataManager.getBookingService().getCheckedInBookingsCount())},
                {"Checked Out",
                    String.valueOf(dataManager.getBookingService().getCheckedOutBookings().size())},
                {"Cancelled",
                    String.valueOf(dataManager.getBookingService().getCancelledBookings().size())}
            }
        );

        Button backupBtn = styledBtn("Backup Data", SUCCESS, WHITE);
        backupBtn.setOnAction(e ->
            alert("Backup", FileHandler.backupAllData()
                ? "Data backed up successfully."
                : "Backup failed.", true)
        );

        // DB Audit Logs card
        TextArea dbLog = new TextArea(
            DatabaseLogger.getBookingSummaryFromDB() + "\n" +
            DatabaseLogger.getLoginLogFromDB() + "\n" +
            DatabaseLogger.getRevenueLogFromDB()
        );
        dbLog.setEditable(false);
        dbLog.setPrefRowCount(14);
        dbLog.setStyle(
            "-fx-font-family:'Courier New';-fx-font-size:11px;" +
            "-fx-control-inner-background:" + OFF_WHITE + ";" +
            "-fx-border-color:" + BORDER + ";-fx-border-radius:8;"
        );
        Button refreshDbBtn = styledBtn("Refresh DB Logs", ACCENT, WHITE);
        refreshDbBtn.setOnAction(e -> dbLog.setText(
            DatabaseLogger.getBookingSummaryFromDB() + "\n" +
            DatabaseLogger.getLoginLogFromDB() + "\n" +
            DatabaseLogger.getRevenueLogFromDB()
        ));

        c.getChildren().addAll(
            titleLbl("Reports and Analytics"),
            card("Key Metrics",           metrics),
            card("Room Type Breakdown",   typeTbl),
            card("Booking Status",        statusTbl),
            card("Data Management",       backupBtn),
            card("Database Audit Log (JDBC/SQLite)", refreshDbBtn, dbLog)
            
        );
        return scroll(c);  // single return at the very end
    }
    private ScrollPane buildDatabaseViewPane() {
    VBox c = new VBox(22);
    c.setPadding(new Insets(28));

    // Bookings log table
    VBox[] bookingHolder = {new VBox()};
    VBox[] loginHolder   = {new VBox()};
    VBox[] revenueHolder = {new VBox()};

    Runnable refreshDB = () -> {
        // Query booking_log
        java.util.List<String[]> bookingRows = new java.util.ArrayList<>();
        java.util.List<String[]> loginRows   = new java.util.ArrayList<>();
        java.util.List<String[]> revenueRows = new java.util.ArrayList<>();

        try {
            java.sql.Connection conn = java.sql.DriverManager.getConnection(
                "jdbc:sqlite:hotel_audit.db");

            // Bookings
            java.sql.ResultSet rs1 = conn.createStatement()
                .executeQuery("SELECT * FROM booking_log ORDER BY logged_at DESC");
            while (rs1.next()) {
                bookingRows.add(new String[]{
                    "#" + rs1.getInt("booking_id"),
                    String.valueOf(rs1.getInt("room_number")),
                    rs1.getString("check_in_date"),
                    rs1.getString("check_out_date"),
                    String.valueOf(rs1.getInt("guests")),
                    "Rs." + String.format("%.0f", rs1.getDouble("final_price")),
                    rs1.getString("status"),
                    rs1.getString("logged_at")
                });
            }

            // Logins
            java.sql.ResultSet rs2 = conn.createStatement()
                .executeQuery("SELECT * FROM login_log ORDER BY logged_at DESC");
            while (rs2.next()) {
                loginRows.add(new String[]{
                    rs2.getString("username"),
                    rs2.getString("role"),
                    rs2.getInt("success") == 1 ? "Success" : "Failed",
                    rs2.getString("logged_at")
                });
            }

            // Revenue
            java.sql.ResultSet rs3 = conn.createStatement()
                .executeQuery("SELECT * FROM revenue_log ORDER BY logged_at DESC");
            double total = 0;
            while (rs3.next()) {
                double amt = rs3.getDouble("amount");
                total += amt;
                revenueRows.add(new String[]{
                    "#" + rs3.getInt("booking_id"),
                    String.valueOf(rs3.getInt("room_number")),
                    "Rs." + String.format("%.2f", amt),
                    rs3.getString("payment_method"),
                    rs3.getString("logged_at")
                });
            }

            conn.close();

            bookingHolder[0].getChildren().setAll(table(
                new String[]{"Booking", "Room", "Check-In",
                             "Check-Out", "Guests", "Amount", "Status", "Logged At"},
                bookingRows.toArray(new String[0][])
            ));

            loginHolder[0].getChildren().setAll(table(
                new String[]{"Username", "Role", "Result", "Time"},
                loginRows.toArray(new String[0][])
            ));

            revenueHolder[0].getChildren().setAll(table(
                new String[]{"Booking", "Room", "Amount", "Method", "Time"},
                revenueRows.toArray(new String[0][])
            ));

        } catch (Exception e) {
            Label err = new Label("Could not connect to database: " + e.getMessage());
            err.setStyle("-fx-text-fill:" + DANGER + ";");
            bookingHolder[0].getChildren().setAll(err);
        }
    };
    refreshDB.run();

    Button refreshBtn = styledBtn("Refresh Database View", NAVY, WHITE);
    refreshBtn.setOnAction(e -> refreshDB.run());

    c.getChildren().addAll(
        titleLbl("Live Database View (JDBC / SQLite)"),
        card("Booking Log", refreshBtn, bookingHolder[0]),
        card("Login Log",   loginHolder[0]),
        card("Revenue Log", revenueHolder[0])
    );
    return scroll(c);
}

    // ══════════════════════════════════════════════
    //  CUSTOMER PORTAL
    // ══════════════════════════════════════════════

    private void showCustomerPortal() {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color:" + OFF_WHITE + ";");

        HBox topBar = new HBox();
        topBar.setPadding(new Insets(0, 24, 0, 24));
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setStyle("-fx-background-color:" + NAVY + ";-fx-min-height:60px;");

        Label t = new Label("MANIPAL Hotel");
        t.setStyle(
            "-fx-font-size:16px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:" + GOLD + ";"
        );
        Region filler = new Region();
        HBox.setHgrow(filler, Priority.ALWAYS);

        Label u = new Label(currentUser.getFullName());
        u.setStyle("-fx-font-size:13px;-fx-text-fill:rgba(255,255,255,0.75);");

        Button logout = styledBtn("Sign Out", DANGER, WHITE);
        logout.setOnAction(e -> {
            dataManager.getUserService().logout();
            showLoginScreen();
        });

        topBar.getChildren().addAll(t, filler, u, logout);
        HBox.setMargin(logout, new Insets(0, 0, 0, 16));
        root.setTop(topBar);

        HBox navBar = new HBox(0);
        navBar.setStyle(
            "-fx-background-color:" + WHITE + ";" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-width:0 0 2 0;"
        );
        navBar.setPadding(new Insets(0, 24, 0, 24));

        StackPane area = new StackPane();
        area.setStyle("-fx-background-color:" + OFF_WHITE + ";");

        String[] navLabels = {"Browse and Book", "My Bookings", "Reviews", "My Profile"};
        Button[] navBtns   = new Button[navLabels.length];

        Runnable[] pageBuilders = {
            () -> area.getChildren().setAll(buildBrowseTab()),
            () -> area.getChildren().setAll(buildMyBookingsTab()),
            () -> area.getChildren().setAll(buildReviewsTab()),
            () -> area.getChildren().setAll(buildProfileTab())
        };

        for (int i = 0; i < navLabels.length; i++) {
            final int idx = i;
            Button btn = new Button(navLabels[i]);
            btn.setPadding(new Insets(16, 22, 16, 22));
            btn.setStyle(cNavStyle(i == 0));
            btn.setOnAction(e -> {
                pageBuilders[idx].run();
                for (Button b : navBtns) b.setStyle(cNavStyle(false));
                btn.setStyle(cNavStyle(true));
            });
            navBtns[i] = btn;
            navBar.getChildren().add(btn);
        }

        area.getChildren().add(buildBrowseTab());

        VBox center = new VBox(0, navBar, area);
        VBox.setVgrow(area, Priority.ALWAYS);
        root.setCenter(center);

        primaryStage.setScene(new Scene(root));
        primaryStage.setTitle("MANIPAL Hotel — Customer Portal");
    }

    private String cNavStyle(boolean active) {
        return active
            ? "-fx-background-color:transparent;" +
              "-fx-text-fill:" + NAVY + ";" +
              "-fx-font-size:13px;" +
              "-fx-font-weight:bold;" +
              "-fx-border-color:transparent transparent " + NAVY + " transparent;" +
              "-fx-border-width:0 0 3 0;" +
              "-fx-cursor:hand;" +
              "-fx-background-radius:0;"
            : "-fx-background-color:transparent;" +
              "-fx-text-fill:" + TEXT_GREY + ";" +
              "-fx-font-size:13px;" +
              "-fx-border-color:transparent;" +
              "-fx-border-width:0 0 3 0;" +
              "-fx-cursor:hand;" +
              "-fx-background-radius:0;";
    }

    // ── Browse and Book ──
    private ScrollPane buildBrowseTab() {
        VBox c = new VBox(22);
        c.setPadding(new Insets(28));

        int avail = dataManager.getRoomService().getAvailableRoomCount();
        int total = dataManager.getRoomService().getTotalRoomCount();

        HBox stats = new HBox(14);
        VBox s1 = statBox(String.valueOf(avail), "Rooms Available", SUCCESS);
        VBox s2 = statBox(String.valueOf(total), "Total Rooms",     NAVY);
        for (VBox s : new VBox[]{s1, s2}) {
            HBox.setHgrow(s, Priority.ALWAYS);
            s.setMaxWidth(Double.MAX_VALUE);
        }
        stats.getChildren().addAll(s1, s2);

        VBox roomTbl = table(
            new String[]{"Room", "Type", "Category", "Price / Night",
                         "Max Guests", "Amenities"},
            dataManager.getRoomService().getAvailableRooms().stream().map(r ->
                new String[]{
                    String.valueOf(r.getRoomNumber()),
                    r.getRoomType().getDisplayName(),
                    r.getRoomCategory().getDisplayName(),
                    "Rs." + String.format("%.0f", r.getPricePerDay()),
                    (r.getRoomType().getMaxAdults() + r.getRoomType().getMaxChildren()) +
                        " (Adults: " + r.getRoomType().getMaxAdults() +
                        ", Children: " + r.getRoomType().getMaxChildren() + ")",
                    r.getAmenitiesString().isEmpty() ? "None" : r.getAmenitiesString()
                }
            ).toArray(String[][]::new)
        );

        ComboBox<String> roomCombo = new ComboBox<>();
        roomCombo.setStyle(
            "-fx-background-color:" + WHITE + ";" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:6;" +
            "-fx-background-radius:6;" +
            "-fx-font-size:13px;"
        );
        roomCombo.setPrefHeight(38);
        roomCombo.setPrefWidth(320);

        Runnable fillCombo = () -> {
            roomCombo.getItems().clear();
            for (Room r : dataManager.getRoomService().getAvailableRooms()) {
                roomCombo.getItems().add(
                    "Room " + r.getRoomNumber() + "  —  " +
                    r.getRoomType().getDisplayName() + "  —  Rs." +
                    String.format("%.0f", r.getPricePerDay()) + " / night  (max " +
                    (r.getRoomType().getMaxAdults() + r.getRoomType().getMaxChildren()) +
                    " guests)"
                );
            }
            if (!roomCombo.getItems().isEmpty())
                roomCombo.setValue(roomCombo.getItems().get(0));
        };
        fillCombo.run();

        DatePicker ciP = new DatePicker(LocalDate.now().plusDays(1));
        DatePicker coP = new DatePicker(LocalDate.now().plusDays(2));
        styleDate(ciP);
        styleDate(coP);

        TextField gf = field("Number of guests");
        gf.setPrefWidth(160);

        Label gHint = new Label();
        gHint.setStyle("-fx-font-size:11px;-fx-text-fill:" + TEXT_GREY + ";");

        Label priceEst = new Label("Select a room and dates to see the estimated price.");
        priceEst.setStyle("-fx-font-size:13px;-fx-text-fill:" + TEXT_GREY + ";");

        Runnable updateEst = () -> {
            try {
                if (roomCombo.getValue() == null) return;
                int rn = Integer.parseInt(
                    roomCombo.getValue().split("Room ")[1].split(" ")[0]);
                Room r = dataManager.getRoomService().getRoomByNumber(rn);
                LocalDate ci = ciP.getValue();
                LocalDate co = coP.getValue();
                if (r != null) {
                    int maxG = r.getRoomType().getMaxAdults() +
                               r.getRoomType().getMaxChildren();
                    gHint.setText("This room accepts up to " +
                        r.getRoomType().getMaxAdults() + " adult(s) and " +
                        r.getRoomType().getMaxChildren() + " child(ren)  —  " +
                        maxG + " guests total.");
                    if (ci != null && co != null && co.isAfter(ci)) {
                        long nights = java.time.temporal.ChronoUnit.DAYS.between(ci, co);
                        double price = dataManager.getPricingService()
                                .calculateFinalPrice(rn, ci, nights);
                        priceEst.setText("Estimated total: Rs." +
                            String.format("%.2f", price) + "  for " + nights +
                            " night" + (nights > 1 ? "s" : "") +
                            " (dynamic pricing applied)");
                        priceEst.setStyle(
                            "-fx-font-size:14px;" +
                            "-fx-font-weight:bold;" +
                            "-fx-text-fill:" + SUCCESS + ";"
                        );
                    }
                }
            } catch (Exception ignored) {}
        };

        roomCombo.valueProperty().addListener((o, ov, nv) -> updateEst.run());
        ciP.valueProperty().addListener((o, ov, nv)      -> updateEst.run());
        coP.valueProperty().addListener((o, ov, nv)      -> updateEst.run());

        Label fb = new Label();
        fb.setWrapText(true);
        fb.setMaxWidth(700);

        Button bookBtn = styledBtn("Confirm Booking", NAVY, WHITE);
        bookBtn.setPrefHeight(44);

        bookBtn.setOnAction(e -> {
            try {
                if (roomCombo.getValue() == null) {
                    fb.setText("No rooms are currently available.");
                    fb.setStyle("-fx-text-fill:" + DANGER + ";");
                    return;
                }
                int rn = Integer.parseInt(
                    roomCombo.getValue().split("Room ")[1].split(" ")[0]);
                LocalDate ci = ciP.getValue();
                LocalDate co = coP.getValue();

                if (ci == null || co == null || !co.isAfter(ci)) {
                    fb.setText("Please select valid check-in and check-out dates.");
                    fb.setStyle("-fx-text-fill:" + DANGER + ";");
                    return;
                }
                if (gf.getText().trim().isEmpty()) {
                    fb.setText("Please enter the number of guests.");
                    fb.setStyle("-fx-text-fill:" + DANGER + ";");
                    return;
                }

                int guests = Integer.parseInt(gf.getText().trim());
                if (guests <= 0) {
                    fb.setText("Number of guests must be at least 1.");
                    fb.setStyle("-fx-text-fill:" + DANGER + ";");
                    return;
                }

                Room r   = dataManager.getRoomService().getRoomByNumber(rn);
                int maxG = r.getRoomType().getMaxAdults() +
                           r.getRoomType().getMaxChildren();
                if (guests > maxG) {
                    fb.setText("Too many guests. This room accommodates a maximum of " +
                        r.getRoomType().getMaxAdults() + " adult(s) and " +
                        r.getRoomType().getMaxChildren() + " child(ren), " +
                        maxG + " in total. You entered " + guests + ".");
                    fb.setStyle("-fx-text-fill:" + DANGER + ";-fx-font-size:12px;");
                    return;
                }

                Booking b = dataManager.getBookingService()
                        .createBooking(currentUser.getUserId(), rn, ci, co, guests);
                if (b != null) {
                    long nights = java.time.temporal.ChronoUnit.DAYS.between(ci, co);
                    double price = dataManager.getPricingService()
                            .calculateFinalPrice(rn, ci, nights);
                    dataManager.getBookingService()
                            .setBookingFinalPrice(b.getBookingId(), price);
                    dataManager.getBookingService().confirmBooking(b.getBookingId());
                    fb.setText("Booking confirmed! Your booking ID is #" +
                        b.getBookingId() + ".  Total: Rs." +
                        String.format("%.2f", price) + "  |  " + ci + " to " + co +
                        "  |  " + guests + " guest(s).");
                    fb.setStyle("-fx-text-fill:" + SUCCESS + ";-fx-font-size:13px;");
                    gf.clear();
                    fillCombo.run();
                    DatabaseLogger.logBooking(b);
                } else {
                    fb.setText("Booking could not be completed. " +
                            "The room may no longer be available.");
                    fb.setStyle("-fx-text-fill:" + DANGER + ";");
                }
            } catch (NumberFormatException ex) {
                fb.setText("Please enter a valid number for guests.");
                fb.setStyle("-fx-text-fill:" + DANGER + ";");
            }
        });

        GridPane fg = new GridPane();
        fg.setHgap(14);
        fg.setVgap(6);
        fg.add(fieldLbl("SELECT ROOM"),  0, 0);
        fg.add(fieldLbl("CHECK-IN"),     1, 0);
        fg.add(fieldLbl("CHECK-OUT"),    2, 0);
        fg.add(fieldLbl("GUESTS"),       3, 0);
        fg.add(roomCombo, 0, 1);
        fg.add(ciP,       1, 1);
        fg.add(coP,       2, 1);
        fg.add(gf,        3, 1);
        fg.add(gHint,     3, 2);

        c.getChildren().addAll(
            titleLbl("Browse and Book a Room"),
            stats,
            card("Available Rooms", roomTbl),
            card("Make a Reservation", fg, priceEst, bookBtn, fb)
        );
        return scroll(c);
    }

    // ── My Bookings ──
    private ScrollPane buildMyBookingsTab() {
        VBox c = new VBox(22);
        c.setPadding(new Insets(28));

        VBox[] holder = {new VBox()};
        Runnable refresh = () -> {
            List<Booking> mine = dataManager.getBookingService()
                    .getBookingsByCustomerId(currentUser.getUserId());
            if (mine.isEmpty()) {
                Label empty = new Label(
                    "You have no bookings yet. Head over to 'Browse and Book' to get started.");
                empty.setStyle("-fx-font-size:13px;-fx-text-fill:" + TEXT_GREY + ";");
                holder[0].getChildren().setAll(empty);
            } else {
                holder[0].getChildren().setAll(table(
                    new String[]{"Booking ID", "Room", "Type",
                                 "Check-In", "Check-Out", "Guests", "Status", "Total"},
                    mine.stream().map(b -> {
                        Room r = dataManager.getRoomService()
                                .getRoomByNumber(b.getRoomNumber());
                        return new String[]{
                            "#" + b.getBookingId(),
                            String.valueOf(b.getRoomNumber()),
                            r != null ? r.getRoomType().getDisplayName() : "—",
                            b.getCheckInDate().toString(),
                            b.getCheckOutDate().toString(),
                            String.valueOf(b.getNumberOfGuests()),
                            b.getStatus().getDisplayName(),
                            "Rs." + String.format("%.0f", b.getFinalPrice())
                        };
                    }).toArray(String[][]::new)
                ));
            }
        };
        refresh.run();

        TextField cid = field("Enter Booking ID to cancel");
        cid.setPrefWidth(220);
        Button canBtn = styledBtn("Cancel Booking", DANGER, WHITE);
        Label cfb     = new Label();

        canBtn.setOnAction(e -> {
            try {
                int id = Integer.parseInt(cid.getText().trim());
                Booking b = dataManager.getBookingService().getBookingById(id);
                if (b == null || b.getCustomerId() != currentUser.getUserId()) {
                    cfb.setText("Booking not found on your account.");
                    cfb.setStyle("-fx-text-fill:" + DANGER + ";");
                    return;
                }
                boolean ok = dataManager.getBookingService()
                        .cancelBooking(id, "Cancelled by customer");
                cfb.setText(ok
                    ? "Booking #" + id + " cancelled. A refund will be processed as per our policy."
                    : "This booking cannot be cancelled — it may already be checked in or completed.");
                cfb.setStyle("-fx-text-fill:" + (ok ? SUCCESS : DANGER) + ";");
                cid.clear();
                refresh.run();
            } catch (Exception ex) {
                cfb.setText("Please enter a valid booking ID.");
                cfb.setStyle("-fx-text-fill:" + DANGER + ";");
            }
        });

        Button refreshBtn = styledBtn("Refresh", NAVY, WHITE);
        refreshBtn.setOnAction(e -> refresh.run());

        HBox actionRow = new HBox(12, refreshBtn, cid, canBtn, cfb);
        actionRow.setAlignment(Pos.CENTER_LEFT);

        c.getChildren().addAll(
            titleLbl("My Bookings"),
            card("Your Reservations", actionRow, holder[0])
        );
        return scroll(c);
    }

    // ── Reviews ──
    private ScrollPane buildReviewsTab() {
        VBox c = new VBox(22);
        c.setPadding(new Insets(28));

        List<Booking> done = dataManager.getBookingService()
                .getBookingsByCustomerId(currentUser.getUserId())
                .stream()
                .filter(b -> b.getStatus() == BookingStatus.CHECKED_OUT)
                .collect(java.util.stream.Collectors.toList());

        ComboBox<String> bCombo = new ComboBox<>();
        bCombo.setStyle(
            "-fx-background-color:" + WHITE + ";" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:6;" +
            "-fx-background-radius:6;" +
            "-fx-font-size:13px;"
        );
        bCombo.setPrefHeight(38);
        bCombo.setPrefWidth(360);

        if (done.isEmpty()) {
            bCombo.getItems().add("No completed stays to review yet");
        } else {
            for (Booking b : done) {
                Room r = dataManager.getRoomService().getRoomByNumber(b.getRoomNumber());
                bCombo.getItems().add(
                    "Booking #" + b.getBookingId() +
                    "  —  Room " + b.getRoomNumber() +
                    (r != null ? " (" + r.getRoomType().getDisplayName() + ")" : "") +
                    "  |  " + b.getCheckInDate() + " to " + b.getCheckOutDate()
                );
            }
        }
        if (!bCombo.getItems().isEmpty())
            bCombo.setValue(bCombo.getItems().get(0));

        Label ratingDisplay = new Label("5 out of 5 stars");
        ratingDisplay.setStyle(
            "-fx-font-size:16px;" +
            "-fx-font-weight:bold;" +
            "-fx-text-fill:" + GOLD + ";"
        );

        Slider slider = new Slider(1, 5, 5);
        slider.setMajorTickUnit(1);
        slider.setMinorTickCount(0);
        slider.setSnapToTicks(true);
        slider.setShowTickLabels(true);
        slider.setShowTickMarks(true);
        slider.setPrefWidth(300);
        slider.valueProperty().addListener((o, ov, nv) -> {
            int s = nv.intValue();
            ratingDisplay.setText(s + " out of 5 stars");
        });

        TextField titleF = field("e.g. Great stay, very comfortable room");
        titleF.setPrefWidth(420);

        TextArea body = new TextArea();
        body.setPromptText("Tell us about your experience — what did you enjoy? What could be better?");
        body.setPrefRowCount(4);
        body.setWrapText(true);
        body.setStyle(
            "-fx-font-size:13px;" +
            "-fx-border-color:" + BORDER + ";" +
            "-fx-border-radius:6;"
        );

        Label fb  = new Label();
        fb.setWrapText(true);

        Button submitBtn = styledBtn("Submit Review", GOLD, TEXT_DARK);
        submitBtn.setPrefHeight(42);

        submitBtn.setOnAction(e -> {
            if (done.isEmpty() || bCombo.getValue().startsWith("No completed")) {
                fb.setText("You need to complete a stay before leaving a review.");
                fb.setStyle("-fx-text-fill:" + DANGER + ";");
                return;
            }
            if (titleF.getText().trim().isEmpty()) {
                fb.setText("Please add a short title for your review.");
                fb.setStyle("-fx-text-fill:" + DANGER + ";");
                return;
            }
            int idx = bCombo.getSelectionModel().getSelectedIndex();
            Booking sel = done.get(idx);
            double rating = slider.getValue();

            dataManager.getRoomService().addRatingToRoom(sel.getRoomNumber(), rating);

            Rating ro = new Rating(
                sel.getBookingId(), currentUser.getUserId(),
                sel.getRoomNumber(), currentUser.getFullName(), currentUser.getEmail()
            );
            ro.setRatingValue(rating);
            ro.setReviewTitle(titleF.getText().trim());
            ro.setReviewDescription(body.getText().trim());
            ro.setWouldRecommend(rating >= 4.0);

            fb.setText("Thank you for your feedback! Your " + (int) rating +
                "-star review for Room " + sel.getRoomNumber() + " has been submitted.");
            fb.setStyle("-fx-text-fill:" + SUCCESS + ";-fx-font-size:13px;");
            titleF.clear();
            body.clear();
            slider.setValue(5);
        });

        VBox ratTbl = table(
            new String[]{"Room", "Type", "Average Rating", "Number of Reviews"},
            dataManager.getRoomService().getAllRooms().stream()
                .filter(r -> r.getRatingCount() > 0)
                .map(r -> new String[]{
                    String.valueOf(r.getRoomNumber()),
                    r.getRoomType().getDisplayName(),
                    String.format("%.1f / 5.0", r.getAverageRating()),
                    r.getRatingCount() + " review(s)"
                }).toArray(String[][]::new)
        );

        Label info = new Label(
            "Reviews can only be submitted after your stay is complete " +
            "(once staff process your check-out)."
        );
        info.setStyle(
            "-fx-font-size:12px;" +
            "-fx-text-fill:" + TEXT_GREY + ";" +
            "-fx-font-style:italic;"
        );

        c.getChildren().addAll(
            titleLbl("Reviews"),
            info,
            card("Leave a Review",
                fieldLbl("SELECT YOUR BOOKING"), bCombo,
                fieldLbl("YOUR RATING"), slider, ratingDisplay,
                fieldLbl("REVIEW TITLE"), titleF,
                fieldLbl("YOUR COMMENTS"), body,
                submitBtn, fb
            ),
            card("Room Ratings Summary", ratTbl)
        );
        return scroll(c);
    }

    // ── Profile ──
    private ScrollPane buildProfileTab() {
        VBox c = new VBox(22);
        c.setPadding(new Insets(28));

        List<Booking> mine = dataManager.getBookingService()
                .getBookingsByCustomerId(currentUser.getUserId());
        double spent    = mine.stream().mapToDouble(Booking::getFinalPrice).sum();
        long upcoming   = mine.stream().filter(Booking::isUpcoming).count();
        long completed  = mine.stream()
                .filter(b -> b.getStatus() == BookingStatus.CHECKED_OUT).count();
        long cancelled  = mine.stream().filter(Booking::isCancelled).count();

        HBox stats = new HBox(14);
        VBox[] boxes = {
            statBox(String.valueOf(mine.size()),           "Total Bookings", NAVY),
            statBox(String.valueOf(upcoming),              "Upcoming",       SUCCESS),
            statBox(String.valueOf(completed),             "Completed",      GOLD),
            statBox(String.valueOf(cancelled),             "Cancelled",      DANGER),
            statBox("Rs." + String.format("%.0f", spent), "Total Spent",    "#8e44ad")
        };
        for (VBox b : boxes) {
            HBox.setHgrow(b, Priority.ALWAYS);
            b.setMaxWidth(Double.MAX_VALUE);
        }
        stats.getChildren().addAll(boxes);

        VBox profileTbl = table(
            new String[]{"Field", "Details"},
            new String[][]{
                {"Full Name",      currentUser.getFullName()},
                {"Username",       currentUser.getUsername()},
                {"Email",          currentUser.getEmail()},
                {"Role",           currentUser.getRole().getDisplayName()},
                {"Account Status", currentUser.getIsActive() ? "Active" : "Inactive"},
                {"Member Since",   currentUser.getCreatedDate().toLocalDate().toString()},
                {"Last Login",     currentUser.getLastLoginDate() != null
                                    ? currentUser.getLastLoginDate().toLocalDate().toString()
                                    : "Current session"}
            }
        );

        c.getChildren().addAll(
            titleLbl("My Profile"),
            card("Your Activity", stats),
            card("Account Details", profileTbl)
        );
        return scroll(c);
    }

    public static void main(String[] args) {
        launch(args);
    }
}