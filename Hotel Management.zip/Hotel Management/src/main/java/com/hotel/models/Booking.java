package com.hotel.models;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * Booking Model Class
 * Represents a hotel booking with all details, pricing, and status management
 */
public class Booking implements Serializable {
    private static final long serialVersionUID = 1L;

    private int bookingId;
    private int customerId;
    private int roomNumber;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private LocalDateTime actualCheckInTime;
    private LocalDateTime actualCheckOutTime;
    private BookingStatus status;
    private Integer numberOfGuests;
    private Double basePrice;
    private Double finalPrice;
    private Double discountApplied;
    private Double loyaltyPointsRedeemed;
    private String bookingNotes;
    private LocalDateTime bookingDate;
    private RefundPolicy refundPolicy;
    private Double refundAmount;
    private String cancellationReason;
    private LocalDateTime cancellationDate;
    private Integer durationDays;
    private Integer durationHours;
    private boolean isExpressCheckout;

    // Using timestamp-based counter so IDs are unique across sessions
    private static int bookingCounter = (int)(System.currentTimeMillis() % 100000);

    public Booking(int customerId, int roomNumber, LocalDate checkInDate,
                   LocalDate checkOutDate, Integer numberOfGuests) {
        this.bookingId = ++bookingCounter;
        this.customerId = customerId;
        this.roomNumber = roomNumber;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.numberOfGuests = numberOfGuests;
        this.status = BookingStatus.PENDING;
        this.basePrice = 0.0;
        this.finalPrice = 0.0;
        this.discountApplied = 0.0;
        this.loyaltyPointsRedeemed = 0.0;
        this.bookingNotes = "";
        this.bookingDate = LocalDateTime.now();
        this.refundPolicy = RefundPolicy.FULL_REFUND;
        this.refundAmount = 0.0;
        this.cancellationReason = "";
        this.durationDays = 0;
        this.durationHours = 0;
        this.isExpressCheckout = false;
    }

    // Getters and Setters
    public int getBookingId() { return bookingId; }
    public int getCustomerId() { return customerId; }
    public int getRoomNumber() { return roomNumber; }

    public LocalDate getCheckInDate() { return checkInDate; }
    public void setCheckInDate(LocalDate checkInDate) { this.checkInDate = checkInDate; }

    public LocalDate getCheckOutDate() { return checkOutDate; }
    public void setCheckOutDate(LocalDate checkOutDate) { this.checkOutDate = checkOutDate; }

    public LocalDateTime getActualCheckInTime() { return actualCheckInTime; }
    public void setActualCheckInTime(LocalDateTime t) { this.actualCheckInTime = t; }

    public LocalDateTime getActualCheckOutTime() { return actualCheckOutTime; }
    public void setActualCheckOutTime(LocalDateTime t) { this.actualCheckOutTime = t; }

    public BookingStatus getStatus() { return status; }
    public void setStatus(BookingStatus status) { this.status = status; }

    public Integer getNumberOfGuests() { return numberOfGuests; }
    public void setNumberOfGuests(Integer numberOfGuests) { this.numberOfGuests = numberOfGuests; }

    public Double getBasePrice() { return basePrice; }
    public void setBasePrice(Double basePrice) { this.basePrice = basePrice; }

    public Double getFinalPrice() { return finalPrice; }
    public void setFinalPrice(Double finalPrice) { this.finalPrice = finalPrice; }

    public Double getDiscountApplied() { return discountApplied; }
    public void setDiscountApplied(Double discountApplied) { this.discountApplied = discountApplied; }

    public Double getLoyaltyPointsRedeemed() { return loyaltyPointsRedeemed; }
    public void setLoyaltyPointsRedeemed(Double v) { this.loyaltyPointsRedeemed = v; }

    public String getBookingNotes() { return bookingNotes; }
    public void setBookingNotes(String bookingNotes) { this.bookingNotes = bookingNotes; }

    public LocalDateTime getBookingDate() { return bookingDate; }

    public RefundPolicy getRefundPolicy() { return refundPolicy; }
    public void setRefundPolicy(RefundPolicy refundPolicy) { this.refundPolicy = refundPolicy; }

    public Double getRefundAmount() { return refundAmount; }
    public void setRefundAmount(Double refundAmount) { this.refundAmount = refundAmount; }

    public String getCancellationReason() { return cancellationReason; }
    public void setCancellationReason(String r) { this.cancellationReason = r; }

    public LocalDateTime getCancellationDate() { return cancellationDate; }
    public void setCancellationDate(LocalDateTime d) { this.cancellationDate = d; }

    public Integer getDurationDays() { return durationDays; }
    public Integer getDurationHours() { return durationHours; }

    public boolean isExpressCheckout() { return isExpressCheckout; }
    public void setExpressCheckout(boolean expressCheckout) { isExpressCheckout = expressCheckout; }

    // ── Status management ──

    public void confirmBooking() {
        this.status = BookingStatus.CONFIRMED;
    }

    /**
     * Check in — accepts both PENDING and CONFIRMED bookings.
     * In practice a booking should be confirmed first, but we allow
     * pending check-ins so admin can check in walk-in guests directly.
     */
    public void checkIn() {
        this.status = BookingStatus.CHECKED_IN;
        this.actualCheckInTime = LocalDateTime.now();
    }

    public void checkOut() {
        this.status = BookingStatus.CHECKED_OUT;
        this.actualCheckOutTime = LocalDateTime.now();
        calculateDuration();
    }

    public void cancelBooking(String reason, RefundPolicy refundPolicy) {
        this.status = BookingStatus.CANCELLED;
        this.cancellationReason = reason;
        this.cancellationDate = LocalDateTime.now();
        this.refundPolicy = refundPolicy;
        calculateRefund();
    }

    // ── Calculations ──

    public void calculateDuration() {
        if (actualCheckInTime != null && actualCheckOutTime != null) {
            long days  = ChronoUnit.DAYS.between(
                actualCheckInTime.toLocalDate(), actualCheckOutTime.toLocalDate());
            long hours = ChronoUnit.HOURS.between(actualCheckInTime, actualCheckOutTime) % 24;
            this.durationDays  = (int) days;
            this.durationHours = (int) hours;
        }
    }

    public String getDurationString() {
        return durationDays + " day(s) " + durationHours + " hour(s)";
    }

    public void calculateRefund() {
        if (this.status == BookingStatus.CANCELLED && this.refundPolicy != null) {
            this.refundAmount = this.finalPrice * this.refundPolicy.getRefundPercentage();
        }
    }

    public void calculateFinalPrice(double baseRate, double occupancyModifier,
                                    double dayModifier, double advanceModifier,
                                    double seasonModifier) {
        double multiplier = (1 + occupancyModifier) * (1 + dayModifier)
                          * (1 + advanceModifier)  * (1 + seasonModifier);
        long nights = ChronoUnit.DAYS.between(checkInDate, checkOutDate);
        this.finalPrice = baseRate * multiplier * nights;
    }

    // ── Policy helpers ──

    public RefundPolicy getApplicableRefundPolicy() {
        long daysBeforeCheckIn = ChronoUnit.DAYS.between(LocalDate.now(), this.checkInDate);
        if (daysBeforeCheckIn >= 30) return RefundPolicy.FULL_REFUND;
        if (daysBeforeCheckIn >= 15) return RefundPolicy.SEVENTY_FIVE_PERCENT;
        if (daysBeforeCheckIn >= 7)  return RefundPolicy.FIFTY_PERCENT;
        if (daysBeforeCheckIn >= 1)  return RefundPolicy.TWENTY_FIVE_PERCENT;
        return RefundPolicy.NO_REFUND;
    }

    public boolean canBeCancelled() {
        return this.status == BookingStatus.PENDING
            || this.status == BookingStatus.CONFIRMED;
    }

    public boolean isCheckedIn()  { return this.status == BookingStatus.CHECKED_IN;  }
    public boolean isCheckedOut() { return this.status == BookingStatus.CHECKED_OUT; }
    public boolean isCancelled()  { return this.status == BookingStatus.CANCELLED;   }

    public boolean isUpcoming() {
        return (this.status == BookingStatus.PENDING
             || this.status == BookingStatus.CONFIRMED)
            && checkInDate.isAfter(LocalDate.now());
    }

    public boolean isOngoing() { return this.status == BookingStatus.CHECKED_IN; }

    public String getBookingSummary() {
        return "Booking ID : " + bookingId
             + "\nRoom       : " + roomNumber
             + "\nCheck-in   : " + checkInDate
             + "\nCheck-out  : " + checkOutDate
             + "\nGuests     : " + numberOfGuests
             + "\nStatus     : " + status.getDisplayName()
             + "\nTotal      : Rs." + String.format("%.2f", finalPrice);
    }

    @Override
    public String toString() {
        return "Booking{bookingId=" + bookingId
             + ", customerId=" + customerId
             + ", roomNumber=" + roomNumber
             + ", checkInDate=" + checkInDate
             + ", checkOutDate=" + checkOutDate
             + ", status=" + status
             + ", finalPrice=" + finalPrice + "}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Booking booking = (Booking) o;
        return bookingId == booking.bookingId;
    }

    @Override
    public int hashCode() { return Integer.hashCode(bookingId); }
}