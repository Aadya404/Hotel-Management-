package com.hotel.models;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Rating Model Class
 * Represents guest feedback and room ratings
 */
public class Rating implements Serializable {
    private static final long serialVersionUID = 1L;

    private int ratingId;
    private int bookingId;
    private int customerId;
    private int roomNumber;
    private Double ratingValue;  // Wrapper class (1.0 to 5.0)
    private String reviewTitle;
    private String reviewDescription;
    private LocalDateTime ratingDate;
    private Boolean wouldRecommend;  // Wrapper class
    private Boolean isVerified;  // Wrapper class (verified booking)
    
    // Rating categories
    private Double cleanliness;  // Wrapper class
    private Double comfort;  // Wrapper class
    private Double amenities;  // Wrapper class
    private Double service;  // Wrapper class
    private Double valueForMoney;  // Wrapper class
    private Double location;  // Wrapper class
    private Double noiseLevel;  // Wrapper class
    private Double roomSize;  // Wrapper class
    
    // Additional details
    private String guestName;
    private String guestEmail;
    private Integer stayDuration;  // Wrapper class
    private String roomType;
    private Boolean hasResponseFromHotel;  // Wrapper class
    private String hotelResponse;
    private LocalDateTime hotelResponseDate;
    private Boolean isHelpful;  // Wrapper class
    private Integer helpfulCount;  // Wrapper class

    // Static counter for auto-generating rating IDs
    private static int ratingCounter = 2000;

    // Constructor
    public Rating(int bookingId, int customerId, int roomNumber, String guestName, String guestEmail) {
        this.ratingId = ++ratingCounter;
        this.bookingId = bookingId;
        this.customerId = customerId;
        this.roomNumber = roomNumber;
        this.guestName = guestName;
        this.guestEmail = guestEmail;
        this.ratingValue = 0.0;
        this.reviewTitle = "";
        this.reviewDescription = "";
        this.ratingDate = LocalDateTime.now();
        this.wouldRecommend = false;  // Autoboxing
        this.isVerified = true;  // Autoboxing (verified booking)
        
        // Initialize category ratings
        this.cleanliness = 0.0;
        this.comfort = 0.0;
        this.amenities = 0.0;
        this.service = 0.0;
        this.valueForMoney = 0.0;
        this.location = 0.0;
        this.noiseLevel = 0.0;
        this.roomSize = 0.0;
        
        // Initialize other details
        this.stayDuration = 0;  // Autoboxing
        this.roomType = "";
        this.hasResponseFromHotel = false;  // Autoboxing
        this.hotelResponse = "";
        this.isHelpful = false;  // Autoboxing
        this.helpfulCount = 0;  // Autoboxing
    }

    // Getters and Setters
    public int getRatingId() {
        return ratingId;
    }

    public int getBookingId() {
        return bookingId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public Double getRatingValue() {
        return ratingValue;  // Autoboxing from wrapper
    }

    public void setRatingValue(Double ratingValue) {
        if (ratingValue >= 1.0 && ratingValue <= 5.0) {
            this.ratingValue = ratingValue;
        } else {
            this.ratingValue = 0.0;
        }
    }

    public String getReviewTitle() {
        return reviewTitle;
    }

    public void setReviewTitle(String reviewTitle) {
        this.reviewTitle = reviewTitle;
    }

    public String getReviewDescription() {
        return reviewDescription;
    }

    public void setReviewDescription(String reviewDescription) {
        this.reviewDescription = reviewDescription;
    }

    public LocalDateTime getRatingDate() {
        return ratingDate;
    }

    public Boolean getWouldRecommend() {
        return wouldRecommend;  // Autoboxing from wrapper
    }

    public void setWouldRecommend(Boolean wouldRecommend) {
        this.wouldRecommend = wouldRecommend;
    }

    public Boolean getIsVerified() {
        return isVerified;  // Autoboxing from wrapper
    }

    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }

    // Category ratings
    public Double getCleanliness() {
        return cleanliness;  // Autoboxing from wrapper
    }

    public void setCleanliness(Double cleanliness) {
        this.cleanliness = validateRating(cleanliness);
    }

    public Double getComfort() {
        return comfort;  // Autoboxing from wrapper
    }

    public void setComfort(Double comfort) {
        this.comfort = validateRating(comfort);
    }

    public Double getAmenities() {
        return amenities;  // Autoboxing from wrapper
    }

    public void setAmenities(Double amenities) {
        this.amenities = validateRating(amenities);
    }

    public Double getService() {
        return service;  // Autoboxing from wrapper
    }

    public void setService(Double service) {
        this.service = validateRating(service);
    }

    public Double getValueForMoney() {
        return valueForMoney;  // Autoboxing from wrapper
    }

    public void setValueForMoney(Double valueForMoney) {
        this.valueForMoney = validateRating(valueForMoney);
    }

    public Double getLocation() {
        return location;  // Autoboxing from wrapper
    }

    public void setLocation(Double location) {
        this.location = validateRating(location);
    }

    public Double getNoiseLevel() {
        return noiseLevel;  // Autoboxing from wrapper
    }

    public void setNoiseLevel(Double noiseLevel) {
        this.noiseLevel = validateRating(noiseLevel);
    }

    public Double getRoomSize() {
        return roomSize;  // Autoboxing from wrapper
    }

    public void setRoomSize(Double roomSize) {
        this.roomSize = validateRating(roomSize);
    }

    public String getGuestName() {
        return guestName;
    }

    public String getGuestEmail() {
        return guestEmail;
    }

    public Integer getStayDuration() {
        return stayDuration;  // Autoboxing from wrapper
    }

    public void setStayDuration(Integer stayDuration) {
        this.stayDuration = stayDuration;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public Boolean getHasResponseFromHotel() {
        return hasResponseFromHotel;  // Autoboxing from wrapper
    }

    public String getHotelResponse() {
        return hotelResponse;
    }

    public void setHotelResponse(String hotelResponse) {
        this.hotelResponse = hotelResponse;
        this.hasResponseFromHotel = true;  // Autoboxing
        this.hotelResponseDate = LocalDateTime.now();
    }

    public LocalDateTime getHotelResponseDate() {
        return hotelResponseDate;
    }

    public Boolean getIsHelpful() {
        return isHelpful;  // Autoboxing from wrapper
    }

    public void setIsHelpful(Boolean isHelpful) {
        this.isHelpful = isHelpful;
    }

    public Integer getHelpfulCount() {
        return helpfulCount;  // Autoboxing from wrapper
    }

    public void setHelpfulCount(Integer helpfulCount) {
        this.helpfulCount = helpfulCount;
    }

    public void incrementHelpfulCount() {
        this.helpfulCount++;  // Autoboxing
    }

    // Helper methods
    private Double validateRating(Double rating) {
        if (rating >= 1.0 && rating <= 5.0) {
            return rating;
        }
        return 0.0;
    }

    public Double getAverageOfCategoryRatings() {
        double sum = cleanliness + comfort + amenities + service + valueForMoney + location + noiseLevel + roomSize;
        int count = 0;
        
        if (cleanliness > 0) count++;
        if (comfort > 0) count++;
        if (amenities > 0) count++;
        if (service > 0) count++;
        if (valueForMoney > 0) count++;
        if (location > 0) count++;
        if (noiseLevel > 0) count++;
        if (roomSize > 0) count++;
        
        if (count == 0) return 0.0;
        return sum / count;
    }

    public String getRatingStar() {
        int stars = Math.round(ratingValue.floatValue());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            if (i < stars) {
                sb.append("★");
            } else {
                sb.append("☆");
            }
        }
        return sb.toString();
    }

    public String getSentiment() {
        if (ratingValue >= 4.5) {
            return "Excellent";
        } else if (ratingValue >= 3.5) {
            return "Good";
        } else if (ratingValue >= 2.5) {
            return "Average";
        } else if (ratingValue >= 1.5) {
            return "Poor";
        } else {
            return "Very Poor";
        }
    }

    public String getRatingDetails() {
        StringBuilder sb = new StringBuilder();
        sb.append("Rating Details:\n");
        sb.append("Overall Rating: ").append(String.format("%.1f", ratingValue)).append("/5.0\n");
        sb.append("Sentiment: ").append(getSentiment()).append("\n");
        if (cleanliness > 0) sb.append("Cleanliness: ").append(String.format("%.1f", cleanliness)).append("/5\n");
        if (comfort > 0) sb.append("Comfort: ").append(String.format("%.1f", comfort)).append("/5\n");
        if (amenities > 0) sb.append("Amenities: ").append(String.format("%.1f", amenities)).append("/5\n");
        if (service > 0) sb.append("Service: ").append(String.format("%.1f", service)).append("/5\n");
        if (valueForMoney > 0) sb.append("Value for Money: ").append(String.format("%.1f", valueForMoney)).append("/5\n");
        if (location > 0) sb.append("Location: ").append(String.format("%.1f", location)).append("/5\n");
        sb.append("Would Recommend: ").append(wouldRecommend ? "Yes" : "No").append("\n");
        sb.append("Review: ").append(reviewDescription).append("\n");
        return sb.toString();
    }

    public boolean isHighRating() {
        return ratingValue >= 4.0;
    }

    public boolean isLowRating() {
        return ratingValue < 3.0;
    }

    @Override
    public String toString() {
        return "Rating{" +
                "ratingId=" + ratingId +
                ", bookingId=" + bookingId +
                ", roomNumber=" + roomNumber +
                ", ratingValue=" + ratingValue +
                ", guestName='" + guestName + '\'' +
                ", wouldRecommend=" + wouldRecommend +
                ", ratingDate=" + ratingDate +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Rating rating = (Rating) o;
        return ratingId == rating.ratingId;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(ratingId);
    }
}