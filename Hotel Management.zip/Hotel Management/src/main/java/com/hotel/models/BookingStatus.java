package com.hotel.models;
import java.io.Serializable;
public enum BookingStatus implements Serializable {
    PENDING("Pending", "#FFAA00"),
    CONFIRMED("Confirmed", "#00AA00"),
    CHECKED_IN("Checked In", "#0066CC"),
    CHECKED_OUT("Checked Out", "#666666"),
    CANCELLED("Cancelled", "#FF0000");
    private final String displayName;
    private final String color;
    BookingStatus(String displayName, String color) { this.displayName = displayName; this.color = color; }
    public String getDisplayName() { return displayName; }
    public String getColor() { return color; }
}