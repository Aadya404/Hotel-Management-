package com.hotel.models;
import java.io.Serializable;
public enum RefundPolicy implements Serializable {
    FULL_REFUND("Full Refund", 1.0),
    SEVENTY_FIVE_PERCENT("75% Refund", 0.75),
    FIFTY_PERCENT("50% Refund", 0.50),
    TWENTY_FIVE_PERCENT("25% Refund", 0.25),
    NO_REFUND("No Refund", 0.0);
    private final String displayName;
    private final Double refundPercentage;
    RefundPolicy(String displayName, Double refundPercentage) { this.displayName = displayName; this.refundPercentage = refundPercentage; }
    public String getDisplayName() { return displayName; }
    public Double getRefundPercentage() { return refundPercentage; }
}