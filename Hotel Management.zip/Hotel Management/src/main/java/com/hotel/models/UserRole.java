package com.hotel.models;
import java.io.Serializable;
public enum UserRole implements Serializable {
    ADMIN("Administrator"), CUSTOMER("Customer");
    private final String displayName;
    UserRole(String displayName) { this.displayName = displayName; }
    public String getDisplayName() { return displayName; }
}