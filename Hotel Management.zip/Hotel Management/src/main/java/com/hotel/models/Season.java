package com.hotel.models;
import java.io.Serializable;
public enum Season implements Serializable {
    OFF_SEASON("Off-Season", -0.10), NORMAL("Normal", 0.0), PEAK("Peak", 0.25);
    private final String displayName;
    private final Double modifier;
    Season(String displayName, Double modifier) { this.displayName = displayName; this.modifier = modifier; }
    public String getDisplayName() { return displayName; }
    public Double getModifier() { return modifier; }
}