package com.hotel.models;
import java.io.Serializable;
public enum DayType implements Serializable {
    WEEKDAY("Weekday", -0.05), WEEKEND("Weekend", 0.10), HOLIDAY("Holiday", 0.20);
    private final String displayName;
    private final Double modifier;
    DayType(String displayName, Double modifier) { this.displayName = displayName; this.modifier = modifier; }
    public String getDisplayName() { return displayName; }
    public Double getModifier() { return modifier; }
}