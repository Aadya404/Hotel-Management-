package com.hotel.models;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Room implements Serializable {
    private static final long serialVersionUID = 1L;

    private int roomNumber;
    private RoomType roomType;
    private RoomCategory roomCategory;
    private Double pricePerDay;
    private AvailabilityStatus status;
    private Set<AmenityType> amenities;
    private double averageRating;
    private int ratingCount;
    private String maintenanceReason;
    private java.time.LocalDate maintenanceUntil;
    private String description;

    public Room(int roomNumber, RoomType roomType, RoomCategory roomCategory, Double pricePerDay) {
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.roomCategory = roomCategory;
        this.pricePerDay = pricePerDay;
        this.status = AvailabilityStatus.AVAILABLE;
        this.amenities = new HashSet<>();
        this.averageRating = 0.0;
        this.ratingCount = 0;
        this.maintenanceReason = "";
        this.maintenanceUntil = null;
        this.description = "";
    }

    public int getRoomNumber() { return roomNumber; }
    public void setRoomNumber(int roomNumber) { this.roomNumber = roomNumber; }

    public RoomType getRoomType() { return roomType; }
    public void setRoomType(RoomType roomType) { this.roomType = roomType; }

    public RoomCategory getRoomCategory() { return roomCategory; }
    public void setRoomCategory(RoomCategory roomCategory) { this.roomCategory = roomCategory; }

    public Double getPricePerDay() { return pricePerDay; }
    public void setPricePerDay(Double pricePerDay) { this.pricePerDay = pricePerDay; }

    public AvailabilityStatus getStatus() { return status; }
    public void setStatus(AvailabilityStatus status) { this.status = status; }

    public Set<AmenityType> getAmenities() { return amenities; }

    // ✅ Added this method - was missing, causing RoomService error
    public void setAmenities(Set<AmenityType> amenities) {
        this.amenities = amenities != null ? amenities : new HashSet<>();
    }

    public void addAmenity(AmenityType amenity) { this.amenities.add(amenity); }
    public void removeAmenity(AmenityType amenity) { this.amenities.remove(amenity); }
    public boolean hasAmenity(AmenityType amenity) { return amenities.contains(amenity); }

    public double getAverageRating() { return averageRating; }
    public void setAverageRating(double averageRating) { this.averageRating = averageRating; }

    public int getRatingCount() { return ratingCount; }
    public void setRatingCount(int ratingCount) { this.ratingCount = ratingCount; }

    public void addRating(double rating) {
        double totalRating = this.averageRating * this.ratingCount;
        this.ratingCount++;
        this.averageRating = (totalRating + rating) / this.ratingCount;
    }

    public String getMaintenanceReason() { return maintenanceReason; }
    public void setMaintenanceReason(String maintenanceReason) { this.maintenanceReason = maintenanceReason; }

    public java.time.LocalDate getMaintenanceUntil() { return maintenanceUntil; }
    public void setMaintenanceUntil(java.time.LocalDate maintenanceUntil) { this.maintenanceUntil = maintenanceUntil; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public boolean isAvailable() { return status == AvailabilityStatus.AVAILABLE; }
    public boolean isOccupied() { return status == AvailabilityStatus.OCCUPIED; }
    public boolean isUnderMaintenance() { return status == AvailabilityStatus.MAINTENANCE; }

    public void markAsAvailable() {
        this.status = AvailabilityStatus.AVAILABLE;
        this.maintenanceReason = "";
        this.maintenanceUntil = null;
    }

    public void markAsOccupied() { this.status = AvailabilityStatus.OCCUPIED; }

    public void markAsMaintenance(String reason, java.time.LocalDate until) {
        this.status = AvailabilityStatus.MAINTENANCE;
        this.maintenanceReason = reason;
        this.maintenanceUntil = until;
    }

    public String getCapacityInfo() {
        int adults = this.roomType.getMaxAdults();
        int children = this.roomType.getMaxChildren();
        return adults + " Adult" + (adults > 1 ? "s" : "") +
               (children > 0 ? ", " + children + " Child" + (children > 1 ? "ren" : "") : "");
    }

    public String getAmenitiesString() {
        StringBuilder sb = new StringBuilder();
        for (AmenityType amenity : amenities) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(amenity.getDisplayName());
        }
        return sb.toString().isEmpty() ? "No amenities" : sb.toString();
    }

    @Override
    public String toString() {
        return "Room{roomNumber=" + roomNumber +
                ", roomType=" + roomType +
                ", roomCategory=" + roomCategory +
                ", pricePerDay=" + pricePerDay +
                ", status=" + status +
                ", averageRating=" + String.format("%.1f", averageRating) + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Room room = (Room) o;
        return roomNumber == room.roomNumber;
    }

    @Override
    public int hashCode() { return Integer.hashCode(roomNumber); }
}