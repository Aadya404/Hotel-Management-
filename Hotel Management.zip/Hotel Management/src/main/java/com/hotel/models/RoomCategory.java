package com.hotel.models;
import java.io.Serializable;
public enum RoomCategory implements Serializable {
    STANDARD("Standard"), PREMIUM("Premium"), LUXURY("Luxury");
    private final String displayName;
    RoomCategory(String displayName) { this.displayName = displayName; }
    public String getDisplayName() { return displayName; }
}