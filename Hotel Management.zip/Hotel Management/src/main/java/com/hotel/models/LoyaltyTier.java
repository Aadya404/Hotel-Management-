package com.hotel.models;
import java.io.Serializable;
public enum LoyaltyTier implements Serializable {
    SILVER("Silver", 1.0), GOLD("Gold", 1.05), PLATINUM("Platinum", 1.10);
    private final String displayName;
    private final Double pointMultiplier;
    LoyaltyTier(String displayName, Double pointMultiplier) { this.displayName = displayName; this.pointMultiplier = pointMultiplier; }
    public String getDisplayName() { return displayName; }
    public Double getPointMultiplier() { return pointMultiplier; }
}