package com.hotel.models;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * User Model Class
 * Represents a system user with authentication credentials and role
 */
public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    private int userId;
    private String username;
    private String password;
    private String email;
    private String fullName;
    private UserRole role;
    private Boolean isActive;  // Wrapper class
    private LocalDateTime createdDate;
    private LocalDateTime lastLoginDate;
    private String department;
    private String phone;
    private LocalDateTime passwordChangedDate;
    private Integer loginAttempts;  // Wrapper class
    private Boolean isLocked;  // Wrapper class
    private LocalDateTime lockedUntil;
    private String profilePicture;

    // Static counter for auto-generating user IDs
    private static int userCounter = 100;

    // Constructor
    public User(String username, String password, String email, String fullName, UserRole role) {
        this.userId = ++userCounter;
        this.username = username;
        this.password = password;
        this.email = email;
        this.fullName = fullName;
        this.role = role;
        this.isActive = true;  // Autoboxing
        this.createdDate = LocalDateTime.now();
        this.lastLoginDate = null;
        this.department = "";
        this.phone = "";
        this.passwordChangedDate = LocalDateTime.now();
        this.loginAttempts = 0;  // Autoboxing
        this.isLocked = false;  // Autoboxing
        this.lockedUntil = null;
        this.profilePicture = "";
    }

    // Getters and Setters
    public int getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
        this.passwordChangedDate = LocalDateTime.now();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public UserRole getRole() {
        return role;
    }

    public void setRole(UserRole role) {
        this.role = role;
    }

    public Boolean getIsActive() {
        return isActive;  // Autoboxing from wrapper
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public LocalDateTime getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(LocalDateTime lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public LocalDateTime getPasswordChangedDate() {
        return passwordChangedDate;
    }

    public Integer getLoginAttempts() {
        return loginAttempts;  // Autoboxing from wrapper
    }

    public void setLoginAttempts(Integer loginAttempts) {
        this.loginAttempts = loginAttempts;
    }

    public Boolean getIsLocked() {
        return isLocked;  // Autoboxing from wrapper
    }

    public void setIsLocked(Boolean isLocked) {
        this.isLocked = isLocked;
    }

    public LocalDateTime getLockedUntil() {
        return lockedUntil;
    }

    public void setLockedUntil(LocalDateTime lockedUntil) {
        this.lockedUntil = lockedUntil;
    }

    public String getProfilePicture() {
        return profilePicture;
    }

    public void setProfilePicture(String profilePicture) {
        this.profilePicture = profilePicture;
    }

    // Authentication methods
    public boolean validatePassword(String inputPassword) {
        // Simple password validation - in production, use hashing (BCrypt, etc.)
        return this.password.equals(inputPassword);
    }

    public boolean changePassword(String oldPassword, String newPassword) {
        if (validatePassword(oldPassword)) {
            this.password = newPassword;
            this.passwordChangedDate = LocalDateTime.now();
            this.loginAttempts = 0;
            return true;
        }
        return false;
    }

    public void recordFailedLoginAttempt() {
        this.loginAttempts++;  // Autoboxing
        
        // Lock account after 5 failed attempts
        if (this.loginAttempts >= 5) {
            this.isLocked = true;  // Autoboxing
            this.lockedUntil = LocalDateTime.now().plusMinutes(30);
        }
    }

    public void recordSuccessfulLogin() {
        this.lastLoginDate = LocalDateTime.now();
        this.loginAttempts = 0;  // Autoboxing
        this.isLocked = false;  // Autoboxing
        this.lockedUntil = null;
    }

    public boolean isAccountLocked() {
        if (!this.isLocked) {
            return false;
        }
        
        // Check if lock has expired
        if (this.lockedUntil != null && LocalDateTime.now().isAfter(this.lockedUntil)) {
            this.isLocked = false;  // Autoboxing
            this.lockedUntil = null;
            this.loginAttempts = 0;  // Autoboxing
            return false;
        }
        
        return this.isLocked;
    }

    public void unlockAccount() {
        this.isLocked = false;  // Autoboxing
        this.loginAttempts = 0;  // Autoboxing
        this.lockedUntil = null;
    }

    public boolean isAccountActive() {
        return this.isActive && !isAccountLocked();
    }

    public boolean isAdmin() {
        return this.role == UserRole.ADMIN;
    }

    public boolean isCustomer() {
        return this.role == UserRole.CUSTOMER;
    }

    // Validation methods
    public boolean validateEmail() {
        return email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

    public boolean validatePhone() {
        return phone.isEmpty() || phone.matches("\\d{10}");
    }

    public boolean validateUsername() {
        return username.length() >= 3 && username.length() <= 20;
    }

    public boolean validatePassword() {
        // Password should be at least 8 characters
        return password.length() >= 8;
    }

    public String getLastLoginString() {
        if (lastLoginDate == null) {
            return "Never logged in";
        }
        return "Last login: " + lastLoginDate;
    }

    public String getUserSummary() {
        return "User ID: " + userId +
                "\nUsername: " + username +
                "\nFull Name: " + fullName +
                "\nEmail: " + email +
                "\nRole: " + role.getDisplayName() +
                "\nActive: " + (isActive ? "Yes" : "No") +
                "\nCreated: " + createdDate +
                "\n" + getLastLoginString();
    }

    @Override
    public String toString() {
        return "User{" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", fullName='" + fullName + '\'' +
                ", role=" + role +
                ", isActive=" + isActive +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return userId == user.userId;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(userId);
    }
}