package com.hotel.models;
import java.io.Serializable;
public enum RoomType implements Serializable {
    SINGLE("Single Room", 1500.0, 1, 1),
    DOUBLE("Double Room", 2500.0, 2, 1),
    DELUXE("Deluxe Suite", 3500.0, 3, 2);

    private final String displayName;
    private final Double basePrice;
    private final int maxAdults;
    private final int maxChildren;

    RoomType(String displayName, Double basePrice, int maxAdults, int maxChildren) {
        this.displayName = displayName;
        this.basePrice = basePrice;
        this.maxAdults = maxAdults;
        this.maxChildren = maxChildren;
    }

    public String getDisplayName() { return displayName; }
    public Double getBasePrice() { return basePrice; }
    public int getMaxAdults() { return maxAdults; }
    public int getMaxChildren() { return maxChildren; }
}