package com.hotel.models;
import java.io.Serializable;
public enum CancellationReason implements Serializable {
    CUSTOMER_REQUEST("Customer Request"), BUSINESS_CLOSURE("Business Closure"),
    EMERGENCY("Emergency"), OTHER("Other");
    private final String displayName;
    CancellationReason(String displayName) { this.displayName = displayName; }
    public String getDisplayName() { return displayName; }
}