package com.hotel.models;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Invoice Model Class
 * Represents a hotel invoice with billing details, taxes, discounts, and refunds
 */
public class Invoice implements Serializable {
    private static final long serialVersionUID = 1L;

    private int invoiceId;
    private int bookingId;
    private int customerId;
    private int roomNumber;
    private LocalDateTime invoiceDate;
    private LocalDateTime dueDate;
    private LocalDateTime paidDate;
    
    // Pricing details
    private Double roomCharges;  // Wrapper class
    private Double taxPercentage;  // Wrapper class (default 18%)
    private Double taxAmount;  // Wrapper class
    private Double discountAmount;  // Wrapper class
    private Double loyaltyDiscount;  // Wrapper class
    private Double subtotal;  // Wrapper class
    private Double totalAmount;  // Wrapper class
    private Double amountPaid;  // Wrapper class
    private Double balanceDue;  // Wrapper class
    private Double refundAmount;  // Wrapper class
    
    // Booking details
    private String customerName;
    private String customerEmail;
    private String customerPhone;
    private String roomType;
    private java.time.LocalDate checkInDate;
    private java.time.LocalDate checkOutDate;
    private Integer numberOfNights;  // Wrapper class
    private Integer numberOfGuests;  // Wrapper class
    private Double pricePerNight;  // Wrapper class
    
    // Additional details
    private String description;
    private String paymentMethod;
    private String invoiceStatus;  // DRAFT, ISSUED, PAID, REFUNDED, CANCELLED
    private String remarks;
    private boolean isPaid;
    private boolean isRefunded;
    private String refundReason;
    private LocalDateTime refundDate;

    // Static counter for auto-generating invoice IDs
    private static int invoiceCounter = 1000;

    // Constructor
    public Invoice(int bookingId, int customerId, int roomNumber, String customerName, 
                   String customerEmail, String customerPhone) {
        this.invoiceId = ++invoiceCounter;
        this.bookingId = bookingId;
        this.customerId = customerId;
        this.roomNumber = roomNumber;
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.customerPhone = customerPhone;
        this.invoiceDate = LocalDateTime.now();
        this.dueDate = this.invoiceDate.plusDays(7);
        
        // Initialize amounts
        this.roomCharges = 0.0;
        this.taxPercentage = 18.0;  // 18% GST (India)
        this.taxAmount = 0.0;
        this.discountAmount = 0.0;
        this.loyaltyDiscount = 0.0;
        this.subtotal = 0.0;
        this.totalAmount = 0.0;
        this.amountPaid = 0.0;
        this.balanceDue = 0.0;
        this.refundAmount = 0.0;
        
        // Initialize booking details
        this.numberOfNights = 0;
        this.numberOfGuests = 0;
        this.pricePerNight = 0.0;
        
        // Initialize other details
        this.description = "";
        this.paymentMethod = "";
        this.invoiceStatus = "DRAFT";
        this.remarks = "";
        this.isPaid = false;
        this.isRefunded = false;
        this.refundReason = "";
    }

    // Getters and Setters
    public int getInvoiceId() {
        return invoiceId;
    }

    public int getBookingId() {
        return bookingId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public LocalDateTime getInvoiceDate() {
        return invoiceDate;
    }

    public LocalDateTime getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDateTime dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDateTime getPaidDate() {
        return paidDate;
    }

    public void setPaidDate(LocalDateTime paidDate) {
        this.paidDate = paidDate;
    }

    public Double getRoomCharges() {
        return roomCharges;  // Autoboxing from wrapper
    }

    public void setRoomCharges(Double roomCharges) {
        this.roomCharges = roomCharges;
    }

    public Double getTaxPercentage() {
        return taxPercentage;  // Autoboxing from wrapper
    }

    public void setTaxPercentage(Double taxPercentage) {
        this.taxPercentage = taxPercentage;
    }

    public Double getTaxAmount() {
        return taxAmount;  // Autoboxing from wrapper
    }

    public Double getDiscountAmount() {
        return discountAmount;  // Autoboxing from wrapper
    }

    public void setDiscountAmount(Double discountAmount) {
        this.discountAmount = discountAmount;
    }

    public Double getLoyaltyDiscount() {
        return loyaltyDiscount;  // Autoboxing from wrapper
    }

    public void setLoyaltyDiscount(Double loyaltyDiscount) {
        this.loyaltyDiscount = loyaltyDiscount;
    }

    public Double getSubtotal() {
        return subtotal;  // Autoboxing from wrapper
    }

    public Double getTotalAmount() {
        return totalAmount;  // Autoboxing from wrapper
    }

    public Double getAmountPaid() {
        return amountPaid;  // Autoboxing from wrapper
    }

    public void setAmountPaid(Double amountPaid) {
        this.amountPaid = amountPaid;
        this.isPaid = (amountPaid >= this.totalAmount);
        updateBalanceDue();
    }

    public Double getBalanceDue() {
        return balanceDue;  // Autoboxing from wrapper
    }

    public Double getRefundAmount() {
        return refundAmount;  // Autoboxing from wrapper
    }

    public void setRefundAmount(Double refundAmount) {
        this.refundAmount = refundAmount;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public java.time.LocalDate getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(java.time.LocalDate checkInDate) {
        this.checkInDate = checkInDate;
    }

    public java.time.LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(java.time.LocalDate checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public Integer getNumberOfNights() {
        return numberOfNights;  // Autoboxing from wrapper
    }

    public void setNumberOfNights(Integer numberOfNights) {
        this.numberOfNights = numberOfNights;
    }

    public Integer getNumberOfGuests() {
        return numberOfGuests;  // Autoboxing from wrapper
    }

    public void setNumberOfGuests(Integer numberOfGuests) {
        this.numberOfGuests = numberOfGuests;
    }

    public Double getPricePerNight() {
        return pricePerNight;  // Autoboxing from wrapper
    }

    public void setPricePerNight(Double pricePerNight) {
        this.pricePerNight = pricePerNight;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(String invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public boolean isPaid() {
        return isPaid;
    }

    public boolean isRefunded() {
        return isRefunded;
    }

    public String getRefundReason() {
        return refundReason;
    }

    public LocalDateTime getRefundDate() {
        return refundDate;
    }

    // Calculation methods
    public void calculateTotals() {
        // Calculate subtotal (room charges)
        this.subtotal = this.roomCharges;
        
        // Calculate tax (18% GST on subtotal)
        this.taxAmount = this.subtotal * (this.taxPercentage / 100.0);
        
        // Calculate total (subtotal + tax - discounts)
        this.totalAmount = this.subtotal + this.taxAmount - this.discountAmount - this.loyaltyDiscount;
        
        // Make sure total is not negative
        if (this.totalAmount < 0) {
            this.totalAmount = 0.0;
        }
        
        updateBalanceDue();
    }

    private void updateBalanceDue() {
        this.balanceDue = this.totalAmount - this.amountPaid;
        if (this.balanceDue < 0) {
            this.balanceDue = 0.0;
        }
    }

    public void markAsPaid(String paymentMethod) {
        this.setAmountPaid(this.totalAmount);
        this.paymentMethod = paymentMethod;
        this.paidDate = LocalDateTime.now();
        this.isPaid = true;
        this.invoiceStatus = "PAID";
    }

    public void processRefund(Double refundAmount, String reason) {
        this.refundAmount = refundAmount;
        this.refundReason = reason;
        this.refundDate = LocalDateTime.now();
        this.isRefunded = true;
        this.invoiceStatus = "REFUNDED";
        this.amountPaid = Math.max(0, this.amountPaid - refundAmount);
        updateBalanceDue();
    }

    public void issueInvoice() {
        calculateTotals();
        this.invoiceStatus = "ISSUED";
    }

    public String getInvoiceAsString() {
        StringBuilder sb = new StringBuilder();
        sb.append("================== HOTEL INVOICE ==================\n");
        sb.append(String.format("Invoice ID: %d\n", invoiceId));
        sb.append(String.format("Booking ID: %d\n", bookingId));
        sb.append(String.format("Invoice Date: %s\n", invoiceDate));
        sb.append(String.format("Due Date: %s\n", dueDate));
        
        sb.append("\n--- GUEST DETAILS ---\n");
        sb.append(String.format("Name: %s\n", customerName));
        sb.append(String.format("Email: %s\n", customerEmail));
        sb.append(String.format("Phone: %s\n", customerPhone));
        
        sb.append("\n--- ROOM DETAILS ---\n");
        sb.append(String.format("Room Number: %d\n", roomNumber));
        sb.append(String.format("Room Type: %s\n", roomType));
        sb.append(String.format("Check-in: %s\n", checkInDate));
        sb.append(String.format("Check-out: %s\n", checkOutDate));
        sb.append(String.format("Number of Nights: %d\n", numberOfNights));
        sb.append(String.format("Number of Guests: %d\n", numberOfGuests));
        
        sb.append("\n--- BILLING SUMMARY ---\n");
        sb.append(String.format("Room Charges: ₹%.2f\n", roomCharges));
        sb.append(String.format("Discount: ₹%.2f\n", discountAmount));
        sb.append(String.format("Loyalty Discount: ₹%.2f\n", loyaltyDiscount));
        sb.append(String.format("Subtotal: ₹%.2f\n", subtotal));
        sb.append(String.format("Tax (%.0f%%): ₹%.2f\n", taxPercentage, taxAmount));
        sb.append(String.format("Total Amount: ₹%.2f\n", totalAmount));
        sb.append(String.format("Amount Paid: ₹%.2f\n", amountPaid));
        sb.append(String.format("Balance Due: ₹%.2f\n", balanceDue));
        
        if (isRefunded) {
            sb.append(String.format("Refund Amount: ₹%.2f\n", refundAmount));
            sb.append(String.format("Refund Reason: %s\n", refundReason));
        }
        
        sb.append(String.format("\n--- STATUS ---\n"));
        sb.append(String.format("Invoice Status: %s\n", invoiceStatus));
        sb.append(String.format("Payment Method: %s\n", paymentMethod));
        sb.append(String.format("Remarks: %s\n", remarks));
        
        sb.append("\n====================================================\n");
        return sb.toString();
    }

    @Override
    public String toString() {
        return "Invoice{" +
                "invoiceId=" + invoiceId +
                ", bookingId=" + bookingId +
                ", customerId=" + customerId +
                ", roomNumber=" + roomNumber +
                ", totalAmount=" + totalAmount +
                ", invoiceStatus='" + invoiceStatus + '\'' +
                ", isPaid=" + isPaid +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Invoice invoice = (Invoice) o;
        return invoiceId == invoice.invoiceId;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(invoiceId);
    }
}