package com.hotel.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Customer Model Class
 * Represents a hotel customer with contact information and booking history
 */
public class Customer implements Serializable {
    private static final long serialVersionUID = 1L;

    private int customerId;
    private String name;
    private String contactNumber;
    private String email;
    private Integer age;  // Wrapper class for age
    private String address;
    private String specialRequests;
    private java.time.LocalDate registrationDate;
    private List<Integer> bookingIds;  // List of booking IDs
    private double totalSpent;  // Total money spent
    private int totalBookings;  // Total bookings made
    private LoyaltyTier loyaltyTier;
    private int loyaltyPoints;
    private String preferredRoomType;
    private String floorPreference;
    private String dietaryRequirements;

    // Static counter for auto-generating customer IDs
    private static int customerCounter = 1000;

    // Constructor
    public Customer(String name, String contactNumber, String email, Integer age, String address) {
        this.customerId = ++customerCounter;
        this.name = name;
        this.contactNumber = contactNumber;
        this.email = email;
        this.age = age;  // Autoboxing
        this.address = address;
        this.specialRequests = "";
        this.registrationDate = java.time.LocalDate.now();
        this.bookingIds = new ArrayList<>();
        this.totalSpent = 0.0;
        this.totalBookings = 0;
        this.loyaltyTier = LoyaltyTier.SILVER;
        this.loyaltyPoints = 0;
        this.preferredRoomType = "";
        this.floorPreference = "Any";
        this.dietaryRequirements = "";
    }

    // Getters and Setters
    public int getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getAge() {
        return age;  // Autoboxing from wrapper
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSpecialRequests() {
        return specialRequests;
    }

    public void setSpecialRequests(String specialRequests) {
        this.specialRequests = specialRequests;
    }

    public java.time.LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public List<Integer> getBookingIds() {
        return bookingIds;
    }

    public void addBookingId(Integer bookingId) {
        this.bookingIds.add(bookingId);
        this.totalBookings++;
    }

    public void removeBookingId(Integer bookingId) {
        this.bookingIds.remove(bookingId);
        if (this.totalBookings > 0) {
            this.totalBookings--;
        }
    }

    public double getTotalSpent() {
        return totalSpent;
    }

    public void addToTotalSpent(double amount) {
        this.totalSpent += amount;
        // Auto-add loyalty points (1 point per ₹100)
        int pointsEarned = (int) (amount / 100);
        addLoyaltyPoints(pointsEarned);
        updateLoyaltyTier();
    }

    public int getTotalBookings() {
        return totalBookings;
    }

    public LoyaltyTier getLoyaltyTier() {
        return loyaltyTier;
    }

    public void setLoyaltyTier(LoyaltyTier loyaltyTier) {
        this.loyaltyTier = loyaltyTier;
    }

    public int getLoyaltyPoints() {
        return loyaltyPoints;
    }

    public void addLoyaltyPoints(int points) {
        // Apply loyalty tier multiplier
        int adjustedPoints = (int) (points * this.loyaltyTier.getPointMultiplier());
        this.loyaltyPoints += adjustedPoints;
        updateLoyaltyTier();
    }

    public void redeemLoyaltyPoints(int points) {
        if (this.loyaltyPoints >= points) {
            this.loyaltyPoints -= points;
            updateLoyaltyTier();
        }
    }

    private void updateLoyaltyTier() {
        if (this.loyaltyPoints >= 1001) {
            this.loyaltyTier = LoyaltyTier.PLATINUM;
        } else if (this.loyaltyPoints >= 501) {
            this.loyaltyTier = LoyaltyTier.GOLD;
        } else {
            this.loyaltyTier = LoyaltyTier.SILVER;
        }
    }

    public String getPreferredRoomType() {
        return preferredRoomType;
    }

    public void setPreferredRoomType(String preferredRoomType) {
        this.preferredRoomType = preferredRoomType;
    }

    public String getFloorPreference() {
        return floorPreference;
    }

    public void setFloorPreference(String floorPreference) {
        this.floorPreference = floorPreference;
    }

    public String getDietaryRequirements() {
        return dietaryRequirements;
    }

    public void setDietaryRequirements(String dietaryRequirements) {
        this.dietaryRequirements = dietaryRequirements;
    }

    // Helper methods
    public boolean isRepeatCustomer() {
        return this.totalBookings > 1;
    }

    public double getAverageSpentPerBooking() {
        if (this.totalBookings == 0) {
            return 0.0;
        }
        return this.totalSpent / this.totalBookings;
    }

    public String getCustomerSummary() {
        return "Customer ID: " + customerId +
                "\nName: " + name +
                "\nTotal Bookings: " + totalBookings +
                "\nTotal Spent: ₹" + String.format("%.2f", totalSpent) +
                "\nLoyalty Tier: " + loyaltyTier.getDisplayName() +
                "\nLoyalty Points: " + loyaltyPoints;
    }

    public boolean validateContactNumber() {
        // Simple validation: should be 10 digits
        return contactNumber.matches("\\d{10}");
    }

    public boolean validateEmail() {
        // Simple email validation
        return email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerId=" + customerId +
                ", name='" + name + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                ", email='" + email + '\'' +
                ", age=" + age +
                ", totalBookings=" + totalBookings +
                ", loyaltyTier=" + loyaltyTier +
                ", loyaltyPoints=" + loyaltyPoints +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Customer customer = (Customer) o;
        return customerId == customer.customerId;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(customerId);
    }
}