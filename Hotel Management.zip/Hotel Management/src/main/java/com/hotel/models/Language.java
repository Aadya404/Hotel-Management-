package com.hotel.models;
import java.io.Serializable;
public enum Language implements Serializable {
    ENGLISH("English"), HINDI("हिन्दी");
    private final String displayName;
    Language(String displayName) { this.displayName = displayName; }
    public String getDisplayName() { return displayName; }
}