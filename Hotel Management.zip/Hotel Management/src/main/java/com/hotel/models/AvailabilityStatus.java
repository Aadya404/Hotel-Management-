package com.hotel.models;
import java.io.Serializable;
public enum AvailabilityStatus implements Serializable {
    AVAILABLE("Available", "#00AA00"),
    OCCUPIED("Occupied", "#FFAA00"),
    MAINTENANCE("Maintenance", "#FF0000");
    private final String displayName;
    private final String color;
    AvailabilityStatus(String displayName, String color) { this.displayName = displayName; this.color = color; }
    public String getDisplayName() { return displayName; }
    public String getColor() { return color; }
}