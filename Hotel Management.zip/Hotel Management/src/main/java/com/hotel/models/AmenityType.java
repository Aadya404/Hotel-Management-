package com.hotel.models;
import java.io.Serializable;
public enum AmenityType implements Serializable {
    WIFI("WiFi"), AIR_CONDITIONING("Air Conditioning"), BALCONY("Balcony"),
    SAFE("Safe"), TV("TV"), MINI_BAR("Mini Bar"), BATHTUB("Bathtub"),
    SHOWER("Shower"), ROOM_SERVICE("Room Service");
    private final String displayName;
    AmenityType(String displayName) { this.displayName = displayName; }
    public String getDisplayName() { return displayName; }
}